package com.cmlb2bapply.pageobject;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.LogStatus;

public class CT_Page extends RunnerTest  {

	//Utilities-Object Creation
	GenericUtilities gu=new GenericUtilities();

	public CT_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//select[@id='ctType']")
	private WebElement select_ctType;

	@FindBy(xpath="//input[@id='ctFirstName']")
	private WebElement input_ctFirstName;

	@FindBy(xpath="//input[@id='ctMiddleName']")
	private WebElement input_ctMiddleName;

	@FindBy(xpath="//input[@id='ctLastName']")
	private WebElement input_ctLastName;

	@FindBy(xpath="//input[@id='ctJobTitle']")
	private WebElement input_ctJobTitle;

	@FindBy(xpath="//input[@id='ctHomeAddress']")
	private WebElement input_ctHomeAddress;

	@FindBy(xpath="//input[@name='ctZipCode']")
	private WebElement input_ctZipCode;

	@FindBy(xpath="//input[@name='ctZipCodeCityStates']")
	private WebElement input_ctZipCodeCityStates;

	@FindBy(xpath="//input[@id='ctSocialNumber']")
	private WebElement input_ctSocialNumber;

	@FindBy(xpath="//input[@id='ctDateOfBirth']")
	private WebElement input_ctDateOfBirth;

	@FindBy(xpath="//input[@id='ctCheckUSCitizen']")
	private WebElement checkbox_ctCheckUSCitizen;

	@FindBy (xpath = "//*[@id='dunAndBstreetNumber']")
	private WebElement input_dunAndBstreetNumber;

	@FindBy(xpath="//input[@id='ctPassportNumber']")
	private WebElement input_ctidentificationDocNo;

	@FindBy(xpath="//select[@id='ctCountryList']")
	private WebElement select_ctCountryList;

	@FindBy(xpath="//select[@id='ctDescriptionDocument']")
	private WebElement select_ctDescriptionDocument;

	@FindBy(xpath="//input[@id='ctDocumentIssueDate']")
	private WebElement input_ctDocumentIssueDate;

	@FindBy(xpath="//input[@id='ctDocumentExpirationDate']")
	private WebElement input_ctDocumentExpirationDate;
	
	
	@FindBy(id="homePhone")
	private WebElement input_apPhoneNumber;
	
	@FindBy(id="applicantEmailAddress")
	private WebElement input_apEmailAddress;


	@FindBy(xpath="//input[@name='addBuyers[0].opFirstName']")
	private WebElement input_opFirstName0;

	@FindBy(xpath="//input[@name='addBuyers[0].opLastName']")
	private WebElement input_opLastName0;
	//Field validation errors objects
	@FindBy(xpath="//span[contains(text(), 'Required field')]")
	public WebElement requiredfield;

	@FindBy(xpath="//span[contains(text(), 'Must be at least 4 characters')]")
	public WebElement MustBe4Characters;

	@FindBy(xpath="//span[contains(text(), 'Must be 5 characters')]")
	public WebElement MustBe5Characters;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid email address')]")
	public WebElement validEmailAddress;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Taxpayer ID or FEIN Number')]")
	public WebElement validTaxpayerId;

	@FindBy(xpath="//span[contains(text(),'Can't be a future date']")
	public WebElement CantBeFutureDate;

	@FindBy(xpath="//span[contains(text(), 'Invalid Year')]")
	public WebElement InvalidYear;

	@FindBy(xpath="//span[contains(text(), 'Invalid Date')]")
	public WebElement InvalidDate;

	@FindBy(xpath="//span[contains(text(),'Must be atleast 18 years old')]")
	public WebElement MustBe18YearsOld;

	@FindBy(xpath="//span[contains(text(), 'Must be at least $1000')]")
	public WebElement MustBe$1000;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Business Phone')]")
	public WebElement validBusinessPhone ;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Personal Phone')]")
	public WebElement validPersonalPhone;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Social Security Number')]")
	public WebElement validSSN ;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid  Date of Birth')]")
	public WebElement validDOB;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Date of Birth')]")
	public WebElement validDOB1;

	@FindBy(xpath="//span[contains(text(), 'Must be at least 6 characters')]")
	public WebElement MustBe6Characters ;

	@FindBy(xpath="//span[contains(text(), 'Must be greater than issue date')]")
	public WebElement MustBeGreaterThanIssueDate;

	@FindBy(xpath="//span[contains(text(), 'Must be greater than current date')]")
	public WebElement MustBeGreaterThanCurrentDate;
	
	@FindBy(xpath="//span[contains(text(),'Please enter a valid Personal Phone')]")
	public WebElement  PleaseenteravalidPersonalPhone;
	
	
	@FindBy(id="baBillingAddress")
	private WebElement input_baBillingAddress;

	@FindBy(id="baBuilding")
	private WebElement input_babillingsuite;

	@FindBy(name="baZipCode")
	private WebElement input_baZipCode;

	@FindBy(id="companyPhNo")
	private WebElement input_businessPhone;

	@FindBy(id="businessPhoneEx")
	private WebElement input_businessExt;

	@FindBy(id="emailAddress")
	public WebElement input_emailAddress;

	@FindBy(id="taxNumber")
	private WebElement input_taxPayerID;

	@FindBy(id="numberOfEmployees")
	private WebElement input_noOfEmployees;

	@FindBy(id="inBusinessSince")
	private WebElement input_yearEstablished;

	@FindBy(id="annualRevenue")
	private WebElement input_annualRevenue;

	@FindBy(id="creditLineRequested")
	private WebElement input_requestedCreditLine;

	@FindBy(xpath="//button[contains(text(),'Continue')]")
	//@FindBy(xpath="//button[@type='submit']")
	private WebElement click_continueButton;

	@FindBy(xpath="//button[@type='submit'])")
	private WebElement click_submitButton;

	//Field validation errors objects

	@FindBy(xpath="//select[@name='companyzipCodeCityStates']")
	private WebElement input_ctPassportNumber;

	@FindBy(xpath="//input[@name='busOwns[0].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen0;

	@FindBy(id="apFirstName")
	private WebElement input_apFirstName;

	@FindBy(id="apMiddleName")
	private WebElement input_apMiddleName;

	@FindBy(id="apLastName")
	private WebElement input_apLastName;

	@FindBy(xpath="//select[@name='busOwns[0].boType']")
	private WebElement select_boType0;

	@FindBy(xpath="//input[@name='busOwns[0].boFirstname']")
	private WebElement input_boFirstname0;

	@FindBy(xpath="//input[@name='busOwns[0].boMiddleName']")
	private WebElement input_boMiddleName0;

	@FindBy(xpath="//input[@name='busOwns[0].boLastname']")
	private WebElement input_boLastname0;

	@FindBy(xpath="//input[@name='busOwns[0].boHomeaddress']")
	private WebElement input_boHomeaddress0;

	@FindBy(xpath="//input[@name='busOwns[0].boZipcode']")
	private WebElement input_boZipcode0;

	@FindBy(xpath="//input[@name='busOwns[0].boCitystate']")
	private WebElement input_boCitystate0;

	@FindBy(xpath="//input[@name='busOwns[0].boSocialnumber']")
	private WebElement input_boSocialnumber0;

	@FindBy(xpath="//input[@name='busOwns[0].boDateOfBirth']")
	private WebElement input_boDateOfBirth0;

	@FindBy(xpath="//input[@name='busOwns[0].boPassportnumber']")
	private WebElement input_boPassportnumber0;

	@FindBy(xpath="//input[@name='busOwns[0].boPassportnumber']")
	private WebElement input_boidentificationDocNo0;

	@FindBy(xpath="//select[@name='busOwns[0].boCountryList']")
	private WebElement select_boCountryList0;

	@FindBy(xpath="//select[@name='busOwns[0].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument0;

	@FindBy(xpath="//input[@name='busOwns[0].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate0;

	@FindBy(xpath="//input[@name='busOwns[0].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate0;

	@FindBy (name = "busOwns[1].boType")
	private WebElement select_boType1;

	@FindBy(xpath="//input[@name='busOwns[1].boFirstname']")
	private WebElement input_boFirstname1;

	@FindBy(xpath="//input[@name='busOwns[1].boMiddleName']")
	private WebElement input_boMiddleName1;

	@FindBy(xpath="//input[@name='busOwns[1].boLastname']")
	private WebElement input_boLastname1;

	@FindBy(xpath="//input[@name='busOwns[1].boHomeaddress']")
	private WebElement input_boHomeaddress1;

	@FindBy(xpath="//input[@name='busOwns[1].boZipcode']")
	private WebElement input_boZipcode1;

	@FindBy(xpath="//input[@name='busOwns[1].boCitystate']")
	private WebElement input_boCitystate1;

	@FindBy(xpath="//input[@name='busOwns[1].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen1;

	@FindBy(xpath="//input[@name='busOwns[1].boSocialnumber']")
	private WebElement input_boSocialnumber1;

	@FindBy(xpath="//input[@name='busOwns[1].boDateOfBirth']")
	private WebElement input_boDateOfBirth1;

	@FindBy(xpath="//input[@name='busOwns[1].boPassportnumber']")
	private WebElement input_boPassportnumber1;

	@FindBy(xpath="//select[@name='busOwns[1].boCountryList']")
	private WebElement select_boCountryList1;

	@FindBy(xpath="//select[@name='busOwns[1].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument1;

	@FindBy(xpath="//input[@name='busOwns[1].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate1;

	@FindBy(xpath="//input[@name='busOwns[1].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate1;

	@FindBy(xpath="//select[@name='busOwns[2].boType']")
	//@FindBy(name="busOwns[2].boType")
	private WebElement select_boType2;

	@FindBy(xpath="//input[@name='busOwns[2].boFirstname']")
	private WebElement input_boFirstname2;

	@FindBy(xpath="//input[@name='busOwns[2].boMiddleName']")
	private WebElement input_boMiddleName2;

	@FindBy(xpath="//input[@name='busOwns[2].boLastname']")
	private WebElement input_boLastname2;

	@FindBy(xpath="//input[@name='busOwns[2].boHomeaddress']")
	private WebElement input_boHomeaddress2;

	@FindBy(xpath="//input[@name='busOwns[2].boZipcode']")
	private WebElement input_boZipcode2;

	@FindBy(xpath="//input[@name='busOwns[2].boCitystate']")
	private WebElement input_boCitystate2;

	@FindBy(xpath="//input[@name='busOwns[2].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen2;

	@FindBy(xpath="//input[@name='busOwns[2].boSocialnumber']")
	private WebElement input_boSocialnumber2;

	@FindBy(xpath="//input[@name='busOwns[2].boDateOfBirth']")
	private WebElement input_boDateOfBirth2;

	@FindBy(xpath="//input[@name='busOwns[2].boPassportnumber']")
	private WebElement input_boPassportnumber2;

	@FindBy(xpath="//select[@name='busOwns[2].boCountryList']")
	private WebElement select_boCountryList2;

	@FindBy(xpath="//select[@name='busOwns[2].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument2;

	@FindBy(xpath="//input[@name='busOwns[2].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate2;

	@FindBy(xpath="//input[@name='busOwns[2].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate2;

	//@FindBy(xpath="//select[@name='busOwns[3].boType']")
	@FindBy(name="busOwns[3].boType")
	private WebElement select_boType3;

	@FindBy(xpath="//input[@name='busOwns[3].boFirstname']")
	private WebElement input_boFirstname3;

	@FindBy(xpath="//input[@name='busOwns[3].boMiddleName']")
	private WebElement input_boMiddleName3;

	@FindBy(xpath="//input[@name='busOwns[3].boLastname']")
	private WebElement input_boLastname3;

	@FindBy(xpath="//input[@name='busOwns[3].boHomeaddress']")
	private WebElement input_boHomeaddress3;

	@FindBy(xpath="//input[@name='busOwns[3].boZipcode']")
	private WebElement input_boZipcode3;

	@FindBy(xpath="//input[@name='busOwns[3].boCitystate']")
	private WebElement input_boCitystate3;

	@FindBy(xpath="//input[@name='busOwns[3].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen3;

	@FindBy(xpath="//input[@name='busOwns[3].boSocialnumber']")
	private WebElement input_boSocialnumber3;

	@FindBy(xpath="//input[@name='busOwns[3].boDateOfBirth']")
	private WebElement input_boDateOfBirth3;

	@FindBy(xpath="//input[@name='busOwns[3].boPassportnumber']")
	private WebElement input_boPassportnumber3;

	@FindBy(xpath="//select[@name='busOwns[3].boCountryList']")
	private WebElement select_boCountryList3;

	@FindBy(xpath="//select[@name='busOwns[3].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument3;

	@FindBy(xpath="//input[@name='busOwns[3].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate3;

	@FindBy(xpath="//input[@name='busOwns[3].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate3;

	@FindBy(xpath="//select[@name='busOwns[4].boType']")
	private WebElement select_boType4;

	@FindBy(xpath="//input[@name='busOwns[4].boFirstname']")
	private WebElement input_boFirstname4;

	@FindBy(xpath="//input[@name='busOwns[4].boMiddleName']")
	private WebElement input_boMiddleName4;

	@FindBy(xpath="//input[@name='busOwns[4].boLastname']")
	private WebElement input_boLastname4;

	@FindBy(xpath="//input[@name='busOwns[4].boHomeaddress']")
	private WebElement input_boHomeaddress4;

	@FindBy(xpath="//input[@name='busOwns[4].boZipcode']")
	private WebElement input_boZipcode4;

	@FindBy(xpath="//input[@name='busOwns[4].boCitystate']")
	private WebElement input_boCitystate4;

	@FindBy(xpath="//input[@name='busOwns[4].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen4;

	@FindBy(xpath="//input[@name='busOwns[4].boSocialnumber']")
	private WebElement input_boSocialnumber4;

	@FindBy(xpath="//input[@name='busOwns[4].boDateOfBirth']")
	private WebElement input_boDateOfBirth4;

	@FindBy(xpath="//input[@name='busOwns[4].boPassportnumber']")
	private WebElement input_boPassportnumber4;

	@FindBy(xpath="//select[@name='busOwns[4].boCountryList']")
	private WebElement select_boCountryList4;

	@FindBy(xpath="//select[@name='busOwns[4].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument4;

	@FindBy(xpath="//input[@name='busOwns[4].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate4;

	@FindBy(xpath="//input[@name='busOwns[4].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate4;

	@FindBy(xpath="//*[contains(text(),'Add another Beneficial Owner')]")
	private WebElement link_AddanotherBeneficialOwner;

	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;

	@FindBy(name="applicantEmailAddress")
	private WebElement input_pgEmailAddress;

	@FindBy(xpath="//*[@id='address1'and contains(text(),'Do not use a P.O. Box. Instead, use your physical address.')]") 
	private WebElement CTHomeaddressVerbiage;	

	@FindBy(id = "companyContact")
	public WebElement Bicompanycontact;


	public void Click_ContinueButton() throws Exception{
		try {
			gu.click(click_continueButton);

			logger.info("User clicks on Continue Button");

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+ e1.getMessage());
			//throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			//throw(e2);
		}
	}

	public void PGPage_Elementvalidation(WebDriver driver) throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, select_ctType, 10)){
				status=true;
			}else{
				status=false;
			}
		}catch(Exception e){

			e.printStackTrace();
			//throw(e);
		}
		Assert.assertTrue(status, "PG Page Filed Validation failed");
	}


	public void CTHomeaddressvalidate(String CTHomeaddressVerbiage) throws Exception{

		boolean status=false;
		try{
			gu.clickByJs(driver, "willIncludePG");
			gu.click(input_ctHomeAddress);

			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{

				S=i.getText();
				// System.out.println(S);
				if(S.equalsIgnoreCase(CTHomeaddressVerbiage))
				{
					status =true;
					logger.info("CT homeaddress verbiage verified successfully");
					break;
				}

			}


			//Assert.assertEquals(S, PGHomeaddVerbiage);
			System.out.println("CT homeaddress verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with CT homeaddress verbiage");
			logger.info(e.getMessage());
		}

	}

	public void navigatedTo_CtPage(WebDriver driver) throws Exception{
		Thread.sleep(2000);
		String urlNew = driver.getCurrentUrl();
		try{
			if (urlNew.contains("applicant-ct")){
				logger.info("Navigated to CT page");
			}
		}catch(Exception e){
			e.printStackTrace();
			logger.info("Not Navigated to CT page...."+e.getMessage());
			//throw(e);
		}
	}

	public void SelectController(String Controller) throws Exception{
		try{
			gu.selectdropdown(select_ctType, "text", Controller);
			gu.pageScrollDownWithEle(driver, select_ctType);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
		}catch(Exception e){
			e.printStackTrace();
			logger.info("someone else or ar/pg is not selected in controller page "+e.getMessage());
			//throw(e);
		}
	}


	public void EntervalueInCTFieldsIsUsCitizen(String CTFirstName, String CTmi, String CTLastName ,String CTJobTitle ,String CTHomeAddress, String CTZipCode, String CTssn, String CTDob) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_ctFirstName);
			status=gu.WaitForElePresent(input_ctFirstName, wait1);
			if(status==true){
				gu.entertext(input_ctFirstName, CTFirstName);
				//logger.info(" CTFirstName value entered :"+CTFirstName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTFirstName value entered: "+CTFirstName + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctMiddleName, CTmi);
				//logger.info("  CTmi value entered :"+CTmi);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTmi value entered: "+CTmi + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctLastName, CTLastName);
				//logger.info(" CTLastName value entered :"+CTLastName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTLastName value entered: "+CTLastName + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctJobTitle, CTJobTitle);
				//logger.info(" CTJobTitle value entered :"+CTJobTitle);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTJobTitle value entered: "+CTJobTitle + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctHomeAddress, CTHomeAddress);
				//logger.info(" CTHomeAddress value entered :"+CTHomeAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTHomeAddress value entered: "+CTHomeAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctZipCode, CTZipCode);
				//logger.info("  CTZipCode value entered :"+CTZipCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTZipCode value entered: "+CTZipCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctSocialNumber, CTssn);
				//logger.info("CTssn  value entered :"+ CTssn);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTssn value entered: "+CTssn + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctDateOfBirth, CTDob);
				//logger.info("CTDob  value entered :"+ CTDob);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTDob value entered: "+CTDob + loggerE.addScreenCapture(screenshotPath));

				status=true;
			}
			else{
				status=false;
			}
			Assert.assertTrue(status, "CT PAGE");
		} 
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e1.getMessage());
			System.out.println("Issue with entering ct text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "CT PAGE");
	}

	public void EnterfewvalueInCTFields(String CTFirstName, String CTmi, String CTLastName) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_ctFirstName);
			status=gu.WaitForElePresent(input_ctFirstName, wait1);
			if(status==true){
				gu.entertext(input_ctFirstName, CTFirstName);
				//logger.info(" CTFirstName value entered :"+CTFirstName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTFirstName value entered: "+CTFirstName + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctMiddleName, CTmi);
				//logger.info("  CTmi value entered :"+CTmi);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTmi value entered: "+CTmi + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_ctLastName, CTLastName);
				//logger.info(" CTLastName value entered :"+CTLastName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTLastName value entered: "+CTLastName + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				status=false;
			}
			Assert.assertTrue(status, "CT PAGE");
		} 
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e1.getMessage());
			System.out.println("Issue with entering ct text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "CT PAGE");
	}

	public void EnterfewmorevalueInCTFields(String CTJobTitle ,String CTHomeAddress) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_ctFirstName);
			status=gu.WaitForElePresent(input_ctFirstName, wait1);
			if(status==true){			
				gu.entertext(input_ctJobTitle, CTJobTitle);
				//logger.info(" CTJobTitle value entered :"+CTJobTitle);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTJobTitle value entered: "+CTJobTitle + loggerE.addScreenCapture(screenshotPath));			
				gu.entertext(input_ctHomeAddress, CTHomeAddress);
				//logger.info(" CTHomeAddress value entered :"+CTHomeAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CTHomeAddress value entered: "+CTHomeAddress + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				status=false;
			}
			Assert.assertTrue(status, "CT PAGE");
		} 
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e1.getMessage());
			System.out.println("Issue with entering ct text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "CT PAGE");
	}



	public void EntervalueInCTFieldsIsNotUsCitizen(String CTFirstName, String CTmi, String CTLastName ,String CTJobTitle ,String CTHomeAddress, String CTZipCode, String CTssn, String CTDob,String CTPassportNumber,String CTCountryOfIDIssunace,String CTTypeOfIdentification,String CTDocIssueDt,String CTDocExpDt) throws Exception{

		try {
			gu.entertext(input_ctFirstName, CTFirstName);
			//logger.info(" CTFirstName value entered :"+CTFirstName);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTFirstName value entered: "+CTFirstName + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctMiddleName, CTmi);
			//logger.info("  CTmi value entered :"+CTmi);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTmi value entered: "+CTmi + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctLastName, CTLastName);
			//logger.info(" CTLastName value entered :"+CTLastName);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTLastName value entered: "+CTLastName + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctJobTitle, CTJobTitle);
			//logger.info(" CTJobTitle value entered :"+CTJobTitle);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTJobTitle value entered: "+CTJobTitle + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctHomeAddress, CTHomeAddress);
			//logger.info(" CTHomeAddress value entered :"+CTHomeAddress);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTHomeAddress value entered: "+CTHomeAddress + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctZipCode, CTZipCode);
			//logger.info("  CTZipCode value entered :"+CTZipCode);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTZipCode value entered: "+CTZipCode + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDateOfBirth, CTDob);
			//logger.info("CTDob  value entered :"+ CTDob);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDob value entered: "+CTDob + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctSocialNumber, CTssn);
			//logger.info("CTssn  value entered :"+ CTssn);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTssn value entered: "+CTssn + loggerE.addScreenCapture(screenshotPath));

			//gu.click(checkbox_ctCheckUSCitizen);
			gu.clickByJs(driver, "ctCheckUSCitizen");
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_ctidentificationDocNo, CTPassportNumber);
			//logger.info("CTPassportNumber  value entered :"+ CTPassportNumber);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTPassportNumber value entered: "+CTPassportNumber + loggerE.addScreenCapture(screenshotPath));

			gu.selectdropdown(select_ctCountryList, "text", CTCountryOfIDIssunace);
			logger.info("CTCountryOfIDIssunace  value selected  :"+ CTCountryOfIDIssunace);

			gu.selectdropdown(select_ctDescriptionDocument, "text", CTTypeOfIdentification);
			//logger.info("CTTypeOfIdentification  value selected :"+ CTTypeOfIdentification);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTTypeOfIdentification value entered: "+CTTypeOfIdentification + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDocumentIssueDate, CTDocIssueDt);
			//logger.info("CTDocIssueDt  value entered :"+ CTDocIssueDt);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDocIssueDt value entered: "+CTDocIssueDt + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDocumentExpirationDate, CTDocExpDt);
			//logger.info("CTDocExpDt  value entered :"+ CTDocExpDt);
			gu.pageScrollDownWithEle(driver, input_ctDocumentExpirationDate);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDocExpDt value entered: "+CTDocExpDt + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e1.getMessage());
			System.out.println("Issue with entering ct text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	
	public void EntervalueinCTbydefaultcheckbox(String CTFirstName, String CTmi, String CTLastName ,String CTJobTitle ,String CTHomeAddress, String CTZipCode, String CTssn, String CTDob) throws Exception{

		try {
			
			gu.entertext(input_ctFirstName, CTFirstName);
			gu.pageScrollDownWithEle(driver, input_ctFirstName);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
			//logger.info(" CTFirstName value entered :"+CTFirstName);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTFirstName value entered: "+CTFirstName + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctMiddleName, CTmi);
			//logger.info("  CTmi value entered :"+CTmi);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTmi value entered: "+CTmi + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctLastName, CTLastName);
			//logger.info(" CTLastName value entered :"+CTLastName);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTLastName value entered: "+CTLastName + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctJobTitle, CTJobTitle);
			//logger.info(" CTJobTitle value entered :"+CTJobTitle);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTJobTitle value entered: "+CTJobTitle + loggerE.addScreenCapture(screenshotPath));

			
			gu.pageScrollDownWithEle(driver, input_ctHomeAddress);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
			gu.entertext(input_ctHomeAddress, CTHomeAddress);
			//logger.info(" CTHomeAddress value entered :"+CTHomeAddress);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTHomeAddress value entered: "+CTHomeAddress + loggerE.addScreenCapture(screenshotPath));
			gu.pageScrollDownByPixel(driver);
			
			
			gu.entertext(input_ctZipCode, CTZipCode);
			//logger.info("  CTZipCode value entered :"+CTZipCode);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTZipCode value entered: "+CTZipCode + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDateOfBirth, CTDob);
			//logger.info("CTDob  value entered :"+ CTDob);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDob value entered: "+CTDob + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctSocialNumber, CTssn);
			//logger.info("CTssn  value entered :"+ CTssn);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTssn value entered: "+CTssn + loggerE.addScreenCapture(screenshotPath));
			gu.pageScrollDownWithEle(driver, input_ctSocialNumber);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
			
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e1.getMessage());
			System.out.println("Issue with entering ct text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void EntervalueInCTMadatoryFieldsIsNotUsCitizen(String CTHomeAddress, String CTZipCode, String CTssn, String CTDob,String CTPassportNumber,String CTCountryOfIDIssunace,String CTTypeOfIdentification,String CTDocIssueDt,String CTDocExpDt) throws Exception{
		try {
			gu.entertext(input_ctHomeAddress, CTHomeAddress);
			//logger.info(" CTHomeAddress value entered :"+CTHomeAddress);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTHomeAddress value entered: "+CTHomeAddress + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctZipCode, CTZipCode);
			//logger.info("  CTZipCode value entered :"+CTZipCode);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTZipCode value entered: "+CTZipCode + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDateOfBirth, CTDob);
			//logger.info("CTDob  value entered :"+ CTDob);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDob value entered: "+CTDob + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctSocialNumber, CTssn);
			//logger.info("CTssn  value entered :"+ CTssn);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTssn value entered: "+CTssn + loggerE.addScreenCapture(screenshotPath));

			gu.click(checkbox_ctCheckUSCitizen);
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_ctidentificationDocNo, CTPassportNumber);
			//logger.info("CTPassportNumber  value entered :"+ CTPassportNumber);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTPassportNumber value entered: "+CTPassportNumber + loggerE.addScreenCapture(screenshotPath));

			gu.selectdropdown(select_ctCountryList, "text", CTCountryOfIDIssunace);
			logger.info("CTCountryOfIDIssunace  value selected  :"+ CTCountryOfIDIssunace);

			gu.selectdropdown(select_ctDescriptionDocument, "text", CTTypeOfIdentification);
			//logger.info("CTTypeOfIdentification  value selected :"+ CTTypeOfIdentification);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTTypeOfIdentification value entered: "+CTTypeOfIdentification + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDocumentIssueDate, CTDocIssueDt);
			//logger.info("CTDocIssueDt  value entered :"+ CTDocIssueDt);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDocIssueDt value entered: "+CTDocIssueDt + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDocumentExpirationDate, CTDocExpDt);
			//logger.info("CTDocExpDt  value entered :"+ CTDocExpDt);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDocExpDt value entered: "+CTDocExpDt + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e1.getMessage());
			System.out.println("Issue with entering ct text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void Enterinvalidvalue(String InvalidCTZipCode,String InvalidCTssn,String InvalidCTDob,String InvalidCTPassportNumber,String InvalidCTDocIssueDt,String InvalidCTDocExpDt,String CTZipCode,String CTDob,String CTssn ,String CTPassportNumber,String CTDocIssueDt,String CTDocExpDt) throws Exception{

		try {

			gu.entertext(input_ctZipCode, InvalidCTZipCode);
			//logger.info("  CTZipCode value entered :"+InvalidCTZipCode);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"InvalidCTZipCode value entered: "+InvalidCTZipCode + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctSocialNumber, InvalidCTssn);
			//logger.info("CTssn  value entered :"+ InvalidCTssn);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"InvalidCTssn value entered: "+InvalidCTssn + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDateOfBirth, InvalidCTDob);
			//logger.info("CTDob  value entered :"+ InvalidCTDob);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"InvalidCTDob value entered: "+InvalidCTDob + loggerE.addScreenCapture(screenshotPath));

			gu.click(checkbox_ctCheckUSCitizen);
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_ctDateOfBirth, InvalidCTPassportNumber);
			//logger.info("CTPassportNumber  value entered :"+ InvalidCTPassportNumber);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"InvalidCTPassportNumber value entered: "+InvalidCTPassportNumber + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDocumentIssueDate, InvalidCTDocIssueDt);
			//logger.info("CTDocIssueDt  value entered :"+ InvalidCTDocIssueDt);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"InvalidCTDocIssueDt value entered: "+InvalidCTDocIssueDt + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDocumentExpirationDate, InvalidCTDocExpDt);
			//logger.info("CTDocExpDt  value entered :"+ InvalidCTDocExpDt);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"InvalidCTDocExpDt value entered: "+InvalidCTDocExpDt + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctZipCode, CTZipCode);
			//logger.info("  CTZipCode value entered :"+CTZipCode);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTZipCode value entered: "+CTZipCode + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDateOfBirth, CTDob);
			//logger.info("CTDob  value entered :"+ CTDob);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDob value entered: "+CTDob + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctSocialNumber, CTssn);
			//logger.info("CTssn  value entered :"+ CTssn);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTssn value entered: "+CTssn + loggerE.addScreenCapture(screenshotPath));

			gu.click(checkbox_ctCheckUSCitizen);
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_ctPassportNumber, CTPassportNumber);
			//logger.info("CTPassportNumber  value entered :"+ CTPassportNumber);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTPassportNumber value entered: "+CTPassportNumber + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDocumentIssueDate, CTDocIssueDt);
			//logger.info("CTDocIssueDt  value entered :"+ CTDocIssueDt);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDocIssueDt value entered: "+CTDocIssueDt + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_ctDocumentExpirationDate, CTDocExpDt);
			//logger.info("CTDocExpDt  value entered :"+ CTDocExpDt);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CTDocExpDt value entered: "+CTDocExpDt + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e1.getMessage());
			System.out.println("Issue with entering ct text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  ct text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void validateLabel(String labelname)  throws Exception{
		try {
			String actVal =gu.getlabel(input_ctidentificationDocNo);
			Assert.assertEquals(actVal, labelname);
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
	}
	public void validateFormate(String fieldvalue)  throws Exception{
		try {
			String actVal =gu.getformatedvalue(input_ctSocialNumber);
			Assert.assertEquals(actVal, fieldvalue);
			logger.info("Entered value is in XXX-XX-XXXX format");
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
	}
	public void validateMasking(String Maskfield)  throws Exception{
		try {

			if( Maskfield.equals("CtPassportNumber")){
				String actVal =gu.getmaskvalue(input_ctidentificationDocNo);
				Assert.assertEquals(actVal, "password");
				logger.info("value masked");
			}
			if(Maskfield.equals("ctSocialNumber"))	{
				String actVal =gu.getmaskvalue(input_ctSocialNumber);
				Assert.assertEquals(actVal, "password");
				logger.info("value masked");
			}
		}catch (Exception e) {
			logger.info(e.getMessage());
		}
	}
	public void FieldValues(WebElement ele,String FieldValue,String ErrorMessage,String MaxLength)throws Exception{
		String[] fieldVal ;	 
		String[] errormsg ;

		fieldVal  = FieldValue.split(",");
		int size = fieldVal.length;
		errormsg = ErrorMessage.split(",");
		int size1 = errormsg.length;
		boolean status;
		for (int i = 0; i <= size-1; i++) {

			//for (int J = i; J <= size1-1; J--) {
			System.out.println(fieldVal[i]);
			System.out.println(errormsg[i]);
			//						ele.click();
			//						ele.sendKeys(FieldValue);
			//						
			gu.entertext(ele,fieldVal[i]);
			gu.tab();
			
			

			int k=i+1;
			gu.captureupdateOTR(driver, document, k+" Test Data :  "+fieldVal[i]);
			
			//if (!ErrorMessage.equals(null))
			if (!errormsg[i].equals("null")) {
				status = ErrorMessages(errormsg[i]);
				Assert.assertTrue(status, "error msg displayed");
				if (status==true){
					logger.info(status);	
					//Assert.assertTrue(status, FieldName);
				}
			}
			
		}  
		
		if (!MaxLength.isEmpty()){
			String actml1 =gu.getMaxLenght(ele);
			int MaxLenght1= Integer.valueOf(MaxLength);
			int actual= Integer.valueOf(actml1);
			Assert.assertEquals(actual, MaxLenght1);
			System.out.println("maxlength matched");
			logger.info(" actual = "+MaxLenght1);
			status=true;
			
			//Arrays.fill(fieldVal, null);
		}
	
	}
	public void EntervaluesinField(String FieldName,String FieldValue,String ErrorMessage, String MaxLength,String labelname) throws Exception{
		String actMssg = null;

		switch(FieldName){

		case "ctFirstName" :
			FieldValues(input_ctFirstName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ctMiddleName" :
			FieldValues(input_ctMiddleName, FieldValue, ErrorMessage, MaxLength);
			break;

		case "ctJobTitle" :
			FieldValues(input_ctJobTitle, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ctLastName" :
			FieldValues(input_ctLastName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ctHomeAddress" :
			FieldValues(input_ctHomeAddress, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ctZipCode" :
			FieldValues(input_ctZipCode, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ctSocialNumber" :
			FieldValues(input_ctSocialNumber, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ctDateOfBirth" :
			FieldValues(input_ctDateOfBirth, FieldValue, ErrorMessage, MaxLength);
			break;
		case "CtPassportNumber" :
			FieldValues(input_ctidentificationDocNo, FieldValue, ErrorMessage, MaxLength);
			break;
		case "CtDocIssueDate" :
			FieldValues(input_ctDocumentIssueDate, FieldValue, ErrorMessage, MaxLength);
			break;
		case "CtDocExpDate" :
			FieldValues(input_ctDocumentExpirationDate, FieldValue, ErrorMessage, MaxLength);
			break;

		case "ZIPCode2" :
			FieldValues(input_baZipCode, FieldValue, ErrorMessage, MaxLength);
			break;

		case "BillingAddr" :
			FieldValues(input_baBillingAddress, FieldValue, ErrorMessage, MaxLength);
			break;

		case "BiSuite2" :
			FieldValues(input_babillingsuite, FieldValue, ErrorMessage, MaxLength);
			break;	
		case "BusinessPh" :
			FieldValues(input_businessPhone, FieldValue, ErrorMessage, MaxLength);
			break;
		case "BusinessExt" :
			FieldValues(input_businessExt, FieldValue, ErrorMessage, MaxLength);
			break;
		case "Email" :
			FieldValues(input_emailAddress, FieldValue, ErrorMessage, MaxLength);
			break;
		case "TaxPayer" :
			FieldValues(input_taxPayerID, FieldValue, ErrorMessage, MaxLength);
			break;
		case "DunAndBstreetNumber" :
			FieldValues(input_dunAndBstreetNumber, FieldValue, ErrorMessage, MaxLength);
			break;
		case "EmpNo" :
			FieldValues(input_noOfEmployees, FieldValue, ErrorMessage, MaxLength);
			break;
		case "Year" :
			FieldValues(input_yearEstablished, FieldValue, ErrorMessage, MaxLength);
			break;
		case "Revenue" :
			FieldValues(input_annualRevenue, FieldValue, ErrorMessage, MaxLength);
			break;
		case "RequestedCredit" :
			FieldValues(input_requestedCreditLine, FieldValue, ErrorMessage, MaxLength);
			break;

		case "FName" :
			FieldValues(input_apFirstName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "MName" :
			FieldValues(input_apMiddleName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "LName" :
			FieldValues(input_apLastName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "companyContact" :
			FieldValues(Bicompanycontact, FieldValue, ErrorMessage, MaxLength);
			break;

		case "PgEmail" :
			FieldValues(input_pgEmailAddress, FieldValue, ErrorMessage, MaxLength);
			break;

		case "boType0" :
			FieldValues(select_boType0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boFirstname0" :
			FieldValues(input_boFirstname0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boMiddleName0" :
			FieldValues(input_boMiddleName0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boLastname0" :
			FieldValues(input_boLastname0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boHomeaddress0" :
			FieldValues(input_boHomeaddress0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boZipcode0" :
			FieldValues(input_boZipcode0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCitystate0" :
			FieldValues(input_boCitystate0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCheckUSCitizen0" :
			FieldValues(input_boCheckUSCitizen0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boSocialnumber0" :
			FieldValues(input_boSocialnumber0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDateOfBirth0" :
			FieldValues(input_boDateOfBirth0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boPassportnumber0" :
			FieldValues(input_boPassportnumber0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCountryList0" :
			FieldValues(select_boCountryList0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDescriptiondocument0" :
			FieldValues(select_boDescriptiondocument0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentIssueDate0" :
			FieldValues(input_boDocumentIssueDate0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentExpirationDate0" :
			FieldValues(input_boDocumentExpirationDate0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boType1" :
			FieldValues(select_boType1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boFirstname1" :
			FieldValues(input_boFirstname1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boMiddleName1" :
			FieldValues(input_boMiddleName1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boLastname1" :
			FieldValues(input_boLastname1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boHomeaddress1" :
			FieldValues(input_boHomeaddress1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boZipcode1" :
			FieldValues(input_boZipcode1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCitystate1" :
			FieldValues(input_boCitystate1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCheckUSCitizen1" :
			FieldValues(input_boCheckUSCitizen1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boSocialnumber1" :
			FieldValues(input_boSocialnumber1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDateOfBirth1" :
			FieldValues(input_boDateOfBirth1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boPassportnumber1" :
			FieldValues(input_boPassportnumber1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCountryList1" :
			FieldValues(select_boCountryList1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDescriptiondocument1" :
			FieldValues(select_boDescriptiondocument1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentIssueDate1" :
			FieldValues(input_boDocumentIssueDate1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentExpirationDate1" :
			FieldValues(input_boDocumentExpirationDate1, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boType2" :
			FieldValues(select_boType2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boFirstname2" :
			FieldValues(input_boFirstname2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boMiddleName2" :
			FieldValues(input_boMiddleName2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boLastname2" :
			FieldValues(input_boLastname2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boHomeaddress2" :
			FieldValues(input_boHomeaddress2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boZipcode2" :
			FieldValues(input_boZipcode2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCitystate2" :
			FieldValues(input_boCitystate2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCheckUSCitizen2" :
			FieldValues(input_boCheckUSCitizen2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boSocialnumber2" :
			FieldValues(input_boSocialnumber2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDateOfBirth2" :
			FieldValues(input_boDateOfBirth2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boPassportnumber2" :
			FieldValues(input_boPassportnumber2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCountryList2" :
			FieldValues(select_boCountryList2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDescriptiondocument2" :
			FieldValues(select_boDescriptiondocument2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentIssueDate2" :
			FieldValues(input_boDocumentIssueDate2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentExpirationDate2" :
			FieldValues(input_boDocumentExpirationDate2, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boType3" :
			FieldValues(select_boType3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boFirstname3" :
			FieldValues(input_boFirstname3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boMiddleName3" :
			FieldValues(input_boMiddleName3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boLastname3" :
			FieldValues(input_boLastname3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boHomeaddress3" :
			FieldValues(input_boHomeaddress3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boZipcode3" :
			FieldValues(input_boZipcode3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCitystate3" :
			FieldValues(input_boCitystate3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCheckUSCitizen3" :
			FieldValues(input_boCheckUSCitizen3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boSocialnumber3" :
			FieldValues(input_boSocialnumber3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDateOfBirth3" :
			FieldValues(input_boDateOfBirth3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boPassportnumber3" :
			FieldValues(input_boPassportnumber3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCountryList3" :
			FieldValues(select_boCountryList3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDescriptiondocument3" :
			FieldValues(select_boDescriptiondocument3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentIssueDate3" :
			FieldValues(input_boDocumentIssueDate3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentExpirationDate3" :
			FieldValues(input_boDocumentExpirationDate3, FieldValue, ErrorMessage, MaxLength);
			break;
		case "OPFN" :
			FieldValues(input_opFirstName0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "OPLN" :
			FieldValues(input_opLastName0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ApPhoneNumber" :
			FieldValues(input_apPhoneNumber, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ApEmailAddress" :
			FieldValues(input_apEmailAddress, FieldValue, ErrorMessage, MaxLength);	
			break;
		}	
		
	}

	public void scrolldowntoele() throws Exception{
		try {
			logger.info("Scroll down");
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue with Scroll down");
		}
	}	
	public boolean ErrorMessages(String ErrorMessage ){
		String actMssg= null;
		boolean status = false;
		switch(ErrorMessage)
		{
		case "Required field" :
			actMssg =gu.getText(requiredfield);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be at least 4 characters" :
			actMssg =gu.getText(MustBe4Characters);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be 5 characters" :
			actMssg =gu.getText(MustBe5Characters);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid email address" :
			actMssg =gu.getText(validEmailAddress);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid Taxpayer ID or FEIN Number" :
			actMssg =gu.getText(validTaxpayerId);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Can't be a future date" :
			actMssg =gu.getText(CantBeFutureDate);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Invalid Year" :
			actMssg =gu.getText(InvalidYear);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Invalid Date" :
			actMssg =gu.getText(InvalidDate);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be atleast 18 years old" :
			actMssg =gu.getText(MustBe18YearsOld);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be at least $1000" :
			actMssg =gu.getText(MustBe$1000);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid Business Phone" :
			actMssg =gu.getText(validBusinessPhone);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
//		case "Please enter a valid Personal Phone" :
//			actMssg =gu.getText(validPersonalPhone);
//			logger.info(actMssg);
//			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
//			logger.info(status);
//			break;
		case "Please enter a valid Social Security Number" :
			actMssg =gu.getText(validSSN);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid Date of Birth" :
			actMssg =gu.getText(validDOB);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be at least 6 characters" :
			actMssg =gu.getText(MustBe6Characters);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be greater than issue date" :
			actMssg =gu.getText(MustBeGreaterThanIssueDate);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be greater than current date" :
			actMssg =gu.getText(MustBeGreaterThanCurrentDate);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
			
		case "Please enter a valid Personal Phone" :
			actMssg =gu.getText(PleaseenteravalidPersonalPhone);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
			
		}
		return status;
	}
	public void Click_UsCitizenCheckboxInCT() throws Exception{
		try {
			gu.click(checkbox_ctCheckUSCitizen);
			//gu.click(input_boCheckUSCitizen0);

			logger.info("User clicks on US Citizen checkbox");

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking US Citizen checkbox"+ e1.getMessage());
			//throw(e1);
		}
	}
	public void Click_UsCitizenCheckbox() throws Exception{
		try {
			gu.click(checkbox_ctCheckUSCitizen);
			//gu.click(input_boCheckUSCitizen0);
			logger.info("User clicks on US Citizen checkbox");
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking US Citizen checkbox"+ e1.getMessage());
			//throw(e1);
		}
	}

	public void validateText(String EnteredText)  throws Exception{
		try {
			String actVal =gu.getEnteredText(input_ctLastName);
			if(actVal.equals(EnteredText)){
				//Assert.assertEquals(actVal, EnteredText);
				logger.info(" actual = "+EnteredText);
				gu.captureupdateOTR(driver, document, " Previously entered data is retained, user can continue filling the page further ");
				System.out.println("Previously entered data is retained, user can continue filling the page further");
			}
			else
			{
				System.out.println("Previously entered value is erased, user should start filling the page again");
				gu.captureupdateOTR(driver, document, " Previously entered value is erased, user should start filling the page again ");
			}
		} catch (Exception e) {
			logger.info(e.getMessage());

		}
	}

}

