package com.cmlb2bapply.pageobject;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.LogStatus;




public class AR_Page extends RunnerTest  {

	//Utilities-Object Creation
	GenericUtilities gu=new GenericUtilities();

	public AR_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div[contains(text(),'Authorized Representative')]")
	private WebElement Text_arText;

	@FindBy(xpath="//div[contains(text(),'All fields are required unless')]")
	private WebElement Text_arAllFieldsAreRequiredText;

	@FindBy(xpath="//div[@class='sc-cvbbAY eVkOIO']")
	private WebElement ARSubHeaderParagraph;

	@FindBy(id="apFirstName")
	private WebElement input_apFirstName;

	@FindBy(id="apMiddleName")
	private WebElement input_apMiddleName;

	@FindBy(id="apLastName")
	private WebElement input_apLastName;


	@FindBy(id="businessTitle")
	private WebElement input_apJobTitle;
	
	
	@FindBy(id="homePhone")
	private WebElement input_apPhoneNumber;
	
	@FindBy(id="applicantEmailAddress")
	private WebElement input_apEmailAddress;

	@FindBy(id="membershipNumber")
	public WebElement Ar_membershipnum;
	
	@FindBy(xpath="//button[contains(text(),'Continue')]")
	private WebElement click_continueButton;
	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;

	
	@FindBy(xpath="//div[@class='sc-jKVCRD kvQisG']")
	private WebElement ApplicantSubnavinARPage;

	@FindBy(xpath="//a[contains(text(),'Authorized Representative')]")
	private WebElement AuthorizedRepresentative_inSubnav;

	@FindBy(xpath="//a[contains(text(),'Personal Guarantor')]")
	private WebElement PersonalGuarantor_inSubnav;

	@FindBy(xpath="//a[contains(text(),'Controller')]")
	private WebElement Controller_inSubnav;

	@FindBy(xpath="//a[contains(text(),'Beneficial Owner')]")
	private WebElement BeneficialOwner_inSubnav;

	
	@FindBy(xpath="//div[@class='sc-jWBwVP gISDaj'] ")
	private WebElement ARHorizontallinewithSectionIcon;

	@FindBy(xpath="	//div[@class='sc-feJyhm kdhxJT'] ")
	private WebElement TextunderContinuebtninAR;

	@FindBy(xpath="//img[@class='sc-krDsej incxRj']")
	public WebElement SamsclubLogo;
	
	
	@FindBy(xpath="//div[@class='sc-dnqmqq UxYeF']")
	private WebElement ApplicantSubnavhorizontallinesinARPage;
	
	@FindBy(xpath="//p[contains(text(),'Optional')]")
	private WebElement ARMiddlenametext_Optional;


	
	public void Click_ContinueButton() throws Exception{
		try {
			gu.click(click_continueButton);
			logger.info("User clicks on Continue Button");
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+e2.getMessage());
			throw(e2);
		}
	}
	public void EnterfewvalueInArFields(String ApFirstName,String ApMI) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_apFirstName);
			status=gu.WaitForElePresent(input_apFirstName, wait1);
			if (status==true){
  
				gu.entertext(input_apFirstName, ApFirstName);
				//logger.info(" ApFirstName value entered :"+ApFirstName);
				screenshotPath = gu.getScreenshot(driver,ApFirstName,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"ApFirstName value entered: "+ApFirstName + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_apMiddleName, ApMI);
				//logger.info(" ApMI value entered :"+ApMI);
				screenshotPath = gu.getScreenshot(driver,ApMI,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"ApMI value entered : "+ApMI + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}else{
				status=false;
				logger.info("Issue in AR Page");
			}

			Assert.assertTrue(status, "AR PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering ApFirstName,ApMI,APLastName,ApJobTitle"+e1.getMessage());
			System.out.println("Issue with entering ApFirstName,ApMI,APLastName,ApJobTitle ");
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering ApFirstName,ApMI,APLastName,ApJobTitle"+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "AR PAGE");
		logger.info("Issue in Entering AR Fields : ----Status = "+status);
	}

	public void EnterfewmorevalueInArFields(String APLastName) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_apFirstName);
			status=gu.WaitForElePresent(input_apFirstName, wait1);
			if (status==true){
				gu.entertext(input_apLastName, APLastName);
				//logger.info(" APLastName value entered :"+APLastName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"APLastName value entered : "+APLastName + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}else{
				status=false;
				logger.info("Issue in AR Page");
			}

			Assert.assertTrue(status, "AR PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering ApFirstName,ApMI,APLastName,ApJobTitle"+e1.getMessage());
			System.out.println("Issue with entering ApFirstName,ApMI,APLastName,ApJobTitle ");
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering ApFirstName,ApMI,APLastName,ApJobTitle"+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "AR PAGE");
		logger.info("Issue in Entering AR Fields : ----Status = "+status);
	}

	public void EntervalueInArFields(String ApFirstName,String ApMI,String APLastName,String ApJobTitle) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_apFirstName);
			status=gu.WaitForElePresent(input_apFirstName, wait1);
			if (status==true){
				
				gu.entertext(input_apFirstName, ApFirstName);
				//logger.info(" ApFirstName value entered :"+ApFirstName);
				screenshotPath = gu.getScreenshot(driver,ApFirstName,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"ApFirstName value entered: "+ApFirstName + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_apMiddleName, ApMI);
				//logger.info(" ApMI value entered :"+ApMI);
				screenshotPath = gu.getScreenshot(driver,ApMI,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"ApMI value entered : "+ApMI + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_apLastName, APLastName);
				//logger.info(" APLastName value entered :"+APLastName);
				screenshotPath = gu.getScreenshot(driver,APLastName,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"APLastName value entered : "+APLastName + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_apJobTitle, ApJobTitle);
				//logger.info(" ApJobTitle value entered :"+ApJobTitle);
				screenshotPath = gu.getScreenshot(driver,ApJobTitle,1, stepNum++);
				loggerE.log(LogStatus.PASS ," ApJobTitle value entered :"+ApJobTitle + loggerE.addScreenCapture(screenshotPath));

				status=true;
			}else{
				status=false;
				logger.info("Issue in AR Page");
			}

			Assert.assertTrue(status, "AR PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering ApFirstName,ApMI,APLastName,ApJobTitle"+e1.getMessage());
			System.out.println("Issue with entering ApFirstName,ApMI,APLastName,ApJobTitle ");
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering ApFirstName,ApMI,APLastName,ApJobTitle"+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "AR PAGE");
		logger.info("Issue in Entering AR Fields : ----Status = "+status);
	}




	public void ARPage_Elementvalidation(WebDriver driver) throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, input_apFirstName, 10)){
				status=true;
			}else{
				status=false;
			}
		}catch(Exception e){
			e.printStackTrace();
			throw(e);
		}
		Assert.assertTrue(status, "ArPage Filed Validation failed");
	}

	public void navigatedTo_ARPage(WebDriver driver) throws Exception{
		gu.fluientWaitforElementToVisible(driver, input_apFirstName);
		boolean status = false;

		try{
			String urlNew = driver.getCurrentUrl();
			if (urlNew.contains("applicant-ar")){
				logger.info("Navigated to AR page");
				status = true;
				Assert.assertTrue(status, "AR page");
			}else{
				Assert.assertTrue(status, "AR page");

			}

		}catch(Exception e){
			status = false;
			e.printStackTrace();
			logger.info("Not Navigated to AR page"+e.getMessage());
			//throw(e);
		}
		Assert.assertTrue(status, "AR page");
		logger.info("-------AR PAGE-------Navigation Status : "+status);
	}
	
	
	public void validateText(String EnteredText)  throws Exception{
		try {
			String actVal =gu.getEnteredText(input_apMiddleName);
			if(actVal.equals(EnteredText)){
				//Assert.assertEquals(actVal, EnteredText);
				logger.info(" actual = "+EnteredText);
				gu.captureupdateOTR(driver, document, " Previously entered data is retained, user can continue filling the page further ");
				System.out.println("Previously entered data is retained, user can continue filling the page further");
			}
			else
			{
				System.out.println("Previously entered value is erased, user should start filling the page again");
				gu.captureupdateOTR(driver, document, " Previously entered value is erased, user should start filling the page again ");
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
	}
	
	public void EntervaluesinARpage(String ApFirstName,String ApMI,String APLastName,String ApJobTitle,String ApPhoneNumber,String ApEmailAddress) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_apFirstName);
			status=gu.WaitForElePresent(input_apFirstName, wait1);
			if (status==true){

				gu.entertext(input_apFirstName, ApFirstName);
				//logger.info(" ApFirstName value entered :"+ApFirstName);
				screenshotPath = gu.getScreenshot(driver,ApFirstName,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"ApFirstName value entered: "+ApFirstName + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_apMiddleName, ApMI);
				//logger.info(" ApMI value entered :"+ApMI);
				screenshotPath = gu.getScreenshot(driver,ApMI,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"ApMI value entered : "+ApMI + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_apLastName, APLastName);
				//logger.info(" APLastName value entered :"+APLastName);
				screenshotPath = gu.getScreenshot(driver,APLastName,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"APLastName value entered : "+APLastName + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_apJobTitle, ApJobTitle);
				//logger.info(" ApJobTitle value entered :"+ApJobTitle);
				screenshotPath = gu.getScreenshot(driver,ApJobTitle,1, stepNum++);
				loggerE.log(LogStatus.PASS ," ApJobTitle value entered :"+ApJobTitle + loggerE.addScreenCapture(screenshotPath));

				
				gu.entertext(input_apPhoneNumber, ApPhoneNumber);
				screenshotPath = gu.getScreenshot(driver,ApPhoneNumber,1, stepNum++);
				loggerE.log(LogStatus.PASS ," ApPhoneNumber value entered :"+ApPhoneNumber + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_apEmailAddress, ApEmailAddress);
				screenshotPath = gu.getScreenshot(driver,ApEmailAddress,1, stepNum++);
				loggerE.log(LogStatus.PASS ," ApEmailAddress value entered :"+ApEmailAddress + loggerE.addScreenCapture(screenshotPath));

				status=true;
			}else{
				status=false;
				logger.info("Issue in AR Page");
			}

			Assert.assertTrue(status, "AR PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering ApFirstName,ApMI,APLastName,ApJobTitle"+e1.getMessage());
			System.out.println("Issue with entering ApFirstName,ApMI,APLastName,ApJobTitle ");
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering ApFirstName,ApMI,APLastName,ApJobTitle"+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "AR PAGE");
		logger.info("Issue in Entering AR Fields : ----Status = "+status);
	}


	
	public void valiPhoneNumberinAR( )  throws Exception{
		boolean status;
		try {
			
			int ApJobTitle = driver.findElement(By.xpath("//input[@id='businessTitle']")).getLocation().getY();
			int ApPhoneNumber = driver.findElement(By.xpath("//input[@id='homePhone']")).getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
						
			if(ApJobTitle<ApPhoneNumber){

				System.out.println("element are in order");
				status=true;
				gu.pageScrollDownWithEle(driver, input_apPhoneNumber);
				gu.captureupdateOTR(driver, document, " ApPhoneNumber is below ApJobTitle field ");
				//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Elements are not in order");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
		
	}
	
	
	public void valiEmailAddressinAR( )  throws Exception{
		boolean status;
		try {
			
			int ApPhoneNumber = driver.findElement(By.xpath("//input[@id='homePhone']")).getLocation().getY();
			int ApEmailAddress = driver.findElement(By.xpath("//input[@id='applicantEmailAddress']")).getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			if(ApPhoneNumber<ApEmailAddress){

				System.out.println("element are in order");
				status=true;
				gu.pageScrollDownWithEle(driver, input_apEmailAddress);
				gu.captureupdateOTR(driver, document, " ApEmailAddress is below ApPhoneNumber field ");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Elements are not in order");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
		
	}
	
	
	public void validateApplicantSubnavinAR() throws Exception{
		Boolean status=false;
		try {	
			gu.pageScrollDownWithEle(driver, SamsclubLogo);
			if (ApplicantSubnavinARPage.isDisplayed()){
			
				logger.info("ApplicantSubnav is displayed in ARPage ");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				gu.captureupdateOTR(driver, document, "ApplicantSubnav is displayed in ARPage");
			}else{
				status=false;
				System.out.println("ApplicantSubnav is not displayed in ARPage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}
	
	public void validateApplicantSubnavfields(){
		Boolean status=false;
		try{
			gu.pageScrollDownWithEle(driver, SamsclubLogo);
			 Boolean ARsubnav = AuthorizedRepresentative_inSubnav.isDisplayed();
			 Boolean PGsubnav = PersonalGuarantor_inSubnav.isDisplayed(); 
			 Boolean CTsubnav = Controller_inSubnav.isDisplayed();
			 Boolean BOsubnav = BeneficialOwner_inSubnav.isDisplayed();
			 gu.captureupdateOTR(driver, document, "ApplicantSubnav fields AR PG CT BO are displayed in AR page");
			if(ARsubnav&PGsubnav&CTsubnav&BOsubnav){
				logger.info("ApplicantSubnav fields AR PG CT BO are displayed in AR page");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				
			}else{
				status=false;
				System.out.println("ApplicantSubnav fields AR PG CT BO are not displayed in AR page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}
	
	public void validateHorizontallinesofApplicantsubnav() throws Exception{
		Boolean status=false;
		try {	
			gu.pageScrollDownWithEle(driver, SamsclubLogo);
			if (ApplicantSubnavhorizontallinesinARPage.isDisplayed()){
				logger.info("ApplicantSubnav horizontallines are displayed in ARPage ");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				gu.captureupdateOTR(driver, document, "ApplicantSubnav horizontallines are displayed in ARPage");
			}else{
				status=false;
				System.out.println("ApplicantSubnav horizontallines are not displayed in ARPage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}
	

	public void validateHorizontallineWithSectionIconinARpage() throws Exception{
		Boolean status=false;
		try {	
			gu.pageScrollDownWithEle(driver, SamsclubLogo);
			gu.captureupdateOTR(driver, document, "ARHorizontalline with SectionIcon is displayed in ARPage");
			if (ARHorizontallinewithSectionIcon.isDisplayed()){
				logger.info("ARHorizontalline with SectionIcon is displayed in ARPage ");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				
			}else{
				status=false;
				System.out.println("ARHorizontalline with SectionIcon is not displayed in ARPage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}
	
	
	public void validateSecondaryHeadertextinARpage() throws Exception{
		Boolean status=false;
		try {	
			gu.pageScrollDownWithEle(driver, ARHorizontallinewithSectionIcon);
			gu.captureupdateOTR(driver, document, "SecondaryHeadertext is displayed in ARPage");
			if (Text_arAllFieldsAreRequiredText.isDisplayed()){
				logger.info("SecondaryHeader is displayed in ARPage ");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				
			}else{
				status=false;
				System.out.println("SecondaryHeadertext is not displayed in ARPage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}
	
	public void validateAllTextFieldsinARpage(){
		Boolean status=false;
		try{
			 gu.pageScrollDownWithEle(driver, input_apFirstName);
			 gu.captureupdateOTR(driver, document, "All Text Fields are displayed in AR page");
			 Boolean ARFirstname = input_apFirstName.isDisplayed();
			 Boolean ArMiddlename = input_apMiddleName.isDisplayed();
			 Boolean ARlastname = input_apLastName.isDisplayed(); 
			 Boolean ARMembershipnum = Ar_membershipnum.isDisplayed();
			 Boolean Arjobtitle = input_apJobTitle.isDisplayed();
			 Boolean ARphonenum = input_apPhoneNumber.isDisplayed();
			 Boolean ARemail = input_apEmailAddress.isDisplayed();
			 Boolean ARmiddlenametext = ARMiddlenametext_Optional.isDisplayed();
			
			if(ARFirstname&ArMiddlename&ARlastname&ARMembershipnum&Arjobtitle&ARphonenum&ARemail&ARmiddlenametext){
				logger.info("All Text Fields are displayed in AR page ");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				gu.captureupdateOTR(driver, document, "All Text Fields are displayed in AR page");
			}else{
				status=false;
				System.out.println("All Text Fields are not displayed in AR page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}	
	
	public void validateApplicantSubnavfieldsARandPG(){
		Boolean status=false;
		try{
			gu.pageScrollDownWithEle(driver, SamsclubLogo);
			 Boolean ARsubnav = AuthorizedRepresentative_inSubnav.isDisplayed();
			 Boolean PGsubnav = PersonalGuarantor_inSubnav.isDisplayed(); 
			 gu.captureupdateOTR(driver, document, "ApplicantSubnav fields AR PG are displayed in AR page");
			if(ARsubnav&PGsubnav){
				logger.info("ApplicantSubnav fields AR PG are displayed in AR page");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				
			}else{
				status=false;
				System.out.println("ApplicantSubnav fields AR PG are not displayed in AR page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}

	
	public void validateContinuebuttonIsBelowtheEmailadrressfieldinARpage( )  throws Exception{
		boolean status;
		try {
			gu.pageScrollDownWithEle(driver, input_apEmailAddress);
			gu.captureupdateOTR(driver, document, "Continuebutton Is displayed Below the Emailadrress field in ARpage");
			int ApEmailAddress = input_apEmailAddress.getLocation().getY();
			int ARContinuebtn = click_ContinueAppButton.getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			if(ApEmailAddress<ARContinuebtn){
				System.out.println("Continuebutton Is displayed Below the Emailadrress field in ARpage");
				status=true;
				gu.captureupdateOTR(driver, document, "Continuebutton Is displayed Below the Emailadrress field in ARpage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Continuebutton Is not displayed Below the Emailadrress field in ARpage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
		
	}

	
	public void validateTextIsDisplayedbelowtheContinuebuttoninARpage( )  throws Exception{
		boolean status;
		try {
			Thread.sleep(3000);
			gu.captureupdateOTR(driver, document, "Text Is Displayed below the Continue button in ARpage");
			int ARContinuebtn = click_ContinueAppButton.getLocation().getY();
			int ARtextUnder_continuebtn = TextunderContinuebtninAR.getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			if(ARContinuebtn<ARtextUnder_continuebtn){

				System.out.println("Text Is Displayed below the Continue button in ARpage");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Text Is not Displayed below the Continue button in ARpage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
		
	}

	public void validateMainHeadertextinARpage() throws Exception{
		Boolean status=false;
		try {	
			gu.pageScrollDownWithEle(driver, ARHorizontallinewithSectionIcon);
			gu.captureupdateOTR(driver, document, "MainHeader Authorized Representative is displayed in ARPage");
			if (Text_arText.isDisplayed()){
				logger.info("MainHeader Authorized Representative is displayed in ARPage ");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				status=false;
				System.out.println("MainHeader Authorized Representative is not displayed in ARPage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}

	public void validateSubHeaderAlongwithparagraph(){
		Boolean status=false;
		try{
			 gu.pageScrollDownWithEle(driver, ARHorizontallinewithSectionIcon);
			 gu.captureupdateOTR(driver, document, "Sub Header along with paragraph is displayed in AR page");
			 Boolean ARSubheader = Text_arAllFieldsAreRequiredText.isDisplayed();
			 Boolean Arsubheaderpara = ARSubHeaderParagraph.isDisplayed();
		      if(ARSubheader&Arsubheaderpara){
				logger.info("Sub Header along with paragraph is displayed in AR page ");
				status=true;
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				gu.captureupdateOTR(driver, document, "Sub Header along with paragraph is displayed in AR page");
			}else{
				status=false;
				System.out.println("Sub Header along with paragraph is not displayed in AR page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}	

	public void ValidateEmailAddressinfotext(String AREmailAddressinfo) throws Exception{

		boolean status=false;
		try{
			Thread.sleep(2000);
			gu.pageScrollDownWithEle(driver, input_apLastName);
			Thread.sleep(2000);
			gu.click(input_apEmailAddress);
			gu.captureupdateOTR(driver, document, "AREmailAddressinfo is displayed in ARPage");
    		List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{
				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(AREmailAddressinfo))
				{
					status =true;
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					logger.info("AREmailAddressinfo verbiageverified successfully");
					break;
				}
			}
			
		} catch (Exception e) {
			logger.info("Issue with AREmailAddressinfo verbiage");
			logger.info(e.getMessage());
		}
	}

	public void ValidateEmailAddressinfotextdisappeared( ) throws Exception{

		try{
			gu.click(input_apPhoneNumber);
			gu.captureupdateOTR(driver, document, " AREmailAddres verbiage is disappeared in Bipage");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
	        logger.info(" AREmailAddres verbiage is disappered");
		
		} catch (Exception e) {
			logger.info("Issue with AREmailAddres verbiage");
			logger.info(e.getMessage());
		}
	}

	public void ValidateFirstNameinfotext(String ARFirstNameinfo) throws Exception{

		boolean status=false;
		try{
			Thread.sleep(2000);
			gu.pageScrollDownWithEle(driver, Text_arAllFieldsAreRequiredText);
			Thread.sleep(2000);
			gu.click(input_apFirstName);
			gu.captureupdateOTR(driver, document, "ARFirstNameinfo is displayed in ARPage");
    		List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{
				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(ARFirstNameinfo))
				{
					status =true;
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					logger.info("ARFirstNameinfo verbiageverified successfully");
					break;
				}
			}
			
		} catch (Exception e) {
			logger.info("Issue with ARFirstNameinfo verbiage");
			logger.info(e.getMessage());
		}
	}

	public void ValidateFirstNameinfotextdisappeared( ) throws Exception{
		boolean status=false;
		try{
			gu.click(input_apMiddleName);
			gu.captureupdateOTR(driver, document, " ARFirstNameinfo verbiage is disappeared in Bipage");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
	        logger.info(" ARFirstNameinfo verbiage is disappered");
		} catch (Exception e) {
			logger.info("Issue with ARFirstNameinfo verbiage");
			logger.info(e.getMessage());
		}
	}
	
	public void ValidateMembershipNumberinfotext(String ARMembershipNumberinfo) throws Exception{

		boolean status=false;
		try{
			Thread.sleep(2000);
			gu.pageScrollDownWithEle(driver, Text_arAllFieldsAreRequiredText);
			Thread.sleep(2000);
			gu.click(Ar_membershipnum);
			gu.captureupdateOTR(driver, document, "ARMembershipNumberinfo is displayed in ARPage");
			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{
				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(ARMembershipNumberinfo))
				{
					status =true;
					gu.captureupdateOTR(driver, document, "ARMembershipNumberinfo is displayed in ARPage");
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					logger.info("ARMembershipNumberinfo verbiageverified successfully");
					break;
				}
			}
			
		} catch (Exception e) {
			logger.info("Issue with ARMembershipNumberinfo verbiage");
			logger.info(e.getMessage());
		}
	}

	public void ValidateMembershipNumberinfotextdisappeared( ) throws Exception{
		boolean status=false;
		try{
			gu.click(input_apJobTitle);
			gu.captureupdateOTR(driver, document, " ARMembershipNumberinfo verbiage is disappeared in Bipage");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
	        logger.info(" ARMembershipNumberinfo verbiage is disappered");
		} catch (Exception e) {
			logger.info("Issue with ARMembershipNumberinfo verbiage");
			logger.info(e.getMessage());
		}
	}
	
	
	public void ValidatePhoneNumberinfotext(String ARPhoneNumberinfo) throws Exception{

		boolean status=false;
		try{
			Thread.sleep(2000);
			gu.pageScrollDownWithEle(driver, Text_arAllFieldsAreRequiredText);
			Thread.sleep(2000);
			gu.click(input_apPhoneNumber);
			gu.captureupdateOTR(driver, document, "ARPhoneNumberinfo is displayed in ARPage");
			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{
				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(ARPhoneNumberinfo))
				{
					status =true;
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					logger.info("ARPhoneNumberinfo verbiageverified successfully");
					break;
				}
			}
			
		} catch (Exception e) {
			logger.info("Issue with ARPhoneNumberinfo verbiage");
			logger.info(e.getMessage());
		}
	}

	public void ValidatePhoneNumberinfotextdisappeared( ) throws Exception{
		boolean status=false;
		try{
			gu.click(input_apJobTitle);
			gu.captureupdateOTR(driver, document, " ARPhoneNumberinfo verbiage is disappeared in Bipage");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
	        logger.info(" ARPhoneNumberinfo verbiage is disappered");
		} catch (Exception e) {
			logger.info("Issue with ARPhoneNumberinfo verbiage");
			logger.info(e.getMessage());
		}
	}
	
	
}



