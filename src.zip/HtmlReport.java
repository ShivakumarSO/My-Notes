package com.cmlb2bapply.utility;

import java.io.FileInputStream;
import java.io.FileWriter;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class HtmlReport  {
	FileInputStream fis;
	public  void converttohtml (String excelpath, String sheetname ){
		FileInputStream fis;
		Workbook wb;
		try{
			fis = new FileInputStream(excelpath);
			wb = WorkbookFactory.create(fis);
			Sheet sh = wb.getSheet(sheetname);
			int converttohtmlrowcount=sh.getLastRowNum();
			int converttohtmlcolumncount=sh.getRow(0).getLastCellNum();
			StringBuilder htmlBuilder = new StringBuilder();
			//String workingpath=System.getProperty("user.dir");

			htmlBuilder.append("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"> <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /> <title>"+sheetname+"</title></head><body> <table cellpadding=\"1\" cellspacing=\"1\" border=\"1\"><thead><tr><td rowspan=\"1\" colspan=\"7\"> <image src="+"'../Template/Images/seleniumlogo.JPG'"+" align=center>"    +sheetname+ " Execution Report"+"</td></tr></thead><tbody>");
			for (int converttohtmliterrow=0; converttohtmliterrow<=converttohtmlrowcount; converttohtmliterrow++ ){
				htmlBuilder.append("<tr>");
				for(int converttohtmlitercolumn=0;converttohtmlitercolumn<=converttohtmlcolumncount-1;converttohtmlitercolumn++){
					htmlBuilder.append("<td>");
					try{

						if (sh.getRow(converttohtmliterrow).getCell(converttohtmlitercolumn).getStringCellValue().isEmpty()){
							htmlBuilder.append("");
						} else if (sh.getRow(converttohtmliterrow).getCell(converttohtmlitercolumn).getStringCellValue().equalsIgnoreCase("passed")){
							htmlBuilder.append("<image src="+"'../Template/Images/pass.jpg'"+" align=center>");  
						} else if (sh.getRow(converttohtmliterrow).getCell(converttohtmlitercolumn).getStringCellValue().equalsIgnoreCase("failed")){
							htmlBuilder.append("<image src="+"'../Template/Images/fail.jpg'"+" align=center>");
						} else if(sh.getRow(converttohtmliterrow).getCell(converttohtmlitercolumn).getStringCellValue().equalsIgnoreCase("skipped")){
							htmlBuilder.append("<image src="+"'../Template/Images/skipped.jpg'"+" align=center>");
						} else{
							htmlBuilder.append(sh.getRow(converttohtmliterrow).getCell(converttohtmlitercolumn).getStringCellValue());

						}

					}catch(Exception e){
						htmlBuilder.append("<image src="+"'../Template/Images/skipped.jpg'"+" align=center>");
					}
				}       
			}

			System.out.println(excelpath);
			String[] excelnamedetail = excelpath.split(".xls");
			System.out.println(excelnamedetail[0]);
			htmlBuilder.append("</tbody></table></body></html>");
			FileWriter writer = new FileWriter( excelnamedetail[0]+"_"+sheetname+".html");
			writer.write(htmlBuilder.toString());
			writer.close();
			fis.close();
		} catch(Exception e){

			e.printStackTrace();

		}
	}

	public void wait(int time){
		for (int itime=0;itime<=time;itime++){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

