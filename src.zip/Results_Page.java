package com.cmlb2bapply.pageobject;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.LogStatus;

public class Results_Page extends RunnerTest  {


	//Utilities-Object Creation
	//GenericUtilities gu=new GenericUtilities();

	public Results_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	//Terms Page

	@FindBy(xpath="//p[contains(text(),'For applications that require further review, call ')]")
	private WebElement PhoneNoVerbiage;		

	@FindBy(xpath="//p[contains(text(),'Your application reference number is ')]")
	private WebElement Reffer;

	@FindBy(xpath="//*[contains(text(),'Please try again later.')]") 
	private WebElement Error;

	@FindBy(xpath="//*[contains(text(),'Congratulations')]") 
	//@FindBy(xpath = "//*[contains(text(),'You will receive your credit card in the mail within 7-10 business days.')]")
	private WebElement congratulations;

	//@FindBy(xpath="//p[contains(text(),'Your application reference number is ')]")
	@FindBy(xpath="//p[contains(text(),'Your application requires further review. Our team may contact you at the telephone number you provided if additional information or verification is needed.')]")
	private WebElement Refer;

	@FindBy(xpath="//p[contains(text(),'You will receive a decision on your application by mail within 7-10 days.')]") 
	private WebElement Decline;

	@FindBy(xpath="//*[contains(text(),'Thank You.')]")
	private WebElement thankYou;


	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;

	@FindBy(xpath="//p[contains(text(),'Our application service is down during scheduled maintenance.')]")
	public WebElement error_maintainance;
	
	
	@FindBy(xpath="//p[contains(text(),'CONSENT TO ELECTRONIC COMMUNICATIONS')]")
	public WebElement Download_Agreement;

	public void errorpagevalidation(String FinalResults) throws Exception{

		try{

			if(FinalResults.equalsIgnoreCase("error_maintainance")){
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",error_maintainance );
				finalMessageValidation(error_maintainance, FinalResults);
			}
		}
		catch (Exception e) {

			Assert.assertTrue(false);
			// TODO: handle exception
			e.printStackTrace();
			logger.info(FinalResults+ "page not exist and not verfied "+e.getMessage());
		}

	}

	public void navigatedTo_DownloadAgreement(WebDriver driver) throws Exception{
		gu.fluientWaitforElementToVisible(driver, Download_Agreement);
		boolean status = false;

		try{
			String urlNew = driver.getCurrentUrl();
			if (urlNew.contains("eb_tcdoc")){
				logger.info("Navigated to DownloadAgreement page");
				status = true;
				Assert.assertTrue(status, "DownloadAgreement page");
			}else{
				Assert.assertTrue(status, "DownloadAgreement page");

			}

		}catch(Exception e){
			status = false;
			e.printStackTrace();
			logger.info("Not Navigated to DownloadAgreement page"+e.getMessage());
			//throw(e);
		}
		Assert.assertTrue(status, "DownloadAgreement");
		logger.info("-------DownloadAgreement PAGE-------Navigation Status : "+status);
	}


	public void verifyFinalResultsMessages(String FinalResults) throws Exception{

		try {
			Thread.sleep(2000);
			if (FinalResults.equalsIgnoreCase("congratulations")){
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", congratulations);
				finalMessageValidation(congratulations, FinalResults);

			}
			else if (FinalResults.equalsIgnoreCase("Error")){
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Error);
				finalMessageValidation(Error, "Please try again later");

			}
			else if (FinalResults.equalsIgnoreCase("Referred")){
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//p[contains(text(),'Your application reference number is ')]")));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Reffer);
				finalMessageValidation(Reffer, "Your application reference number is");

			}
			else if (FinalResults.equalsIgnoreCase("Decline")){
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Decline);
				finalMessageValidation(Decline, "You will receive a decision on your application by mail within 7-10 days.");

			}  else if (FinalResults.equalsIgnoreCase("Refer")){
				logger.info("Final result message not mentioned please check your future file");
			}


		} catch (Exception e) {
			//Assert.assertEquals("FinalResults", "hjhggjhjhgl");
			Assert.assertTrue(false);
			// TODO: handle exception
			e.printStackTrace();

			logger.info(FinalResults+ "page not exist and not verfied "+e.getMessage());

			//throw(e);
		}

	}

	public void navigatedTo_ResultsPage(WebDriver driver) throws Exception{

		//Thread.sleep(2000);
		boolean status = false;
		try{
			//gu.implictwait(driver, 2000);
			Thread.sleep(1000);

			//gu.fluientWaitforElementToVisible(driver, thankYou);
			String urlNew = driver.getCurrentUrl();		
			if (urlNew.contains("results")){
				logger.info("Navigated to Results  page");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Navigated to Results  page" + loggerE.addScreenCapture(screenshotPath));
				gu.pageScrollDownByPixel(driver);
				//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				//loggerE.log(LogStatus.PASS ," Navigated to Results  page" + loggerE.addScreenCapture(screenshotPath));
				//gu.pageScrollDownByPixel(driver);
				//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Navigated to Results  page" + loggerE.addScreenCapture(screenshotPath));
				status=true;	
			}else{
				logger.info("------Not Navigated to Results  page--------Error Page----Displayed");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.FAIL ," Not Navigated to Results  page" + loggerE.addScreenCapture(screenshotPath));
				status=false;
			}
			Assert.assertTrue(status);
		}catch(Exception e){
			status=false;
			e.printStackTrace();
			logger.info("Not Navigated to Results  page"+e.getMessage());
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.FAIL ," Not Navigated to Results  page" + loggerE.addScreenCapture(screenshotPath));
			//throw(e);
		}
		Assert.assertTrue(status,"-----Result Page-----");
	}
	public static void finalMessageValidation(WebElement ele ,String FinalResults) {
		boolean status = false;
		try {

			String resMess =ele.getText();
			logger.info(resMess);
			status =resMess.toLowerCase().contains(FinalResults.toLowerCase());
			logger.info(status);
			if (status==true){
				status = true;


				logger.info(FinalResults + "  ---page exist and verfied--- "+ resMess);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Result Page:"+resMess + loggerE.addScreenCapture(screenshotPath));
			}

			else{
				status = false;

				logger.info(FinalResults + "--page not exist and not verfied --"+resMess);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.FAIL ," Result Page:"+resMess + loggerE.addScreenCapture(screenshotPath));
			}
			Assert.assertTrue(status, FinalResults);		
		} catch (Exception e) {
			status=false;
			// TODO: handle exception
			e.printStackTrace();
			logger.info(FinalResults + "--page not exist and not verfied --"+e.getMessage());

			loggerE.log(LogStatus.FAIL ," Result Page:"+e.getMessage() + loggerE.addScreenCapture(screenshotPath));
		}
		Assert.assertTrue(status, FinalResults);
	}

	public void scrolldowntoele(String FinalResults) throws Exception{
		try {
			if(FinalResults.equalsIgnoreCase("congratulations")){
				gu.pageScrollDownWithEle(driver,congratulations );
			}
			else if(FinalResults.equalsIgnoreCase("Referred")){
				gu.pageScrollDownWithEle(driver,Refer );
			}
			else if(FinalResults.equalsIgnoreCase("Decline")){
				gu.pageScrollDownWithEle(driver,Decline );
			}
			else if(FinalResults.equalsIgnoreCase("Error")){
				gu.pageScrollDownWithEle(driver,Error );
			}

			logger.info("Scroll down");
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue with Scroll down");
		}
	}
	public void valiPhnNoVerbiage(String arg1) throws Exception{
		boolean status=false;
		try{
			String phNo= PhoneNoVerbiage.getText();
			if(arg1.isEmpty()){		
				//if(checkBox1.isSelected()){

				System.out.println("PhoneNoVerbiage is"+phNo);
				if(phNo.contains(" 1-866-232-7508")){
					gu.pageScrollDownWithEle(driver, PhoneNoVerbiage);
					System.out.println("PhoneNoVerbiage Present");
					//checkBox1.click();
					status=true;
				}
			}else{
				if(phNo.contains("1-844-442-7928")){
					status=true;
					gu.pageScrollDownWithEle(driver, PhoneNoVerbiage);
					System.out.println("PhoneNoVerbiage Present");
					//checkBox1.click();
				}
			}
			//Thread.sleep(2000);
			gu.captureupdateOTR(driver, document, " Phone Number and Verbiage present");		
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			logger.info("Issue in verifying PhoneNoVrebiage... "+e.getMessage());
			status=false;
		}
		Assert.assertTrue(status, "PhoneNoVrebiage");
	}

}

