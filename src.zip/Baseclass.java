package com.cmlb2bapply.step;


import java.io.File;

import org.apache.log4j.Logger;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cmlb2bapply.pageobject.Landing_Page;
import com.cmlb2bapply.utility.ExcelUtility;
import com.cmlb2bapply.utility.GenericUtilities;
import com.cmlb2bapply.utility.HtmlReport;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class Baseclass {

	//WebDriver Initialization
	//Local bsLocal;
	public static ExtentReports extent;
	public static ExtentTest loggerE;
	public static String screenshotPath;
	public static WebDriver driver;
	public static Landing_Page lp;
	public static XWPFDocument document;
	public static HtmlReport hr;
	public static GenericUtilities gu;
	public static ExcelUtility ex;
	public static int Executer=1;
	public final static Logger logger = Logger.getLogger("Log4j");
	public String OTRLocation=System.getProperty("user.dir")+"\\Test-Output\\OTR\\";
	public static WebDriverWait wait;
	public static String ExcelLocation=System.getProperty("user.dir")+"//Test-Output//ExcelOutput//Detailed_Execution_status.xlsx";
	public static String IEDriverPath=System.getProperty("user.dir")+"\\setup\\drivers\\IEDriverServer_Win32_3.8.0\\IEDriverServer.exe";
	public static String ChromeDriverPath=System.getProperty("user.dir")+"\\setup\\drivers\\chromedriver_win32\\chromedriver.exe";
	public static String FirefoxDriverPath=System.getProperty("user.dir")+"\\setup\\drivers\\Firefoxdriver_win64\\geckodriver.exe";
	public static final String ScreenShotLocation =System.getProperty("user.dir")+"//Test-Output//ScreenShots//";
	public static final String reportConfigPath=System.getProperty("user.dir")+"//extent-config.xml//";
	public static JavascriptExecutor js;
	public static String S;
	

	//User have to update Sauce lab details below for Sauce lab execution  

	public static final String USERNAME = "AshaRani"; 
	public static final String ACCESS_KEY = "fb230c47-5b3d-4b66-a31f-873322c0266d";
	public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:443/wd/hub";
	public static final String RealDevice_USERNAME = "asharani";
	public static final String RealDevice_ACCESS_KEY = "B5CD71079DF647ECB52D9B2FEBCBD10C";
	public static final String RealDevice_URL = "https://us1.appium.testobject.com/wd/hub";
	public static final String RealDeviceEu_URL ="https://eu1.appium.testobject.com/wd/hub";
	public static  String RealDeviceScenarioName="";
	public static  String TCNameNew="";
	public static final int wait1 =20;
	public static int stepNum =1;
	public static final String BS_USERNAME = "arunts2";
	public static final String BS_AUTOMATE_KEY = "hzxFw4yZLvEQMmZ2gHxp";
	public static final String BS_URL = "https://" + BS_USERNAME + ":" + BS_AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";

}

