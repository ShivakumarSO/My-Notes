package com.cmlb2bapply.pageobject;

public interface Webdriver {

}
