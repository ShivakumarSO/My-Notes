package com.cmlb2bapply.step;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.Test;


import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.ExcelUtility;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.vimalselvam.cucumber.listener.Reporter;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks extends RunnerTest {




	@Before
	public void cucumberBefore(Scenario scenario){
		
		

		System.out.println("This will run before the Scenario");
		gu =new GenericUtilities();
		document=new XWPFDocument();

		String ScenarioName = scenario.getName();
		String[] ScenarioNameArr = ScenarioName.split("_");
		String TCName = ScenarioNameArr[0];
		gu.createOTR(document, TCName, ScenarioName);
		logger.info("--------------------------------------------------------------------------");
		logger.info(ScenarioName);
		RealDeviceScenarioName=ScenarioName;
		TCNameNew=TCName;
		//extent report setting
		/* int k=1;
		String tdate= gu.CurrentDateAndTime();
		//Extent report will genrate test cases wise
		 //extent = new ExtentReports(System.getProperty("user.dir") +"/Test-Output/Reports/"+ "CML B2B Apply Automation_Execution_Summary_Report_"+ TCName +"_"+ tdate +".html", false);
		// extent = new ExtentReports(System.getProperty("user.dir") +"/Test-Output/Reports/"+ "CML B2B Apply Automation_Execution_Summary_Report_"+ tdate +".html", true);
		 extent = new ExtentReports(System.getProperty("user.dir") +"/Test-Output/Reports/"+ "CML B2B Apply Automation_Execution_Summary_Report" + tdate +".html", true);
	//extent.addSystemInfo("Environment","Environment Name")
	extent
	            .addSystemInfo("Host Name", "BRC/PROX APPLY")
	            .addSystemInfo("Environment", "BRC/PROX Web")
	            .addSystemInfo("User Name", "Arun T S");

	            //loading the external xml file (i.e., extent-config.xml) which was placed under the base directory
	            //You could find the xml file below. Create xml file in your project and copy past the code mentioned below
	            extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
	            loggerE = extent.startTest(scenario.getName() +k);
		  k=k+1;*/
		loggerE = extent.startTest(scenario.getName() );
	}

	@After
	public void cucumberAfter(Scenario scenario) throws IOException, InvalidFormatException{

		System.out.println(scenario.getStatus());
		System.out.println("This will run after the Scenario");

		ex=new ExcelUtility();
		SimpleDateFormat df = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		Date today;
		String reportDate;
		today = Calendar.getInstance().getTime();
		reportDate = df.format(today);
		driver.quit();
		gu =new GenericUtilities();
		gu.updatestatusOTR(document, scenario.getStatus());
		String[] Name=scenario.getName().split(":");
		gu.saveOTR(OTRLocation+Name[0]+"_"+reportDate+".docx", document);
		int Count=ex.getRowCount(ExcelLocation, "Detailed");
		ex.writeStringValueIntoExcel_CreateRow(ExcelLocation, "Detailed", Count, 0, Name[0]);
		ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 1,Name[1]); //scenario.getName()
		ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 2, OTRLocation+Name[0]+"_"+reportDate+".docx");
		ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 3, scenario.getStatus());

		// Steps to Update Suace Lab Results
		String jobName = scenario.getName();
		RunnerTest.UpdateResults(USERNAME, ACCESS_KEY, !scenario.isFailed(), sessionId, jobName);
		System.out.println("SauceOnDemandSessionID="+ sessionId + "job-name="+ jobName);

		// Steps to Update Suace Lab Results for real devices
		// Steps to close extent report


		/*System.out.println(scenario.getStatus());
			extent.endTest(loggerE);
			extent.flush();
			extent.close();*/
		extent.endTest(loggerE);
		driver.quit();

	}	 


}
