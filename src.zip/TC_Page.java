package com.cmlb2bapply.pageobject;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.LogStatus;
public class TC_Page extends RunnerTest  {

	//Utilities-Object Creation
	GenericUtilities gu=new GenericUtilities();

	public TC_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	//Terms Page
	@FindBy(xpath="//button[contains(text(),'Cancel Application')]")
	private WebElement CancelButton;

	//@FindBy(xpath="//button[@data-type='accept-submit']")
	//private WebElement click_AcceptSubmitButton;

	@FindBy(xpath="//*[@id='main']/div[4]/div/form/div/div[2]/button")
	private WebElement click_AcceptSubmitButton;

	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;

	public void click_AcceptSubmitButton () throws Exception{
		try {
			//gu.click(click_AcceptSubmitButton);
			gu.clickButtonByJSWithIndex(driver, 0);//clicking accept and submit button				
			//Thread.sleep(7000);
		gu.WaitForElePresentExplicit(driver, click_AcceptSubmitButton, 30);
		Thread.sleep(3000);
			
			logger.info("User clicks on Continue Button");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," User  clicks on accept and submit Button" + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+ e1.getMessage());
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.FAIL ," User  clicks on accept and submit Button" +e1.getMessage()+ loggerE.addScreenCapture(screenshotPath));
			//throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			//throw(e2);

		}
	}
	public void TCPage_Elementvalidation(WebDriver driver) throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, click_AcceptSubmitButton, 10)){
				status=true;

			}else{

				status=false;
			}
		}catch(Exception e){

			e.printStackTrace();
			//throw(e);
		}
		Assert.assertTrue(status, "Terms and condition Page Filed Validation failed");
	}

	public void navigatedTo_TCPage(WebDriver driver) throws Exception{

		String urlNew = driver.getCurrentUrl();
		try{
			if (urlNew.contains("t-and-c")){
				logger.info("Navigated to Terms and condition  page");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Navigated to Terms and condition  page" + loggerE.addScreenCapture(screenshotPath));
			}
		}catch(Exception e){

			e.printStackTrace();
			logger.info("Not Navigated to Terms and condition  page..."+e.getMessage());
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.FAIL ," Not Navigated to Terms and condition  page" +e.getMessage()+ loggerE.addScreenCapture(screenshotPath));
			//throw(e);
		}

	}


}

