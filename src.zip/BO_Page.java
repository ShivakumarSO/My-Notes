package com.cmlb2bapply.pageobject;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.LogStatus;

public class BO_Page extends RunnerTest  {

	//Utilities-Object Creation
	GenericUtilities gu=new GenericUtilities();

	public BO_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//*[@id='checkInterestOfApplicant']]")
	private WebElement checkbox_AddOneBo;

	@FindBy(xpath="//select[@name='busOwns[0].boType']")
	private WebElement select_boType0;

	@FindBy(xpath="//input[@name='busOwns[0].boFirstname']")
	private WebElement input_boFirstname0;

	@FindBy(xpath="//input[@name='busOwns[0].boMiddleName']")
	private WebElement input_boMiddleName0;

	@FindBy(xpath="//input[@name='busOwns[0].boLastname']")
	private WebElement input_boLastname0;

	@FindBy(xpath="//input[@name='busOwns[0].boHomeaddress']")
	private WebElement input_boHomeaddress0;

	@FindBy(xpath="//input[@name='busOwns[0].boZipcode']")
	private WebElement input_boZipcode0;

	@FindBy(xpath="//input[@name='busOwns[0].boCitystate']")
	private WebElement input_boCitystate0;

	@FindBy(xpath="//input[@name='busOwns[0].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen0;

	@FindBy(xpath="//input[@name='busOwns[0].boSocialnumber']")
	private WebElement input_boSocialnumber0;

	@FindBy(xpath="//input[@name='busOwns[0].boDateOfBirth']")
	private WebElement input_boDateOfBirth0;

	@FindBy(xpath="//input[@name='busOwns[0].boPassportnumber']")
	private WebElement input_boPassportnumber0;

	@FindBy(xpath="//input[@name='busOwns[0].boPassportnumber']")
	private WebElement input_boidentificationDocNo0;

	@FindBy(xpath="//select[@name='busOwns[0].boCountryList']")
	private WebElement select_boCountryList0;

	@FindBy(xpath="//select[@name='busOwns[0].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument0;

	@FindBy(xpath="//input[@name='busOwns[0].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate0;

	@FindBy(xpath="//input[@name='busOwns[0].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate0;

	//@FindBy(xpath="//select[@name='busOwns[1].boType']")
	//private WebElement select_boType1;
	@FindBy (name = "busOwns[1].boType")
	private WebElement select_boType1;

	@FindBy(xpath="//input[@name='busOwns[1].boFirstname']")
	private WebElement input_boFirstname1;

	@FindBy(xpath="//input[@name='busOwns[1].boMiddleName']")
	private WebElement input_boMiddleName1;

	@FindBy(xpath="//input[@name='busOwns[1].boLastname']")
	private WebElement input_boLastname1;

	@FindBy(xpath="//input[@name='busOwns[1].boHomeaddress']")
	private WebElement input_boHomeaddress1;

	@FindBy(xpath="//input[@name='busOwns[1].boZipcode']")
	private WebElement input_boZipcode1;

	@FindBy(xpath="//input[@name='busOwns[1].boCitystate']")
	private WebElement input_boCitystate1;

	@FindBy(xpath="//input[@name='busOwns[1].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen1;

	@FindBy(xpath="//input[@name='busOwns[1].boSocialnumber']")
	private WebElement input_boSocialnumber1;

	@FindBy(xpath="//input[@name='busOwns[1].boDateOfBirth']")
	private WebElement input_boDateOfBirth1;

	@FindBy(xpath="//input[@name='busOwns[1].boPassportnumber']")
	private WebElement input_boPassportnumber1;

	@FindBy(xpath="//select[@name='busOwns[1].boCountryList']")
	private WebElement select_boCountryList1;

	@FindBy(xpath="//select[@name='busOwns[1].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument1;

	@FindBy(xpath="//input[@name='busOwns[1].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate1;

	@FindBy(xpath="//input[@name='busOwns[1].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate1;

	@FindBy(xpath="//select[@name='busOwns[2].boType']")
	//@FindBy(name="busOwns[2].boType")
	private WebElement select_boType2;

	@FindBy(xpath="//input[@name='busOwns[2].boFirstname']")
	private WebElement input_boFirstname2;

	@FindBy(xpath="//input[@name='busOwns[2].boMiddleName']")
	private WebElement input_boMiddleName2;

	@FindBy(xpath="//input[@name='busOwns[2].boLastname']")
	private WebElement input_boLastname2;

	@FindBy(xpath="//input[@name='busOwns[2].boHomeaddress']")
	private WebElement input_boHomeaddress2;

	@FindBy(xpath="//input[@name='busOwns[2].boZipcode']")
	private WebElement input_boZipcode2;

	@FindBy(xpath="//input[@name='busOwns[2].boCitystate']")
	private WebElement input_boCitystate2;

	@FindBy(xpath="//input[@name='busOwns[2].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen2;

	@FindBy(xpath="//input[@name='busOwns[2].boSocialnumber']")
	private WebElement input_boSocialnumber2;

	@FindBy(xpath="//input[@name='busOwns[2].boDateOfBirth']")
	private WebElement input_boDateOfBirth2;

	@FindBy(xpath="//input[@name='busOwns[2].boPassportnumber']")
	private WebElement input_boPassportnumber2;

	@FindBy(xpath="//select[@name='busOwns[2].boCountryList']")
	private WebElement select_boCountryList2;

	@FindBy(xpath="//select[@name='busOwns[2].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument2;

	@FindBy(xpath="//input[@name='busOwns[2].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate2;

	@FindBy(xpath="//input[@name='busOwns[2].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate2;

	//@FindBy(xpath="//select[@name='busOwns[3].boType']")
	@FindBy(name="busOwns[3].boType")
	private WebElement select_boType3;

	@FindBy(xpath="//input[@name='busOwns[3].boFirstname']")
	private WebElement input_boFirstname3;

	@FindBy(xpath="//input[@name='busOwns[3].boMiddleName']")
	private WebElement input_boMiddleName3;

	@FindBy(xpath="//input[@name='busOwns[3].boLastname']")
	private WebElement input_boLastname3;

	@FindBy(xpath="//input[@name='busOwns[3].boHomeaddress']")
	private WebElement input_boHomeaddress3;

	@FindBy(xpath="//input[@name='busOwns[3].boZipcode']")
	private WebElement input_boZipcode3;

	@FindBy(xpath="//input[@name='busOwns[3].boCitystate']")
	private WebElement input_boCitystate3;

	@FindBy(xpath="//input[@name='busOwns[3].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen3;

	@FindBy(xpath="//input[@name='busOwns[3].boSocialnumber']")
	private WebElement input_boSocialnumber3;

	@FindBy(xpath="//input[@name='busOwns[3].boDateOfBirth']")
	private WebElement input_boDateOfBirth3;

	@FindBy(xpath="//input[@name='busOwns[3].boPassportnumber']")
	private WebElement input_boPassportnumber3;

	@FindBy(xpath="//select[@name='busOwns[3].boCountryList']")
	private WebElement select_boCountryList3;

	@FindBy(xpath="//select[@name='busOwns[3].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument3;

	@FindBy(xpath="//input[@name='busOwns[3].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate3;

	@FindBy(xpath="//input[@name='busOwns[3].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate3;

	@FindBy(xpath="//select[@name='busOwns[4].boType']")
	private WebElement select_boType4;

	@FindBy(xpath="//input[@name='busOwns[4].boFirstname']")
	private WebElement input_boFirstname4;

	@FindBy(xpath="//input[@name='busOwns[4].boMiddleName']")
	private WebElement input_boMiddleName4;

	@FindBy(xpath="//input[@name='busOwns[4].boLastname']")
	private WebElement input_boLastname4;

	@FindBy(xpath="//input[@name='busOwns[4].boHomeaddress']")
	private WebElement input_boHomeaddress4;

	@FindBy(xpath="//input[@name='busOwns[4].boZipcode']")
	private WebElement input_boZipcode4;

	@FindBy(xpath="//input[@name='busOwns[4].boCitystate']")
	private WebElement input_boCitystate4;

	@FindBy(xpath="//input[@name='busOwns[4].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen4;

	@FindBy(xpath="//input[@name='busOwns[4].boSocialnumber']")
	private WebElement input_boSocialnumber4;

	@FindBy(xpath="//input[@name='busOwns[4].boDateOfBirth']")
	private WebElement input_boDateOfBirth4;

	@FindBy(xpath="//input[@name='busOwns[4].boPassportnumber']")
	private WebElement input_boPassportnumber4;

	@FindBy(xpath="//select[@name='busOwns[4].boCountryList']")
	private WebElement select_boCountryList4;

	@FindBy(xpath="//select[@name='busOwns[4].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument4;

	@FindBy(xpath="//input[@name='busOwns[4].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate4;

	@FindBy(xpath="//input[@name='busOwns[4].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate4;

	@FindBy(xpath="//*[contains(text(),'Add another Beneficial Owner')]")
	private WebElement link_AddanotherBeneficialOwner;

	@FindBy(xpath="(//span[contains(text(),'Remove')])[1]")
	private WebElement link_RemoveThisPerson1;

	@FindBy(xpath="(//span[contains(text(),'Remove')])[2]")
	private WebElement link_RemoveThisPerson2;

	@FindBy(xpath="(//span[contains(text(),'Remove')])[3]")
	private WebElement link_RemoveThisPerson3;

	@FindBy(xpath="//button[contains(text(),'Continue')]")
	private WebElement click_continueButton;
	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;

	@FindBy(xpath="//span/a[contains(text(), 'complete your exemption status online')]")
	public WebElement click_temsLink;

	public void Click_ContinueButton() throws Exception{
		try {
			gu.click(click_continueButton);

			logger.info("User clicks on Continue Button");
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+ e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			throw(e2);
		}
	}

	public void PGPage_Elementvalidation(WebDriver driver) throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, checkbox_AddOneBo, 10)){
				status=true;
		
			}else{
				status=false;
			}
		}catch(Exception e){

			e.printStackTrace();
			throw(e);
		}
		Assert.assertTrue(status, "PG Page Filed Validation failed");
	}

	public void navigatedTo_BoPage(WebDriver driver) throws Exception{
		Thread.sleep(2000);
		boolean status=false;
		String urlNew = driver.getCurrentUrl();
		try{

			if (urlNew.contains("applicant-bo")){
				logger.info("Navigated to BO page");
				status=true;
			}
			Assert.assertTrue(status, "Navigated to BO page");
		}catch(Exception e){
			status=false;
			e.printStackTrace();
			logger.info("Not Navigated to BO page....."+e.getMessage());
			throw(e);
		}
		Assert.assertTrue(status, "Navigated to BO page");
	}
	public void addOneBO() throws Exception{
		Thread.sleep(2000);
		try {
			//gu.WaitForElePresent(checkbox_AddOneBo, 2000);
			//gu.click(checkbox_AddOneBo);

			//gu.fluientWaitforElementToVisible(driver, checkbox_AddOneBo);	
			gu.clickByJs(driver, "checkInterestOfApplicant");
			//gu.clickCheckboxByXpath(driver, checkbox_AddOneBo);
			logger.info("At least one individual at my organization owns 25% or more of the equity interests of the applicant. check box clicked");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.info("At least one individual at my organization owns 25% or more of the equity interests of the applicant. check box not  clicked"+e.getMessage());
		}
	}
	public void whoWillBeABo(String BeneficialOwner) throws Exception{

		try {
			gu.WaitForElePresent(select_boType0, 1000);
			if(select_boType0.isDisplayed()){
				gu.selectdropdown(select_boType0, "text", BeneficialOwner );
				logger.info("select_boType0 is selected :"+BeneficialOwner);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}
	}

	public void whoWillBeABO(String BeneficialOwner) throws Exception{

		try {
			gu.WaitForElePresent(select_boType0, 1000);
			if(select_boType0.isDisplayed()){
				gu.selectdropdown(select_boType0, "text", BeneficialOwner);
				gu.pageScrollDownWithEle(driver, select_boType0);
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				logger.info("select_boType0 is selected :"+BeneficialOwner);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}
	}
	public void EntervalueInBOFieldsIsUsCitizen0(String BO0,String BOFirstName0, String BOmi0, String BOLastName0,String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0) throws Exception{

		try {
			gu.selectdropdown(select_boType0, "text", BO0 );
			//logger.info("select_boType0 is selected :"+BO0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"select_boType0 is selected :"+BO0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname0, BOFirstName0);
			//logger.info(" BOFirstName value entered :"+BOFirstName0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName0 value entered: "+BOFirstName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName0, BOmi0);
			//logger.info("  BOmi value entered :"+BOmi0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi0 value entered: "+BOmi0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname0, BOLastName0);
			//logger.info(" BOLastName value entered :"+BOLastName0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName0 value entered: "+BOLastName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boHomeaddress0, BOHomeAddress0);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress0 value entered: "+BOHomeAddress0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode0, BOZipCode0);
			//logger.info("  BOZipCode value entered :"+BOZipCode0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode0 value entered: "+BOZipCode0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber0, BOssn0);
			//logger.info("BOssn  value entered :"+ BOssn0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn0 value entered: "+BOssn0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth0, BODob0);
			//logger.info("BODob  value entered :"+ BODob0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob0 value entered: "+BODob0 + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e1.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void EnterfewmorevalueInBOFieldsIsUsCitizen0(String BOHomeAddress0, String BOZipCode0) throws Exception{		
		try {						
			gu.entertext(input_boHomeaddress0, BOHomeAddress0);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress0 value entered: "+BOHomeAddress0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode0, BOZipCode0);
			//logger.info("  BOZipCode value entered :"+BOZipCode0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode0 value entered: "+BOZipCode0 + loggerE.addScreenCapture(screenshotPath));
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e1.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void EnterfewvalueInBOFieldsIsUsCitizen0(String BO0,String BOFirstName0, String BOmi0, String BOLastName0) throws Exception{

		try {
			gu.selectdropdown(select_boType0, "text", BO0 );
			//logger.info("select_boType0 is selected :"+BO0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"select_boType0 is selected :"+BO0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname0, BOFirstName0);
			//logger.info(" BOFirstName value entered :"+BOFirstName0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName0 value entered: "+BOFirstName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName0, BOmi0);
			//logger.info("  BOmi value entered :"+BOmi0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi0 value entered: "+BOmi0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname0, BOLastName0);
			//logger.info(" BOLastName value entered :"+BOLastName0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName0 value entered: "+BOLastName0 + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e1.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void EntervalueInBOFieldsIsNotUsCitizen0(String BO0,String BOFirstName0, String BOmi0, String BOLastName0,String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0,String BOPassportNumber0,String BOCountryOfIDIssunace0,String BOTypeOfIdentification0,String BODocIssueDt0,String BODocExpDt0) throws Exception{

		try {
			gu.selectdropdown(select_boType0, "text", BO0 );
			//logger.info("select_boType0 is selected :"+BO0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO0 value entered: "+BO0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname0, BOFirstName0);
			//logger.info(" BOFirstName value entered :"+BOFirstName0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName0 value entered: "+BOFirstName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName0, BOmi0);
			//logger.info("  BOmi value entered :"+BOmi0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi0 value entered: "+BOmi0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname0, BOLastName0);
			//logger.info(" BOLastName value entered :"+BOLastName0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName0 value entered: "+BOLastName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boHomeaddress0, BOHomeAddress0);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress0 value entered: "+BOHomeAddress0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode0, BOZipCode0);
			//logger.info("  BOZipCode value entered :"+BOZipCode0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode0 value entered: "+BOZipCode0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber0, BOssn0);
			//logger.info("BOssn  value entered :"+ BOssn0);				
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn0 value entered: "+BOssn0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth0, BODob0);
			//logger.info("BODob  value entered :"+ BODob0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob0 value entered: "+BODob0 + loggerE.addScreenCapture(screenshotPath));

			//gu.click(input_boCheckUSCitizen0);
			gu.clickByJs(driver, "busOwns[0].boCheckUSCitizen");
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_boPassportnumber0, BOPassportNumber0);
			//logger.info("BOPassportNumber  value entered :"+ BOPassportNumber0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOPassportNumber0 value entered: "+BOPassportNumber0 + loggerE.addScreenCapture(screenshotPath));

			gu.selectdropdown(select_boCountryList0, "text", BOCountryOfIDIssunace0);
			logger.info("BOCountryOfIDIssunace  value selected  :"+ BOCountryOfIDIssunace0);

			gu.selectdropdown(select_boDescriptiondocument0, "text", BOTypeOfIdentification0);
			//logger.info("BOTypeOfIdentification  value selected :"+ BOTypeOfIdentification0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOTypeOfIdentification0 value entered: "+BOTypeOfIdentification0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentIssueDate0, BODocIssueDt0);
			//logger.info("BODocIssueDt  value entered :"+ BODocIssueDt0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODocIssueDt0 value entered: "+BODocIssueDt0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentExpirationDate0, BODocExpDt0);
			//logger.info("BODocExpDt  value entered :"+ BODocExpDt0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODocExpDt0 value entered: "+BODocExpDt0 + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e1.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void EnterRemainingvaluesInBOFieldsIsNotUsCitizen0(String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0,String BOPassportNumber0,String BOCountryOfIDIssunace0,String BOTypeOfIdentification0,String BODocIssueDt0,String BODocExpDt0) throws Exception{
		try {

			gu.entertext(input_boHomeaddress0, BOHomeAddress0);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress0 value entered: "+BOHomeAddress0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode0, BOZipCode0);
			//logger.info("  BOZipCode value entered :"+BOZipCode0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode0 value entered: "+BOZipCode0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber0, BOssn0);
			//logger.info("BOssn  value entered :"+ BOssn0);				
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn0 value entered: "+BOssn0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth0, BODob0);
			//logger.info("BODob  value entered :"+ BODob0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob0 value entered: "+BODob0 + loggerE.addScreenCapture(screenshotPath));

			//gu.click(input_boCheckUSCitizen0);
			gu.clickByJs(driver, "busOwns[0].boCheckUSCitizen");
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_boPassportnumber0, BOPassportNumber0);
			//logger.info("BOPassportNumber  value entered :"+ BOPassportNumber0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOPassportNumber0 value entered: "+BOPassportNumber0 + loggerE.addScreenCapture(screenshotPath));

			gu.selectdropdown(select_boCountryList0, "text", BOCountryOfIDIssunace0);
			logger.info("BOCountryOfIDIssunace  value selected  :"+ BOCountryOfIDIssunace0);

			gu.selectdropdown(select_boDescriptiondocument0, "text", BOTypeOfIdentification0);
			//logger.info("BOTypeOfIdentification  value selected :"+ BOTypeOfIdentification0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOTypeOfIdentification0 value entered: "+BOTypeOfIdentification0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentIssueDate0, BODocIssueDt0);
			//logger.info("BODocIssueDt  value entered :"+ BODocIssueDt0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODocIssueDt0 value entered: "+BODocIssueDt0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentExpirationDate0, BODocExpDt0);
			//logger.info("BODocExpDt  value entered :"+ BODocExpDt0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODocExpDt0 value entered: "+BODocExpDt0 + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e1.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}

	public void EntervalueInBOFieldsIsUsCitizen1(String BO1,String BOFirstName1, String BOmi1, String BOLastName1,String BOHomeAddress1, String BOZipCode1, String BOssn1, String BODob1) throws Exception{

		try {
			//Thread.sleep(2000);
			gu.selectdropdown(select_boType1, "text", BO1 );
			//logger.info("select_boType1 is selected :"+BO1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO1 value entered: "+BO1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname1, BOFirstName1);
			//logger.info(" BOFirstName value entered :"+BOFirstName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName1 value entered: "+BOFirstName1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName1, BOmi1);
			//logger.info("  BOmi value entered :"+BOmi1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi1 value entered: "+BOmi1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname1, BOLastName1);
			//logger.info(" BOLastName value entered :"+BOLastName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName1 value entered: "+BOLastName1 + loggerE.addScreenCapture(screenshotPath));


			gu.entertext(input_boHomeaddress1, BOHomeAddress1);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress1 value entered: "+BOHomeAddress1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode1, BOZipCode1);
			// logger.info("  BOZipCode value entered :"+BOZipCode1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode1 value entered: "+BOZipCode1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber1, BOssn1);
			//logger.info("BOssn  value entered :"+ BOssn1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn1 value entered: "+BOssn1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth1, BODob1);
			//logger.info("BODob  value entered :"+ BODob1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e1.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}

	public void ValidateBO3HomeaddressVerbiage(String BO3,String BOFirstName3, String BOmi3, String BOLastName3,String BOHomeAddress3, String BOHomeaddressValidation, String BOZipCode3, String BOssn3, String BODob3) throws Exception{

		try {
			gu.selectdropdown(select_boType3, "text", BO3 );
			//logger.info("select_boType3 is selected :"+BO3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO3 value entered: "+BO3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname3, BOFirstName3);
			//logger.info(" BOFirstName value entered :"+BOFirstName3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName3 value entered: "+BOFirstName3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName3, BOmi3);
			//logger.info("  BOmi value entered :"+BOmi3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi3 value entered: "+BOmi3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname3, BOLastName3);
			//logger.info(" BOLastName value entered :"+BOLastName3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName3 value entered: "+BOLastName3 + loggerE.addScreenCapture(screenshotPath));


			gu.click(input_boHomeaddress3);


			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{

				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(BOHomeaddressValidation))
				{
					boolean status =true;
					logger.info("CT homeaddress verbiage verified successfully");
					break;
				}

			}


			//Assert.assertEquals(S, PGHomeaddVerbiage);
			System.out.println("CT homeaddress verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with CT homeaddress verbiage");
			logger.info(e.getMessage());
		}
		gu.entertext(input_boHomeaddress3, BOHomeAddress3);
		//logger.info(" BOHomeAddress value entered :"+BOHomeAddress3);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOHomeAddress3 value entered: "+BOHomeAddress3 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boZipcode3, BOZipCode3);
		//logger.info("  BOZipCode value entered :"+BOZipCode3);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOZipCode3 value entered: "+BOZipCode3 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boSocialnumber3, BOssn3);
		//logger.info("BOssn  value entered :"+ BOssn3);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOssn3 value entered: "+BOssn3 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boDateOfBirth3, BODob3);
		//logger.info("BODob  value entered :"+ BODob3);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BODob3 value entered: "+BODob3 + loggerE.addScreenCapture(screenshotPath));


	} 




	public void ValidateBO2Homeaddress(String BO1,String BOFirstName1, String BOmi1, String BOLastName1,String BOHomeAddress1,String BOHomeaddressValidation, String BOZipCode1, String BOssn1, String BODob1) throws Exception{

		try {
			//Thread.sleep(2000);
			gu.selectdropdown(select_boType1, "text", BO1 );
			//logger.info("select_boType1 is selected :"+BO1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO1 value entered: "+BO1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname1, BOFirstName1);
			//logger.info(" BOFirstName value entered :"+BOFirstName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName1 value entered: "+BOFirstName1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName1, BOmi1);
			//logger.info("  BOmi value entered :"+BOmi1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi1 value entered: "+BOmi1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname1, BOLastName1);
			//logger.info(" BOLastName value entered :"+BOLastName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName1 value entered: "+BOLastName1 + loggerE.addScreenCapture(screenshotPath));

			gu.click(input_boHomeaddress1);


			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{

				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(BOHomeaddressValidation))
				{
					boolean status =true;
					logger.info("CT homeaddress verbiage verified successfully");
					break;
				}

			}


			//Assert.assertEquals(S, PGHomeaddVerbiage);
			System.out.println("CT homeaddress verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with CT homeaddress verbiage");
			logger.info(e.getMessage());
		}

		gu.entertext(input_boHomeaddress1, BOHomeAddress1);
		//logger.info(" BOHomeAddress value entered :"+BOHomeAddress1);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOHomeAddress1 value entered: "+BOHomeAddress1 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boZipcode1, BOZipCode1);
		// logger.info("  BOZipCode value entered :"+BOZipCode1);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOZipCode1 value entered: "+BOZipCode1 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boSocialnumber1, BOssn1);
		//logger.info("BOssn  value entered :"+ BOssn1);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOssn1 value entered: "+BOssn1 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boDateOfBirth1, BODob1);
		//logger.info("BODob  value entered :"+ BODob1);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));
	} 
	//	catch (NoSuchElementException e1) 
	//	 {
	//		e1.printStackTrace();
	//		logger.info("Issue in Entering  bo text fields"+e1.getMessage());
	//		System.out.println("Issue with entering bo text fields");
	//		
	//		logger.info(e1.getMessage());
	//		}
	//	catch (Exception e2) {
	//			e2.printStackTrace();
	//			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
	//			logger.info(e2.getMessage());
	//		}



	public void BOHomeaddressValidation(String BOHomeaddressValidation, String BO0 ) throws Exception{

		boolean status=false;
		try{

			gu.selectdropdown(select_boType0, "text", BO0 );
			gu.click(input_boHomeaddress0);


			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{

				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(BOHomeaddressValidation))
				{
					status =true;
					logger.info("CT homeaddress verbiage verified successfully");
					break;
				}

			}


			//Assert.assertEquals(S, PGHomeaddVerbiage);
			System.out.println("CT homeaddress verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with CT homeaddress verbiage");
			logger.info(e.getMessage());
		}

	}
	public void EnterallvaluesInBO0Fields(String BO0,String BOFirstName0, String BOmi0, String BOLastName0,String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0) throws Exception{

		try {
			//Thread.sleep(2000);
			gu.selectdropdown(select_boType0, "text", BO0 );

			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO0 value entered: "+BO0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname0, BOFirstName0);
			//logger.info(" BOFirstName value entered :"+BOFirstName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName value entered: "+BOFirstName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName0, BOmi0);
			//logger.info("  BOmi value entered :"+BOmi1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi0 value entered: "+BOmi0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname0, BOLastName0);
			//logger.info(" BOLastName value entered :"+BOLastName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName0 value entered: "+BOLastName0 + loggerE.addScreenCapture(screenshotPath));

			// using for validation
			gu.entertext(input_boHomeaddress0, BOHomeAddress0);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress0 value entered: "+BOHomeAddress0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode0, BOZipCode0);
			// logger.info("  BOZipCode value entered :"+BOZipCode1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode0 value entered: "+BOZipCode0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber0, BOssn0);
			//logger.info("BOssn  value entered :"+ BOssn1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn0 value entered: "+BOssn0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth0, BODob0);
			//logger.info("BODob  value entered :"+ BODob1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob0 value entered: "+BODob0 + loggerE.addScreenCapture(screenshotPath));
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e1.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}

	public void ValidateBo3Homepageaddress(String BO2,String BOFirstName2, String BOmi2, String BOLastName2,String BOHomeAddress2, String BOHomeaddressValidation,String BOZipCode2, String BOssn2, String BODob2) throws Exception{

		try {
			gu.selectdropdown(select_boType2, "text", BO2 );
			//logger.info("select_boType2 is selected :"+BO2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO2 value entered: "+BO2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname2, BOFirstName2);
			//logger.info(" BOFirstName value entered :"+BOFirstName2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName2 value entered: "+BOFirstName2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName2, BOmi2);
			//logger.info("  BOmi value entered :"+BOmi2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi2 value entered: "+BOmi2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname2, BOLastName2);
			//logger.info(" BOLastName value entered :"+BOLastName2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName2 value entered: "+BOLastName2 + loggerE.addScreenCapture(screenshotPath));

			gu.click(input_boHomeaddress2);
			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{

				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(BOHomeaddressValidation))
				{
					boolean status = true;
					logger.info("CT homeaddress verbiage verified successfully");
					break;
				}

			}


			//Assert.assertEquals(S, PGHomeaddVerbiage);
			System.out.println("CT homeaddress verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with CT homeaddress verbiage");
			logger.info(e.getMessage());
		}

		gu.entertext(input_boHomeaddress2, BOHomeAddress2);
		//logger.info(" BOHomeAddress value entered :"+BOHomeAddress2);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOHomeAddress2 value entered: "+BOHomeAddress2 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boZipcode2, BOZipCode2);
		//logger.info("  BOZipCode value entered :"+BOZipCode2);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOZipCode2 value entered: "+BOZipCode2 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boSocialnumber2, BOssn2);
		//logger.info("BOssn  value entered :"+ BOssn2);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOssn2 value entered: "+BOssn2 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boDateOfBirth2, BODob2);
		//logger.info("BODob  value entered :"+ BODob2);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BODob2 value entered: "+BODob2 + loggerE.addScreenCapture(screenshotPath));
	} 

	public void ValidateBO0Verbiage(String BO0,String BOFirstName0, String BOmi0, String BOLastName0,String BOHomeAddress0,String BOHomeaddressValidation, String BOZipCode0, String BOssn0, String BODob0) throws Exception{

		try {
			//Thread.sleep(2000);
			gu.selectdropdown(select_boType0, "text", BO0 );

			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO0 value entered: "+BO0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname0, BOFirstName0);
			//logger.info(" BOFirstName value entered :"+BOFirstName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName value entered: "+BOFirstName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName0, BOmi0);
			//logger.info("  BOmi value entered :"+BOmi1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi0 value entered: "+BOmi0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname0, BOLastName0);
			//logger.info(" BOLastName value entered :"+BOLastName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName0 value entered: "+BOLastName0 + loggerE.addScreenCapture(screenshotPath));

			// using for validation
			gu.click(input_boHomeaddress0);
			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{

				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(BOHomeaddressValidation))
				{
					boolean status = true;
					logger.info("CT homeaddress verbiage verified successfully");
					break;
				}

			}


			//Assert.assertEquals(S, PGHomeaddVerbiage);
			System.out.println("CT homeaddress verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with CT homeaddress verbiage");
			logger.info(e.getMessage());
		}

		gu.entertext(input_boHomeaddress0, BOHomeAddress0);
		//logger.info(" BOHomeAddress value entered :"+BOHomeAddress1);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOHomeAddress0 value entered: "+BOHomeAddress0 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boZipcode0, BOZipCode0);
		// logger.info("  BOZipCode value entered :"+BOZipCode1);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOZipCode0 value entered: "+BOZipCode0 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boSocialnumber0, BOssn0);
		//logger.info("BOssn  value entered :"+ BOssn1);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BOssn0 value entered: "+BOssn0 + loggerE.addScreenCapture(screenshotPath));

		gu.entertext(input_boDateOfBirth0, BODob0);
		//logger.info("BODob  value entered :"+ BODob1);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		loggerE.log(LogStatus.PASS ,"BODob0 value entered: "+BODob0 + loggerE.addScreenCapture(screenshotPath));
	} 
	//	catch(NoSuchElementException e1) 
	//	 {
	//		e1.printStackTrace();
	//		logger.info("Issue in Entering  bo text fields"+e1.getMessage());
	//		System.out.println("Issue with entering bo text fields");
	//		
	//		logger.info(e1.getMessage());
	//		}
	//	catch (Exception e2) {
	//			e2.printStackTrace();
	//			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
	//			logger.info(e2.getMessage());
	//		}
	//   

	public void EntervalueInBObydefaultcheckUScitizen(String BOFirstName0, String BOmi0, String BOLastName0,String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0) throws Exception{

		try {
			//Thread.sleep(2000);
			
			gu.entertext(input_boFirstname0, BOFirstName0);
			gu.pageScrollDownWithEle(driver, input_boFirstname0);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
			//logger.info(" BOFirstName value entered :"+BOFirstName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName value entered: "+BOFirstName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName0, BOmi0);
			//logger.info("  BOmi value entered :"+BOmi1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi0 value entered: "+BOmi0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname0, BOLastName0);
			//logger.info(" BOLastName value entered :"+BOLastName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName0 value entered: "+BOLastName0 + loggerE.addScreenCapture(screenshotPath));

			gu.pageScrollDownWithEle(driver, input_boHomeaddress0);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
			gu.entertext(input_boHomeaddress0, BOHomeAddress0);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress0 value entered: "+BOHomeAddress0 + loggerE.addScreenCapture(screenshotPath));
			gu.pageScrollDownByPixel(driver);
			
			
			gu.entertext(input_boZipcode0, BOZipCode0);
			// logger.info("  BOZipCode value entered :"+BOZipCode1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode0 value entered: "+BOZipCode0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber0, BOssn0);
			//logger.info("BOssn  value entered :"+ BOssn1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn0 value entered: "+BOssn0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth0, BODob0);
			gu.pageScrollDownWithEle(driver, input_boDateOfBirth0);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
			//logger.info("BODob  value entered :"+ BODob1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob0 value entered: "+BODob0 + loggerE.addScreenCapture(screenshotPath));
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  BO text fields"+e1.getMessage());
			System.out.println("Issue with entering BO text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  BO text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}


	public void EntervalueInBOFieldsIsNotUsCitizen1(String BO1,String BOFirstName1, String BOmi1, String BOLastName1,String BOHomeAddress1, String BOZipCode1, String BOssn1, String BODob1,String BOPassportNumber1,String BOCountryOfIDIssunace1,String BOTypeOfIdentification1,String BODocIssueDt1,String BODocExpDt1) throws Exception{

		try {
			gu.selectdropdown(select_boType1, "text", BO1 );
			//logger.info("select_boType1 is selected :"+BO1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname1, BOFirstName1);
			//logger.info(" BOFirstName value entered :"+BOFirstName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName1, BOmi1);
			//logger.info("  BOmi value entered :"+BOmi1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname1, BOLastName1);
			//logger.info(" BOLastName value entered :"+BOLastName1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boHomeaddress1, BOHomeAddress1);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode1, BOZipCode1);
			//logger.info("  BOZipCode value entered :"+BOZipCode1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber1, BOssn1);
			//logger.info("BOssn  value entered :"+ BOssn1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth1, BODob1);
			//logger.info("BODob  value entered :"+ BODob1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			//gu.click(input_boCheckUSCitizen1);
			gu.clickByJs(driver, "busOwns[1].boCheckUSCitizen");
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_boPassportnumber1, BOPassportNumber1);
			//logger.info("BOPassportNumber  value entered :"+ BOPassportNumber1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.selectdropdown(select_boCountryList1, "text", BOCountryOfIDIssunace1);
			logger.info("BOCountryOfIDIssunace  value selected  :"+ BOCountryOfIDIssunace1);

			gu.selectdropdown(select_boDescriptiondocument1, "text", BOTypeOfIdentification1);
			//logger.info("BOTypeOfIdentification  value selected :"+ BOTypeOfIdentification1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentIssueDate1, BODocIssueDt1);
			//logger.info("BODocIssueDt  value entered :"+ BODocIssueDt1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentExpirationDate1, BODocExpDt1);
			//logger.info("BODocExpDt  value entered :"+ BODocExpDt1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob1 value entered: "+BODob1 + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e1.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}


	public void EntervalueInBOFieldsIsUsCitizen2(String BO2,String BOFirstName2, String BOmi2, String BOLastName2,String BOHomeAddress2, String BOZipCode2, String BOssn2, String BODob2) throws Exception{

		try {
			gu.selectdropdown(select_boType2, "text", BO2 );
			//logger.info("select_boType2 is selected :"+BO2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO2 value entered: "+BO2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname2, BOFirstName2);
			//logger.info(" BOFirstName value entered :"+BOFirstName2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName2 value entered: "+BOFirstName2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName2, BOmi2);
			//logger.info("  BOmi value entered :"+BOmi2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi2 value entered: "+BOmi2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname2, BOLastName2);
			//logger.info(" BOLastName value entered :"+BOLastName2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName2 value entered: "+BOLastName2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boHomeaddress2, BOHomeAddress2);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress2 value entered: "+BOHomeAddress2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode2, BOZipCode2);
			//logger.info("  BOZipCode value entered :"+BOZipCode2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode2 value entered: "+BOZipCode2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber2, BOssn2);
			//logger.info("BOssn  value entered :"+ BOssn2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn2 value entered: "+BOssn2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth2, BODob2);
			//logger.info("BODob  value entered :"+ BODob2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob2 value entered: "+BODob2 + loggerE.addScreenCapture(screenshotPath));
		} 
		catch (NoSuchElementException e2) 
		{
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e2.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void EntervalueInBOFieldsIsNotUsCitizen2(String BO2,String BOFirstName2, String BOmi2, String BOLastName2,String BOHomeAddress2, String BOZipCode2, String BOssn2, String BODob2,String BOPassportNumber2,String BOCountryOfIDIssunace2,String BOTypeOfIdentification2,String BODocIssueDt2,String BODocExpDt2) throws Exception{

		try {
			gu.selectdropdown(select_boType2, "text", BO2 );
			//logger.info("select_boType2 is selected :"+BO2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO2 value entered: "+BO2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname2, BOFirstName2);
			//logger.info(" BOFirstName value entered :"+BOFirstName2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName2 value entered: "+BOFirstName2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName2, BOmi2);
			//logger.info("  BOmi value entered :"+BOmi2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi2 value entered: "+BOmi2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname2, BOLastName2);
			//logger.info(" BOLastName value entered :"+BOLastName2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName2 value entered: "+BOLastName2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boHomeaddress2, BOHomeAddress2);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress2 value entered: "+BOHomeAddress2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode2, BOZipCode2);
			//logger.info("  BOZipCode value entered :"+BOZipCode2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode2 value entered: "+BOZipCode2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber2, BOssn2);
			//logger.info("BOssn  value entered :"+ BOssn2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn2 value entered: "+BOssn2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth2, BODob2);
			//logger.info("BODob  value entered :"+ BODob2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob2 value entered: "+BODob2 + loggerE.addScreenCapture(screenshotPath));

			//gu.click(input_boCheckUSCitizen2);
			gu.clickByJs(driver, "busOwns[2].boCheckUSCitizen");
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_boPassportnumber2, BOPassportNumber2);
			//logger.info("BOPassportNumber  value entered :"+ BOPassportNumber2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOPassportNumber2 value entered: "+BOPassportNumber2 + loggerE.addScreenCapture(screenshotPath));

			gu.selectdropdown(select_boCountryList2, "text", BOCountryOfIDIssunace2);
			logger.info("BOCountryOfIDIssunace  value selected  :"+ BOCountryOfIDIssunace2);

			gu.selectdropdown(select_boDescriptiondocument2, "text", BOTypeOfIdentification2);
			//logger.info("BOTypeOfIdentification  value selected :"+ BOTypeOfIdentification2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOTypeOfIdentification2 value entered: "+BOTypeOfIdentification2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentIssueDate2, BODocIssueDt2);
			//logger.info("BODocIssueDt  value entered :"+ BODocIssueDt2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODocIssueDt2 value entered: "+BODocIssueDt2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentExpirationDate2, BODocExpDt2);
			//logger.info("BODocExpDt  value entered :"+ BODocExpDt2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODocExpDt2 value entered: "+BODocExpDt2 + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e2) 
		{
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e2.getMessage());
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e2.getMessage());
			logger.info(e2.getMessage());
		}
	}
	public void EntervalueInBOFieldsIsUsCitizen3(String BO3,String BOFirstName3, String BOmi3, String BOLastName3,String BOHomeAddress3, String BOZipCode3, String BOssn3, String BODob3) throws Exception{

		try {
			gu.selectdropdown(select_boType3, "text", BO3 );
			//logger.info("select_boType3 is selected :"+BO3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO3 value entered: "+BO3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname3, BOFirstName3);
			//logger.info(" BOFirstName value entered :"+BOFirstName3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName3 value entered: "+BOFirstName3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName3, BOmi3);
			//logger.info("  BOmi value entered :"+BOmi3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi3 value entered: "+BOmi3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname3, BOLastName3);
			//logger.info(" BOLastName value entered :"+BOLastName3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName3 value entered: "+BOLastName3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boHomeaddress3, BOHomeAddress3);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress3 value entered: "+BOHomeAddress3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode3, BOZipCode3);
			//logger.info("  BOZipCode value entered :"+BOZipCode3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode3 value entered: "+BOZipCode3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber3, BOssn3);
			//logger.info("BOssn  value entered :"+ BOssn3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn3 value entered: "+BOssn3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth3, BODob3);
			//logger.info("BODob  value entered :"+ BODob3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob3 value entered: "+BODob3 + loggerE.addScreenCapture(screenshotPath));


		} 
		catch (NoSuchElementException e3) 
		{
			e3.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e3.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e3.getMessage());
		}
		catch (Exception e3) {
			e3.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e3.getMessage());
			logger.info(e3.getMessage());
		}
	}
	public void EntervalueInBOFieldsIsNotUsCitizen3(String BO3,String BOFirstName3, String BOmi3, String BOLastName3,String BOHomeAddress3, String BOZipCode3, String BOssn3, String BODob3,String BOPassportNumber3,String BOCountryOfIDIssunace3,String BOTypeOfIdentification3,String BODocIssueDt3,String BODocExpDt3) throws Exception{

		try {
			gu.selectdropdown(select_boType3, "text", BO3 );
			//logger.info("select_boType3 is selected :"+BO3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BO3 value entered: "+BO3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boFirstname3, BOFirstName3);
			//logger.info(" BOFirstName value entered :"+BOFirstName3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOFirstName3 value entered: "+BOFirstName3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boMiddleName3, BOmi3);
			//logger.info("  BOmi value entered :"+BOmi3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOmi3 value entered: "+BOmi3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boLastname3, BOLastName3);
			//logger.info(" BOLastName value entered :"+BOLastName3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOLastName3 value entered: "+BOLastName3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boHomeaddress3, BOHomeAddress3);
			//logger.info(" BOHomeAddress value entered :"+BOHomeAddress3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOHomeAddress3 value entered: "+BOHomeAddress3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boZipcode3, BOZipCode3);
			//logger.info("  BOZipCode value entered :"+BOZipCode3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOZipCode3 value entered: "+BOZipCode3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boSocialnumber3, BOssn3);
			//logger.info("BOssn  value entered :"+ BOssn3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOssn3 value entered: "+BOssn3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDateOfBirth3, BODob3);
			//logger.info("BODob  value entered :"+ BODob3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODob3 value entered: "+BODob3 + loggerE.addScreenCapture(screenshotPath));

			//gu.click(input_boCheckUSCitizen3);
			gu.clickByJs(driver, "busOwns[3].boCheckUSCitizen");
			logger.info("This individual is a not US Citizen and clicked on check box:");

			gu.entertext(input_boPassportnumber3, BOPassportNumber3);
			//logger.info("BOPassportNumber  value entered :"+ BOPassportNumber3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOPassportNumber3 value entered: "+BOPassportNumber3 + loggerE.addScreenCapture(screenshotPath));

			gu.selectdropdown(select_boCountryList3, "text", BOCountryOfIDIssunace3);
			logger.info("BOCountryOfIDIssunace  value selected  :"+ BOCountryOfIDIssunace3);

			gu.selectdropdown(select_boDescriptiondocument3, "text", BOTypeOfIdentification3);
			//logger.info("BOTypeOfIdentification  value selected :"+ BOTypeOfIdentification3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BOTypeOfIdentification3 value entered: "+BOTypeOfIdentification3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentIssueDate3, BODocIssueDt3);
			//logger.info("BODocIssueDt  value entered :"+ BODocIssueDt3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODocIssueDt3 value entered: "+BODocIssueDt3 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_boDocumentExpirationDate3, BODocExpDt3);
			//logger.info("BODocExpDt  value entered :"+ BODocExpDt3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BODocExpDt3 value entered: "+BODocExpDt3 + loggerE.addScreenCapture(screenshotPath));

		} 
		catch (NoSuchElementException e3) 
		{
			e3.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e3.getMessage());
			System.out.println("Issue with entering bo text fields");

			logger.info(e3.getMessage());
		}
		catch (Exception e3) {
			e3.printStackTrace();
			logger.info("Issue in Entering  bo text fields"+e3.getMessage());
			logger.info(e3.getMessage());
		}
	}
	public void addAnotherBO()throws Exception{
		try {
			if(link_AddanotherBeneficialOwner.isDisplayed()){
				gu.click(link_AddanotherBeneficialOwner);
				//WebElement nameInputField = driver.findElement(By.xpath("//*[@id='main']/div[3]/div/div[2]/form/div[1]/div[2]/div[*]/div/span/span"));
				WebElement nameInputField = driver.findElement(By.xpath("//*[text()='Add another Beneficial Owner']"));
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", nameInputField);
				logger.info("clicked on Add another bo link");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Not clicked on Add another bo link"+e.getMessage());
		}

	}
	public void clickTemsLinkAndVerifyNewTab()throws Exception{
		try {
			Thread.sleep(3000);
			if(click_temsLink.isDisplayed()){
				//gu.click(click_temsLink);
				driver.findElement(By.xpath("//a[contains(.,'complete your exemption status online')]")).click();
			}

			ArrayList tabs = new ArrayList (driver.getWindowHandles());
			System.out.println(tabs.size());
			driver.switchTo().window((String) tabs.get(1));
			try {
				if(driver.findElement(By.xpath("//h1[contains(.,'Tax-Exempt Management System')]")).isDisplayed()){
					logger.info("clicked on TEMS link and navigated to TEMS page");
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ,"Tax-Exempt Management System: " + loggerE.addScreenCapture(screenshotPath));

				}else{
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.FAIL ,"Not navigated to Tax-Exempt Management System : " + loggerE.addScreenCapture(screenshotPath));

				}
			} catch (Exception e) {
				logger.info("navigated to different page"+e.getMessage());

			}

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Not clicked on Add another bo link"+e.getMessage());
		}
	}
	public void VerifyTemsLink()throws Exception{
		int flag=0;
		try {
			List <WebElement> list = driver.findElements(By.tagName("a"));
			System.out.println("Number of links: "+list.size());
			for(int i = 0; i < list.size(); i++){
				System.out.println(list.get(i).getText());
				if((list.get(i).getText().equals("complete your exemption status online"))){
					loggerE.log(LogStatus.FAIL ," TEMS Link is getting displayed for mPos" + loggerE.addScreenCapture(screenshotPath));
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					flag=1;	
				}
			}
			if(flag==0){
				loggerE.log(LogStatus.PASS ," TEMS Link is not getting displayed for mPos" + loggerE.addScreenCapture(screenshotPath));
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				logger.info("TEMs link not displayed");
			}

		}
		catch (Exception e) {
			logger.info("TEMs link displayed"+e.getMessage());
		}
	}
	/*try {


				/*try {
					if(driver.findElement(By.xpath("//h1[contains(.,'Tax-Exempt Management System')]")).isDisplayed()){
						logger.info("clicked on TEMS link and navigated to TEMS page");
							screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
							loggerE.log(LogStatus.PASS ,"Tax-Exempt Management System: " + loggerE.addScreenCapture(screenshotPath));

							}else{
							screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
							loggerE.log(LogStatus.FAIL ,"Not navigated to Tax-Exempt Management System : " + loggerE.addScreenCapture(screenshotPath));

							}
				} catch (Exception e) {
					logger.info("navigated to different page");
				}

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Not clicked on Add another bo link"+e.getMessage());
		}
		}*/
	public void validateLabelinbopage(String labelname)  throws Exception{
		try {
			String actVal =gu.getlabel(input_boPassportnumber0);
			Assert.assertEquals(actVal, labelname);
			System.out.println("Label name verified successfully in BO Page");
		} catch (Exception e) {
			logger.info(e.getMessage());
		}

	}


	public void scrolldowntoeleinbopage() throws Exception{
		try {
			gu.pageScrollDownWithEle(driver, input_boDateOfBirth0);
			logger.info("Scroll down");
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue with Scroll down");
		}
	}
	public void Click_UsCitizenCheckbox() throws Exception{
		try {
			gu.click(input_boCheckUSCitizen0);
			Thread.sleep(1000);
			logger.info("User clicks on US Citizen checkbox");
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking US Citizen checkbox"+ e1.getMessage());
			throw(e1);
		}
	}
	public void Click_UsCitizenCheckbox1() throws Exception{
		try {
			gu.click(input_boCheckUSCitizen1);
			Thread.sleep(1000);
			logger.info("User clicks on US Citizen checkbox");

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking US Citizen checkbox"+ e1.getMessage());
			throw(e1);
		}
	}
	public void Click_UsCitizenCheckbox2() throws Exception{
		try {
			gu.click(input_boCheckUSCitizen2);
			Thread.sleep(1000);
			logger.info("User clicks on US Citizen checkbox");

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking US Citizen checkbox"+ e1.getMessage());
			throw(e1);
		}
	}
	public void Click_UsCitizenCheckbox3() throws Exception{
		try {
			gu.click(input_boCheckUSCitizen3);
			Thread.sleep(1000);
			logger.info("User clicks on US Citizen checkbox");

		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking US Citizen checkbox"+ e1.getMessage());
			throw(e1);
		}
	}
	public void validateText(String EnteredText)  throws Exception{
		try {
			String actVal =gu.getEnteredText(input_boLastname0);
			if(actVal.equals(EnteredText)){
				//Assert.assertEquals(actVal, EnteredText);
				logger.info(" actual = "+EnteredText);
				gu.captureupdateOTR(driver, document, " Previously entered data is retained, user can continue filling the page further ");
				System.out.println("Previously entered data is retained, user can continue filling the page further");
			}
			else
			{
				System.out.println("Previously entered value is erased, user should start filling the page again");
				gu.captureupdateOTR(driver, document, " Previously entered value is erased, user should start filling the page again ");
			}
		} catch (Exception e) {
			logger.info(e.getMessage());

		}
	}
	public void validateLabel(String labelname)  throws Exception{
		try {
			String actVal =gu.getlabel(input_boidentificationDocNo0);
			Assert.assertEquals(actVal, labelname);
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
	}
}


