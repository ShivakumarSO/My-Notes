package com.cmlb2bapply.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;


import java.util.List;

import javax.sound.sampled.ReverbType;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



import com.cmlb2bapply.runner.RunnerTest;

import net.bytebuddy.asm.Advice.OffsetMapping.ForArgument;
import net.bytebuddy.dynamic.scaffold.MethodRegistry.Handler.ForAbstractMethod;

public class Mainclass extends RunnerTest{



	public static void main(String[] args) throws AWTException {
		System.setProperty("webdriver.chrome.driver",ChromeDriverPath);
		//swapno(15,20);
		//reverseStringa("arunkumar")	;
		WebDriver driver=new ChromeDriver();
		driver.get("https://qbusinessapply.syf.com/cmlapply/ca/lowes/business-info");
		driver.findElement(By.xpath("//a[contains(.,'complete your exemption status online')]")).click();

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		WebElement zipcode=driver.findElement(By.name("companyzipCode"));
		((JavascriptExecutor) driver).executeScript("arguments[0].value = '10101';",zipcode);



		//driver.navigate().to(currentUrl); 
		//ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		//System.out.println("No. of tabs: " + tabs.size());

		//findlen("arunkumar");

		/*String str = "arun123arun678";      
		 * 
		str = str.replaceAll("[^0-9]+", " ");
		System.out.println(Arrays.asList(str.trim().split(" ")));*/
		//System.out.println("ToolsQA");

	}
	public static String swapno  (int x, int y){

		x = x+y ;
		y=x-y;
		x=x-y;
		System.out.println("x="+x+"y="+y);
		String a = ("x="+x+"y="+y);
		return a;
	}
	public static void reverseStringa(String val){

		String input = val;

		// convert String to character array 
		// by using toCharArray 
		char[] try1 = input.toCharArray(); 
		System.out.println(try1.length);
		for (int i = try1.length-1; i>=0; i--) 
			System.out.print(try1[i]); 



	}
	public static void findlen(String val){
		int count =0;
		for (char c:val.toCharArray()){
			count++;
		}
		System.out.println("total lenght is "+count);

	}
	public static void gratestnumber(int x,int y, int z){


	}

}

