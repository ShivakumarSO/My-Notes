package com.cmlb2bapply.step;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.AssertJUnit;

import com.cmlb2bapply.pageobject.*;


import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MposBrcApplystep extends RunnerTest {
	@SuppressWarnings("deprecation")
	public Landing_Page lp;
	public BusinessInfo_Page bi;
	public AR_Page ar;
	public PG_Page pg;
	public CT_Page ct;
	public BO_Page bo;
	public Options_Page op;
	public TC_Page tc;
	public Results_Page res;



	@Given("^Launch the browser \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and navigate to mposbrc web \"([^\"]*)\"$")
	public void launch_the_browser_and_navigate_to_mposbrc_web(String Cloud_Execution, String Browser, String Browser_version, String Platform, String URL) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try{
			logger.info("Intiated Browser launch activity");
			launch_browser(Cloud_Execution,Platform,Browser,Browser_version);
			logger.info("Browser Launch is success ");
			Navigateto(URL);
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			gu.pageScrollDownByPixel(driver);
			gu.captureupdateOTR(driver, document, "Landing Page");
			//logger.info("Navigated to mpos brc landing page"); 
		}catch (Exception e) {
			System.out.println("Issue with landing Page");
			gu.captureupdateOTR(driver, document, "Issue with landing Page");
			logger.info("issue with mpos brc landing page"); 
		}

	}
	@Given("^Launch the browser \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and navigate to mposprox web \"([^\"]*)\"$")
	public void launch_the_browser_and_navigate_to_mposprox_web(String Cloud_Execution, String Browser, String Browser_version, String Platform, String URL) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try{
			logger.info("Intiated Browser launch activity");
			launch_browser(Cloud_Execution,Platform,Browser,Browser_version);
			logger.info("Browser Launch is success ");
			Navigateto(URL);
			driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
			gu.captureupdateOTR(driver, document, "Landing Page");
			//logger.info("Navigated to mpos prox landing page"); 
		}catch (Exception e) {
			System.out.println("Issue with BI Page");
			//gu.captureupdateOTR(driver, document, "Issue with landing Page");
			//logger.info("issue with mpos brc landing page"); 
		}

	}
	@Given("^Launch the browser \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and navigate to dapplybrc web \"([^\"]*)\"$")
	public void launch_the_browser_and_navigate_to_dapplybrc_web(String Cloud_Execution, String Browser, String Browser_version, String Platform, String URL) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try{
			logger.info("Intiated Browser launch activity");
			launch_browser(Cloud_Execution,Platform,Browser,Browser_version);
			logger.info("Browser Launch is success ");
			Navigateto(URL);
			driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
			gu.captureupdateOTR(driver, document, "Business info Page");
			logger.info("Navigated to dapply brc Business info Page"); 
		}catch (Exception e) {
			System.out.println("Issue with Business info Page");
			gu.captureupdateOTR(driver, document, "Issue with Business info Page");
			logger.info("Issue with  Business info Page"); 
		}

	}
	@Given("^Launch the browser \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and navigate to dapplyprox web \"([^\"]*)\"$")
	public void launch_the_browser_and_navigate_to_dapplyprox_web(String Cloud_Execution, String Browser, String Browser_version, String Platform, String URL) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try{
			logger.info("Intiated Browser launch activity");
			launch_browser(Cloud_Execution,Platform,Browser,Browser_version);
			logger.info("Browser Launch is success ");
			Navigateto(URL);
			driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
			gu.captureupdateOTR(driver, document, "Business info Page");
			logger.info("Navigated to dapply prox Business info Page"); 
		}catch (Exception e) {
			System.out.println("Issue with Business info Page");
			gu.captureupdateOTR(driver, document, "Issue with Business info Page");
			logger.info("Issue with  Business info Page"); 
		}

	}


	@When("^clicks on continueAppButton in timeout popup$")
	public void clicks_on_continueAppButton_in_timeout_popup() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		//Thread.sleep(1000*60*10);
		bi.Click_ContinueButton();
		gu.captureupdateOTR(driver, document, " clicks on continue button in popup and return to bi page ");  
		//bi.Click_ContinueButton();
	}
	@Then("^Verify previously entered data retained or not \"([^\"]*)\"$")
	public void verify_previously_entered_data_retained_or_not(String EnteredText) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		bi=new BusinessInfo_Page(driver);
		bi.validateText(EnteredText);

	}

	@When("^User enters remaining fields in bi page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_remaining_fields_in_bi_page(String ZipCode, String BusinessPhone, String Ext, String EmailAddress, String TaxPayerId, String NumberOfEmployes, String YearEstablished, String AnnualRevenue, String RequestedCreditLine) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {

			//Thread.sleep(2000);
			//Thread.sleep(2000);
			bi=new BusinessInfo_Page(driver);
			bi.EnterrestvalueInBiFields( ZipCode,BusinessPhone, Ext, EmailAddress, TaxPayerId, NumberOfEmployes, YearEstablished, AnnualRevenue, RequestedCreditLine);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");     
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());

		}
	}
	@When("^user enter few fields in pg page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_few_fields_in_pg_page(String PgHomeAddress, String PgZipCode, String PgEmailAddress, String PgPersonalPhone) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pg =new PG_Page(driver);
		pg.EnterfewvaluesInPGField(PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone);

		gu.captureupdateOTR(driver, document, " Entered PG page field values");     

	}
	@When("^user should enter the remaining fields \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_should_enter_the_remaining_fields(String PgPersonalPhone, String PgSsn, String PgDob, String PgAnuualNetIncome) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pg =new PG_Page(driver);
		pg.EnterremainingvaluesInPGField(PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome);

		gu.captureupdateOTR(driver, document, " Entered PG page field values");     

	} 



	@Then("^verify TaxExempt CheckBox$")
	public void verify_TaxExempt_CheckBox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi.ValiTaxExempt();		
	}

	@Then("^user clicks on TaxExempt CheckBox$")
	public void user_clicks_on_TaxExempt_CheckBox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi.CheckTaxExempt();		
	}

	@Then("^user unchecks on TaxExempt CheckBox$")
	public void user_unchecks_on_TaxExempt_CheckBox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//Thread.sleep(2000);
		bi.UncheckTaxExempt();
	}

	@When("^user enters valid StoreNumber\"([^\"]*)\" and_AssociateId \"([^\"]*)\"$")
	public void user_enters_valid_StoreNumber_and_AssociateId(String StoreNumber, String AssociateID) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		lp=new Landing_Page(driver);
		lp.LandingFields(StoreNumber, AssociateID);
		gu.captureupdateOTR(driver, document, "Landing Page -StoreNumber - AssociateID field entered");
	}

	@When("^clicks on Please verify  in checkbox$")
	public void clicks_on_Please_verify_in_checkbox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		lp.click_Verify_Id();  

	}

	@When("^clicks on get started in button$")
	public void clicks_on_get_started_in_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		lp.click_Button();
	}

	@Then("^user should navigate to business info  page$")
	public void user_should_navigate_to_business_info_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		//Thread.sleep(2000);
		//Thread.sleep(1000);
		bi.navigatedTo_BIPage(driver);
		gu.pageScrollDownByPixel(driver);
		gu.captureupdateOTR(driver, document, " Navigate to business info  page");		//
		//Thread.sleep(1000);

	}
	/*@When("^User enters valid bi page details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_valid_bi_page_details(String DunAndBstreetNumber,String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String BillingAddress,String BASuite,String BAZipCode,String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String NumberOfEmployes,String YearEstablished,String AnnualRevenue,String RequestedCreditLine) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		try {

			//Thread.sleep(2000);
			//Thread.sleep(2000);
			bi=new BusinessInfo_Page(driver);
			bi.EntervalueInBiFields(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, BillingAddress, BASuite, BAZipCode, BusinessPhone, Ext, EmailAddress, TaxPayerId, NumberOfEmployes, YearEstablished, AnnualRevenue, RequestedCreditLine);
			//gu.pageScrollUpByPixel(driver);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");	

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());

		}

	}*/

	@When("^clicks on continue button$")
	public void clicks_on_continue_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			bi=new BusinessInfo_Page(driver);
			Thread.sleep(2000);
			gu.pageScrollUpByPixel(driver);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
			bi.Click_ContinueButton();

			//gu.pageScrollDownWithEle(driver, driver.findElement(By.id("apFirstName")));
			//bi.Click_ContinueButton();
			//Thread.sleep(1000);
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in clicking continue button... "+e.getMessage());

		}


	}

	@Then("^user should navigate to ar page$")
	public void user_should_navigate_to_ar_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//Thread.sleep(2000);
		ar=new AR_Page(driver);
		ar.navigatedTo_ARPage(driver);
		gu.pageScrollDownByPixel(driver);
		gu.captureupdateOTR(driver, document, " Navigated To AR page");	
	}

	@When("^user enters valid ar page field details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_valid_ar_page_field_details(String ApFirstName,String ApMI,String APLastName,String ApJobTitle) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ar=new AR_Page(driver);
		ar.EntervalueInArFields(ApFirstName, ApMI, APLastName, ApJobTitle);
		gu.captureupdateOTR(driver, document, " Entered AR page field values");	

	}

	@When("^user enters few fields in AR Page \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_few_fields_in_AR_Page(String ApFirstName, String ApMI) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ar=new AR_Page(driver);
		ar.EnterfewvalueInArFields(ApFirstName, ApMI);
		gu.captureupdateOTR(driver, document, " Entered few AR page field values");	

	}

	@Then("^Verify previously entered data retained or not in AR Page \"([^\"]*)\"$")
	public void verify_previously_entered_data_retained_or_not_in_AR_Page(String EnteredText) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ar=new AR_Page(driver);
		ar.validateText(EnteredText);
	}

	@Then("^user enter few more fields in AR Page \"([^\"]*)\"$")
	public void user_enter_few_more_fields_in_AR_Page(String APLastName) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ar=new AR_Page(driver);
		ar.EnterfewmorevalueInArFields(APLastName);
		gu.captureupdateOTR(driver, document, " Entered few more AR page field values");	

	}


	@Then("^user should navigate to PG  page$")
	public void user_should_navigate_to_PG_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//Thread.sleep(1000);
		pg =new PG_Page(driver);
		pg.navigatedTo_PgPage(driver);
		gu.pageScrollDownByPixel(driver);
		gu.captureupdateOTR(driver, document, " Navigated to PG Page");	


	}

//	@When("^user enters valid PG page field details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
//	public void user_enters_valid_PG_page_field_details(String PgHomeAddress,String PgZipCode,String PgEmailAddress,String PgPersonalPhone,String PgSsn,String PgDob,String PgAnuualNetIncome) throws Throwable {
//		// Write code here that turns the phrase above into concrete actions
//		pg =new PG_Page(driver);
//		pg.EntervalueInPGFields(PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome);
//		// gu.pageScrollUpByPixel(driver);
//		gu.captureupdateOTR(driver, document, " Entered PG page field values");	
//
//	}


	@Then("^user should navigate to options page$")
	public void user_should_navigate_to_options_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op =new Options_Page(driver);
		op.navigatedTo_OptionsPage(driver);
		gu.pageScrollDownByPixel(driver);
		gu.captureupdateOTR(driver, document, " Navigated to Options Page");	
	}

	@When("^user enters valid options page  details \"([^\"]*)\"$")
	public void user_enters_valid_options_page_details( String AddBuyer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op.selectAddBuyer(AddBuyer);
		gu.captureupdateOTR(driver, document, " Entered options page field values");
	}

	@Then("^user should navigate to Terms and condition page$")
	public void user_should_navigate_to_Terms_and_condition_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		tc=new TC_Page(driver);
		tc.navigatedTo_TCPage(driver);
		gu.pageScrollDownByPixel(driver);
		gu.captureupdateOTR(driver, document, " Navigated to Terms and conditions Page");	
	}

	@Then("^clicks on accept and submit button$")
	public void clicks_on_accept_and_submit_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			tc.click_AcceptSubmitButton();
			//Thread.sleep(4000);


		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in clicking accept and submit button");
		}


	}

	@Then("^user should navigate to Results page$")
	public void user_should_navigate_to_Results_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);

		res=new Results_Page(driver);

		Thread.sleep(3000);
		res.navigatedTo_ResultsPage(driver);
		gu.pageScrollDownByPixel(driver);
		gu.captureupdateOTR(driver, document, " Navigated to Results Page");





	}


	@When("^user verify approve or deffer or error or reffer message in results page \"([^\"]*)\"$")
	public void user_verify_approve_or_deffer_or_error_or_reffer_message_in_results_page(String FinalResults) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		// Thread.sleep(2000);

		bi=new BusinessInfo_Page(driver);
		bi.scrolldowntoele();
		gu.captureupdateOTR(driver, document, " FinalResults Message exist in result page and  Verified");
	}



	@Then("^user  should navigate to CT  page$")
	public void user_should_navigate_to_CT_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.navigatedTo_CtPage(driver);
		gu.pageScrollDownByPixel(driver);
		gu.captureupdateOTR(driver, document, " Navigated to CT Page");

	}

	@Then("^user select controller ar/pg or someone else  and enter deatils for ct page \"([^\"]*)\"$")
	public void user_select_controller_ar_pg_or_someone_else_and_enter_deatils_for_ct_page(String Controller) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct.SelectController(Controller);
		gu.captureupdateOTR(driver, document, " Who will as controller value selected in  CT Page ");

	}

	@Then("^user  should navigate to BO  page$")
	public void user_should_navigate_to_BO_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		bo=new BO_Page(driver);
		bo.navigatedTo_BoPage(driver);
		gu.pageScrollDownByPixel(driver);
		gu.captureupdateOTR(driver, document, " Navigated to BO Page");

	}

	@Then("^User enters company full legal name value and validate field with differt types of data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_company_full_legal_name_value_and_validate_field_with_differt_types_of_data(String CompanyFullLegalName, String ErrorMessage, String MaxLenght) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		//Thread.sleep(2000);
		bi.Companyname_FieldValidation(CompanyFullLegalName, ErrorMessage, MaxLenght);
		gu.captureupdateOTR(driver, document, " Field validation for BI Company name field ");
	}


	@Then("^user Check At least one individual at my organization check box$")
	public void user_Check_At_least_one_individual_at_my_organization_check_box() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		bo=new BO_Page(driver);
		bo.addOneBO();
	}



	@Then("^user Select AR-PG/CT from Who will be a Benificial Owner dropdown \"([^\"]*)\"$")
	public void user_Select_AR_PG_CT_from_Who_will_be_a_Benificial_Owner_dropdown(String BeneficialOwner) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.whoWillBeABo(BeneficialOwner);
		gu.captureupdateOTR(driver, document, "  BeneficialOwner BO0 is selected ");
	}
	@Then("^User should select anyone from the Benificial Owner dropdown \"([^\"]*)\"$")
	public void user_should_select_anyone_from_the_Benificial_Owner_dropdown(String BeneficialOwner) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.whoWillBeABO(BeneficialOwner);
		gu.captureupdateOTR(driver, document, "  BeneficialOwner BO0 is selected ");
	}
	@Then("^Enter Remaining values In BOONEFieldsIsNotUsCitizen \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void enter_Remaining_values_In_BOONEFieldsIsNotUsCitizen(String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0, String BOPassportNumber0, String BOCountryOfIDIssunace0, String BOTypeOfIdentification0, String BODocIssueDt0, String BODocExpDt0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.EnterRemainingvaluesInBOFieldsIsNotUsCitizen0(BOHomeAddress0, BOZipCode0, BOssn0, BODob0, BOPassportNumber0, BOCountryOfIDIssunace0, BOTypeOfIdentification0, BODocIssueDt0, BODocExpDt0);
	}
	@Then("^user Add another Benificial Owner link$")
	public void user_Add_another_Benificial_Owner_link() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.addAnotherBO();
	}

	@Then("^user clicks on TEMS link$")
	public void user_clicks_on_TEMS_link() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.clickTemsLinkAndVerifyNewTab();
	}
	@Then("^Verify the TEMS links present or not$")
	public void verify_the_TEMS_links_present_or_not() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.VerifyTemsLink();
		gu.pagescrollDown();
		gu.pagescrollDown();
		gu.captureupdateOTR(driver, document, " !-----TEMS link is not getting Displayed----!");

	}
	@When("^validate labels \"([^\"]*)\"$")
	public void validate_labels(String labelname) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.validateLabel(labelname);
	}
	@Then("^Verify that the characters entered are masked \"([^\"]*)\"$")
	public void verify_that_the_characters_entered_are_masked(String Maskfield) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.validateMasking(Maskfield);
	}

	@Then("^Verify that the characters entered are in XXX-XX-XXXX format \"([^\"]*)\"$")
	public void verify_that_the_characters_entered_are_in_XXX_XX_XXXX_format(String fieldvalue) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.validateFormate(fieldvalue);
	}
	@Then("^user enters valid PG page field details and checks Iagree checkbox \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_valid_PG_page_field_details_and_checks_Iagree_checkbox(String PgHomeAddress,String PgZipCode,String PgEmailAddress,String PgPersonalPhone,String PgSsn,String PgDob,String PgAnuualNetIncome) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pg =new PG_Page(driver);
		pg.EntervalueInPGPageAndCheckIAgreeCheckbox(PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome);

		//throw new PendingException();
	}


	@Then("^user Select someone else from Who will be a Benificial Owner dropdown\"([^\"]*)\"$")
	public void user_Select_someone_else_from_Who_will_be_a_Benificial_Owner_dropdown(String BeneficialOwner) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.whoWillBeABo(BeneficialOwner);
	}
	@When("^User enters valid bi page details and uncheck billing address \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_valid_bi_page_details_and_uncheck_billing_address(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String BillingAddress,String BASuite,String BAZipCode,String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String NumberOfEmployes,String YearEstablished,String AnnualRevenue,String RequestedCreditLine) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {

			//Thread.sleep(1000);
			//Thread.sleep(2000);
			bi=new BusinessInfo_Page(driver);

			//bi.EntervalueInBiFields(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, BillingAddress, BASuite, BAZipCode, BusinessPhone, Ext, EmailAddress, TaxPayerId, NumberOfEmployes, YearEstablished, AnnualRevenue, RequestedCreditLine);
			bi.EntervalueInBiFieldUncheckBillingAddr(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, BillingAddress, BASuite, BAZipCode, BusinessPhone, Ext, EmailAddress, TaxPayerId, NumberOfEmployes, YearEstablished, AnnualRevenue, RequestedCreditLine);
			//gu.captureupdateOTR(driver, document, " -----Entering values in BI page and Uncheck Billing Address checkbox----- "); 
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());

		}
	}

	@Then("^clicks on This individual is a US Citizen checkbox$")
	public void clicks_on_This_individual_is_a_US_Citizen_checkbox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		// Thread.sleep(1000);
		ct.Click_UsCitizenCheckbox();

		//gu.clickByJs(driver, "ctCheckUSCitizen");

	}
	@Then("^clicks on This individual is a US Citizen checkbox in bo page$")
	public void clicks_on_This_individual_is_a_US_Citizen_checkbox_in_bo_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		//bo.Click_UsCitizenCheckbox();
		gu.clickByJs(driver, "busOwns[0].boCheckUSCitizen");
	}
	@Then("^clicks on This individual is a BOONE US Citizen checkbox in bo page$")
	public void clicks_on_This_individual_is_a_BOONE_US_Citizen_checkbox_in_bo_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		// bo.Click_UsCitizenCheckbox1();
		gu.clickByJs(driver, "busOwns[1].boCheckUSCitizen");
	}

	@Then("^clicks on This individual is a BOTWO US Citizen checkbox in bo page$")
	public void clicks_on_This_individual_is_a_BOTWO_US_Citizen_checkbox_in_bo_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		// bo.Click_UsCitizenCheckbox2();
		gu.clickByJs(driver, "busOwns[2].boCheckUSCitizen");
	}

	@Then("^clicks on This individual is a BOTHREE US Citizen checkbox in bo page$")
	public void clicks_on_This_individual_is_a_BOTHREE_US_Citizen_checkbox_in_bo_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		//bo.Click_UsCitizenCheckbox3();
		gu.clickByJs(driver, "busOwns[3].boCheckUSCitizen");
	}
	@When("^validate labels in bo page \"([^\"]*)\"$")
	public void validate_labels_in_bo_page(String labelname) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.validateLabelinbopage(labelname);
		bo.scrolldowntoeleinbopage();
		//Thread.sleep(1000);

		gu.captureupdateOTR(driver, document, " -----Label name successfully verified-------");
	}

	@Then("^validate Order \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void validate_Order(String Header, String order1, String order2, String order3) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		bi.fetchOrderOfWebElement(Header, order1, order2, order3);
	}
	@Then("^validate Order In BO \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void validate_Order_IN_BO() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		bi.fetchOrderOfWebElementInBO();
		gu.captureupdateOTR(driver, document, " validating order of the elements");
	}
	@Then("^validate Order In BO$")
	public void validate_Order_In_BO() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		bi.fetchOrderOfWebElementInBO();
		bi.scrolldowntoele();
		gu.captureupdateOTR(driver, document, " validating order of the elements");
	}
	@Then("^user select someone else  and enter deatils for Benificial Owner \"([^\"]*)\"   \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_deatils_for_Benificial_Owner(String BO0,String BOFirstName0,String BOmi0,String BOLastName0,String BOHomeAddress0,String BOZipCode0,String BOssn0,String BODob0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.EntervalueInBOFieldsIsUsCitizen0(BO0, BOFirstName0, BOmi0, BOLastName0, BOHomeAddress0, BOZipCode0, BOssn0, BODob0);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 1");	
	}

	@Then("^user select someone else  and enter few more deatils for Benificial Owner \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_few_more_deatils_for_Benificial_Owner(String BOHomeAddress0, String BOZipCode0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.EnterfewmorevalueInBOFieldsIsUsCitizen0(BOHomeAddress0, BOZipCode0);
		gu.captureupdateOTR(driver, document, " Entering few more field details for BO 1");	
	}

	@Then("^user select someone else  and enter few deatils for Benificial Owner \"([^\"]*)\"   \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_few_deatils_for_Benificial_Owner(String BO0, String BOFirstName0, String BOmi0, String BOLastName0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.EnterfewvalueInBOFieldsIsUsCitizen0(BO0, BOFirstName0, BOmi0, BOLastName0);
		gu.captureupdateOTR(driver, document, " Entering few field details for BO 1");	

	}
	@Then("^user select someone else  and enter deatils for Benificial Owner one \"([^\"]*)\"   \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_deatils_for_Benificial_Owner_one(String BO1,String BOFirstName1,String BOmi1,String BOLastName1,String BOHomeAddress1,String BOZipCode1,String BOssn1,String BODob1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.EntervalueInBOFieldsIsUsCitizen1(BO1, BOFirstName1, BOmi1, BOLastName1, BOHomeAddress1, BOZipCode1, BOssn1, BODob1);
		//bo.EntervalueInBOFieldsIsUsCitizen1(BO1, BOFirstName1, BOmi1, BOLastName1, BOHomeAddress1, BOZipCode1, BOssn1, BODob1);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 1");	
	}

	@Then("^user select someone else  and enter deatils for Benificial Owner Two \"([^\"]*)\"    \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_deatils_for_Benificial_Owner_Two(String BO2,String BOFirstName2,String BOmi2,String BOLastName2,String BOHomeAddress2,String BOZipCode2,String BOssn2,String BODob2) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo.EntervalueInBOFieldsIsUsCitizen2(BO2, BOFirstName2, BOmi2, BOLastName2, BOHomeAddress2, BOZipCode2, BOssn2, BODob2);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 2");
	}

	@Then("^user select someone else  and enter deatils for Benificial Owner Three \"([^\"]*)\"    \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_deatils_for_Benificial_Owner_Three(String BO3,String BOFirstName3,String BOmi3,String BOLastName3,String BOHomeAddress3,String BOZipCode3,String BOssn3,String BODob3) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo.EntervalueInBOFieldsIsUsCitizen3(BO3, BOFirstName3, BOmi3, BOLastName3, BOHomeAddress3, BOZipCode3, BOssn3, BODob3);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 3");
	}


	@Then("^EntervalueInBOONEFieldsIsNotUsCitizen \"([^\"]*)\"   \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void entervalueinboonefieldsisnotuscitizen(String BO0,String BOFirstName0, String BOmi0, String BOLastName0,String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0,String BOPassportNumber0,String BOCountryOfIDIssunace0,String BOTypeOfIdentification0,String BODocIssueDt0,String BODocExpDt0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo.EntervalueInBOFieldsIsNotUsCitizen0(BO0, BOFirstName0,  BOmi0,  BOLastName0, BOHomeAddress0,  BOZipCode0,  BOssn0,  BODob0, BOPassportNumber0, BOCountryOfIDIssunace0, BOTypeOfIdentification0, BODocIssueDt0, BODocExpDt0);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 1");
	}

	@Then("^EntervalueInBOTWOFieldsIsNotUsCitizen \"([^\"]*)\"   \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void entervalueinbotwofieldsisnotuscitizen(String BO1, String BOFirstName1, String BOmi1, String BOLastName1,String BOHomeAddress1, String BOZipCode1, String BOssn1, String BODob1,String BOPassportNumber1,String BOCountryOfIDIssunace1,String BOTypeOfIdentification1,String BODocIssueDt1,String BODocExpDt1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo.EntervalueInBOFieldsIsNotUsCitizen1( BO1, BOFirstName1,BOmi1,  BOLastName1, BOHomeAddress1,  BOZipCode1,  BOssn1,  BODob1, BOPassportNumber1, BOCountryOfIDIssunace1, BOTypeOfIdentification1, BODocIssueDt1, BODocExpDt1);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 2");
	}

	@Then("^EntervalueInBOTHREEFieldsIsNotUsCitizen \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void entervalueinbothreefieldsisnotuscitizen(String BO2, String BOFirstName2, String BOmi2, String BOLastName2,String BOHomeAddress2, String BOZipCode2, String BOssn2, String BODob2,String BOPassportNumber2,String BOCountryOfIDIssunace2,String BOTypeOfIdentification2,String BODocIssueDt2,String BODocExpDt2) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo.EntervalueInBOFieldsIsNotUsCitizen2(BO2, BOFirstName2,  BOmi2,  BOLastName2, BOHomeAddress2,  BOZipCode2,  BOssn2,  BODob2, BOPassportNumber2, BOCountryOfIDIssunace2, BOTypeOfIdentification2, BODocIssueDt2, BODocExpDt2);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 3");
	}

	@Then("^EntervalueInBOFOURFieldsIsNotUsCitizen \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void entervalueinbofourfieldsisnotuscitizen(String BO3, String BOFirstName3, String BOmi3, String BOLastName3,String BOHomeAddress3, String BOZipCode3, String BOssn3, String BODob3,String BOPassportNumber3,String BOCountryOfIDIssunace3,String BOTypeOfIdentification3,String BODocIssueDt3,String BODocExpDt3) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo.EntervalueInBOFieldsIsNotUsCitizen3(BO3, BOFirstName3,  BOmi3,  BOLastName3, BOHomeAddress3,  BOZipCode3,  BOssn3,  BODob3, BOPassportNumber3, BOCountryOfIDIssunace3, BOTypeOfIdentification3, BODocIssueDt3, BODocExpDt3);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 4");
	}

	@When("^EntervalueInCTFieldsIsUsCitizen \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void entervalueinctfieldsisuscitizen(String CTFirstName, String CTmi, String CTLastName, String CTJobTitle, String CTHomeAddress, String CTZipCode, String CTssn, String CTDob) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.EntervalueInCTFieldsIsUsCitizen(CTFirstName, CTmi, CTLastName, CTJobTitle, CTHomeAddress, CTZipCode, CTssn, CTDob);
	}

	@Then("^user enters single sale txt limit \"([^\"]*)\"$")
	public void user_enters_single_sale_txt_limit(String LmitForSingleSaleTxn) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.limitForSingleSaleTranx(LmitForSingleSaleTxn);
	}

	@Then("^user clicks on A purchase order is required for each purchase check box$")
	public void user_clicks_on_A_purchase_order_is_required_for_each_purchase_check_box() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.ClickOrderCheckBox();
	}

	@Then("^user enter options page details for add buyer one  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_options_page_details_for_add_buyer_one(String opAB0, String opFirstName0, String opLastName0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		op=new Options_Page(driver);
		op.EnterValuesInOptionsField0(opAB0, opFirstName0, opLastName0);
		gu.captureupdateOTR(driver, document, " Entering add buyer 1 field details for options page");
	}

	@Then("^user clicks on add another buyer link$")
	public void user_clicks_on_add_another_buyer_link() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//Thread.sleep(2000);
		op=new Options_Page(driver);
		op.clickAddAnotherBuyer();
		// Thread.sleep(2000);
	}

	@Then("^user enter options page details for add buyer two  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_options_page_details_for_add_buyer_two(String opAB1, String opFirstName1, String opLastName1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.EnterValuesInOptionsField1(opAB1, opFirstName1, opLastName1);
		gu.captureupdateOTR(driver, document, " Entering add buyer 2 field details for options page");
	}

	@Then("^user enter options page details for add buyer three  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_options_page_details_for_add_buyer_three(String opAB2, String opFirstName2, String opLastName2) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.EnterValuesInOptionsField2(opAB2, opFirstName2, opLastName2);
		gu.captureupdateOTR(driver, document, " Entering add buyer 3 field details for options page");
	}

	@Then("^user enter options page details for add buyer four  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_options_page_details_for_add_buyer_four(String opAB3, String opFirstName3, String opLastName3) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.EnterValuesInOptionsField3(opAB3, opFirstName3, opLastName3);
		gu.captureupdateOTR(driver, document, " Entering add buyer 4 field details for options page");
	}
	@When("^user clicks on Select Lowe's Accounts Receivable check box$")
	public void user_clicks_on_Select_Lowe_s_Accounts_Receivable_check_box() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		lp=new Landing_Page(driver);
		lp.click_checkbox_prox();
	}

	@Then("^user clicks on I will include a personal guaranty with this application checkbox$")
	public void user_clicks_on_I_will_include_a_personal_guaranty_with_this_application_checkbox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pg=new PG_Page(driver);
		pg.iwillincludepg_checkbox();
		// Thread.sleep(1000);
		//gu.captureupdateOTR(driver, document, " ----- successfully verified-------");
	}

	@When("^user clicks on Select Lowe's Business Account check box$")
	public void user_clicks_on_Select_Lowe_s_Business_Account_check_box() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		lp=new Landing_Page(driver);
		lp.ClicksLowesBusinessChkbox();
		gu.captureupdateOTR(driver, document, " Click on Select Lowe's Business Account check box");
	}

	@Then("^user verify approve or decline or error or reffer message in results page \"([^\"]*)\"$")
	public void user_verify_approve_or_decline_or_error_or_reffer_message_in_results_page(String FinalResults) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		res=new Results_Page(driver);
		gu=new GenericUtilities();
		res.verifyFinalResultsMessages(FinalResults);

		if(FinalResults.equalsIgnoreCase("Congratulations")){
			res.scrolldowntoele( FinalResults);
			gu.captureupdateOTR(driver, document, " Result Page");
			gu.pageScrollDownByPixel(driver);
			gu.captureupdateOTR(driver, document, "Result Page");
			gu.pageScrollDownByPixel(driver);
			gu.captureupdateOTR(driver, document, "Result Page");

		}else{
			res.scrolldowntoele( FinalResults);
			gu.pageScrollDownByPixel(driver);
			gu.captureupdateOTR(driver, document, "Result Page");
			gu.pageScrollDownByPixel(driver);
			gu.captureupdateOTR(driver, document, "Result Page");

		}
	}


	@When("^User enters Field values and validate with different types of data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_Field_values_and_validate_with_different_types_of_data(String FieldName,String FieldValue,String ErrorMessage, String MaxLength,String labelname) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		bi.EntervaluesinField(FieldName, FieldValue, ErrorMessage, MaxLength, labelname);
		//ct.EntervaluesinField(FieldName, FieldValue, ErrorMessage, MaxLength, labelname);
		//gu.captureupdateOTR(driver, document, " entering values in the page ");	
		//Thread.sleep(1000);
		gu.captureupdateOTR(driver, document, " ----- successfully verified-------");
	}
	@When("^EntervalueInCTFieldsIsNotUsCitizen \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void entervalueinctfieldsisnotuscitizen(String CTFirstName, String CTmi, String CTLastName, String CTJobTitle, String CTHomeAddress, String CTZipCode, String CTssn, String CTDob, String CTPassportNumber, String CTCountryOfIDIssunace, String CTTypeOfIdentification, String CTDocIssueDt, String CTDocExpDt) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.EntervalueInCTFieldsIsNotUsCitizen(CTFirstName, CTmi, CTLastName, CTJobTitle, CTHomeAddress, CTZipCode, CTssn, CTDob, CTPassportNumber, CTCountryOfIDIssunace, CTTypeOfIdentification, CTDocIssueDt, CTDocExpDt);
		gu.captureupdateOTR(driver, document, " ----- Entering CT Fieldsdetails in CT page-for Not us citizen------");
		//Thread.sleep(1000);
	}
	@Then("^user enters valid CT page field details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_valid_CT_page_field_details(String CTHomeAddress, String CTZipCode, String CTssn, String CTDob, String CTPassportNumber, String CTCountryOfIDIssunace, String CTTypeOfIdentification, String CTDocIssueDt, String CTDocExpDt) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.EntervalueInCTMadatoryFieldsIsNotUsCitizen(CTHomeAddress, CTZipCode, CTssn, CTDob, CTPassportNumber, CTCountryOfIDIssunace, CTTypeOfIdentification, CTDocIssueDt, CTDocExpDt);
		gu.captureupdateOTR(driver, document, " ----- Entering CT Fieldsdetails in CT page------");
	}

	@Then("^scroll to first error filed is \"([^\"]*)\"$")
	public void scroll_to_first_error_filed_is(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//Thread.sleep(1000);
		gu.captureupdateOTR(driver, document, " Scroll to "+arg1+" error field when it is empty");
	}

	/*@When("^user waits for few minutes$")
public void user_waits_for_few_minutes() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //Thread.sleep(1000*60*3);
	bi=new BusinessInfo_Page(driver);
	bi.waitFewMins(3);

}*/

	@Then("^user waits for few minutes \"([^\"]*)\"$")
	public void user_waits_for_few_minutes(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		bi.waitFewMins(arg1);
		//gu.captureupdateOTR(driver, document, " Time Remaining modal window with continue button is displayed ");
	}


	@Then("^user waits for timer to become zero$")
	public void user_waits_for_timer_to_become_zero() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		gu.waitUntilZero(driver);
	}

	@When("^user clicks on continue button in popup displayed$")
	public void user_clicks_on_continue_button_in_popup_displayed() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			gu.captureupdateOTR(driver, document, " Time Remaining modal window with continue button is displayed ");
			bi=new BusinessInfo_Page(driver);
			bi.click_ContinueAppButtonPopUp();
			//gu.captureupdateOTR(driver, document, " Time Remaining modal window with continue button is displayed ");
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in clicking continue button popup... "+e.getMessage());
		}
	}

	@When("^User enters few fields in bi page details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_few_fields_in_bi_page_details(String CompanyFullLegalName, String DBAName, String TypeOfBusiness, String PromCode, String BusinessAddress, String Suite, String ZipCode) throws Throwable {

		// Write code here that turns the phrase above into concrete actions
		try {

			Thread.sleep(2000);
			Thread.sleep(2000);
			bi=new BusinessInfo_Page(driver);
			bi.EnterfewvaluesinBiFields(CompanyFullLegalName,DBAName,TypeOfBusiness,PromCode,BusinessAddress,Suite, ZipCode);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");	
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());

		}

	}

	@Then("^user enters some more fields in bi page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_some_more_fields_in_bi_page(String BusinessPhone,String Ext,String EmailAddress) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {

			//Thread.sleep(2000);
			//Thread.sleep(2000);
			bi=new BusinessInfo_Page(driver);
			bi.EntersomemorevaluesInBiFields(BusinessPhone, Ext, EmailAddress);
			gu.captureupdateOTR(driver, document, " Entering some more values in BI Page ");	
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in entering some more values in business info  page.... "+e.getMessage());

		}

	}



	@Then("^user clicks on StartOver button in popup displayed$")
	public void user_clicks_on_StartOver_button_in_popup_displayed() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			//Thread.sleep(3000);
			bi=new BusinessInfo_Page(driver);
			bi.waitFewMinsForStartOver(3);
			gu.captureupdateOTR(driver, document, " Time Out  Modal Window with Start Over button is displayed ");

			bi.clickStartOverButton();
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue in clicking continue button popup... "+e.getMessage());

		}
	}

	@Then("^checks whether the page is reloaded$")
	public void checks_whether_the_page_is_reloaded() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		bi.pageReload();
		gu.captureupdateOTR(driver, document, " Page is Reloaded ");
	}

	@When("^user enters few fields in PG Page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_few_fields_in_PG_Page(String PgHomeAddress, String PgZipCode, String PgEmailAddress) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pg =new PG_Page(driver);
		pg.EnterfewvalueInPGFields(PgHomeAddress, PgZipCode, PgEmailAddress);  
		gu.captureupdateOTR(driver, document, " Entered few PG page field values");	

	}

	@Then("^Verify previously entered data retained or not in PG Page \"([^\"]*)\"$")
	public void verify_previously_entered_data_retained_or_not_in_PG_Page(String EnteredText) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pg=new PG_Page(driver);
		pg.validateText(EnteredText);
	}

	@Then("^user enter few more fields in PG Page \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_few_more_fields_in_PG_Page(String PgPersonalPhone, String PgSsn) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pg =new PG_Page(driver);
		pg.EnterfewmorevalueInPGFields(PgPersonalPhone, PgSsn);  
		gu.captureupdateOTR(driver, document, " Entered few more PG page field values");	

	}



	@When("^user enters few fields in CT Page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_few_fields_in_CT_Page(String CTFirstName, String CTmi, String CTLastName) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.EnterfewvalueInCTFields(CTFirstName, CTmi, CTLastName);
		gu.captureupdateOTR(driver, document, " Entered few field values in CT page");
	}


	@Then("^user enters few fields in Options Page \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_few_fields_in_Options_Page(String LmitForSingleSaleTxn, String opAB0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.EnterfewvalueInOptionsPage(LmitForSingleSaleTxn, opAB0);
		gu.captureupdateOTR(driver, document, " Entered few field values in Options page");

	}


	@Then("^user verifies whether the previously entered data is retained in Options Page \"([^\"]*)\"$")
	public void user_verifies_whether_the_previously_entered_data_is_retained_in_Options_Page(String EnteredText) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.validateText(EnteredText);	
	}

	@Then("^user enters few more fields in Options Page \"([^\"]*)\"$")
	public void user_enters_few_more_fields_in_Options_Page(String opFirstName0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.EnterfewmorevalueInOptionsPage(opFirstName0);
		gu.captureupdateOTR(driver, document, " Entered few more field values in Options page");

	}

	@Then("^user verifies whether the previously entered data is retained in CT Page \"([^\"]*)\"$")
	public void user_verifies_whether_the_previously_entered_data_is_retained_in_CT_Page(String EnteredText) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		ct=new CT_Page(driver);
		ct.validateText(EnteredText);
	}
	@Then("^user verifies whether the previously entered data is retained in BO Page \"([^\"]*)\"$")
	public void user_verifies_whether_the_previously_entered_data_is_retained_in_BO_Page(String EnteredText) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.validateText(EnteredText);
	}
	@Then("^user enters some more fields in CT Page \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_some_more_fields_in_CT_Page(String CTJobTitle, String CTHomeAddress) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.EnterfewmorevalueInCTFields(CTJobTitle, CTHomeAddress);
		gu.captureupdateOTR(driver, document, " Entered few more field values CT page ");
	}
	@Then("^verify LowesBusinessAccount CheckBox$")
	public void verify_LowesBusinessAccount_CheckBox() throws Throwable {
		Thread.sleep(2000);
		lp=new Landing_Page(driver);
		lp.ValiLowesBusinessChkbox();
	}

	@Then("^verify LowesAccountReceivable CheckBox$")
	public void verify_LowesAccountReceivable_CheckBox() throws Throwable {

		Thread.sleep(2000);
		lp=new Landing_Page(driver);
		lp.ValiLowesReceivableChkbox();
	}

	@Then("^user clicks on LowesBusinessAccount CheckBox$")
	public void user_clicks_on_LowesBusinessAccount_CheckBox() throws Throwable {
		//Thread.sleep(2000);
		lp=new Landing_Page(driver);
		lp.ClicksLowesBusinessChkbox();
	}

	@Then("^user unchecks on LowesBusinessAccount CheckBox$")
	public void user_unchecks_on_LowesBusinessAccount_CheckBox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		lp=new Landing_Page(driver);
		lp.ClicksLowesReceivableChkbox();
	}

	@Then("^user clicks on LowesAccountReceivable CheckBox$")
	public void user_clicks_on_LowesAccountReceivable_CheckBox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		lp=new Landing_Page(driver);
		lp.UncheckLowesBusinessChkbox();
	}

	@Then("^user unchecks on LowesAccountReceivable CheckBox$")
	public void user_unchecks_on_LowesAccountReceivable_CheckBox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		lp=new Landing_Page(driver);
		lp.UncheckLowesReceivableChkbox();
	}

	@Then("^user verifies whether Send card check Box is present \"([^\"]*)\"$")
	public void user_verifies_whether_Send_card_check_Box_is_present(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.ValiSendCardChkbox();
		gu.captureupdateOTR(driver, document, " Send card check Box is present ");
	}

	@Then("^user clicks on Send card check box \"([^\"]*)\"$")
	public void user_clicks_on_Send_card_check_box(String webelementofCheckBox) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver);
		op.ClicksSendCardChkbox(webelementofCheckBox);
	}

	@Then("^user unchecks Send card check box \"([^\"]*)\"$")
	public void user_unchecks_Send_card_check_box(String webelementofCheckBox) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		op=new Options_Page(driver); 
		op.UncheckSendCardChkbox(webelementofCheckBox);
	}
	@Then("^verify get started button enabled$")
	public void verify_get_started_button_enabled() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		lp=new Landing_Page(driver);
		lp.verifyGetStarted_ButtonisEnabled();   
		gu.captureupdateOTR(driver, document, "Landing Page get started button enabled");
	}

	@Then("^user Verifies the Verbiage and the Phone number on the referred page \"([^\"]*)\"$")
	public void user_Verifies_the_Verbiage_and_the_Phone_number_on_the_referred_page(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		res=new Results_Page(driver);
		res.valiPhnNoVerbiage(arg1);
	}
	//added dunandBstret filed
	@When("^User enters valid bi page details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_valid_bi_page_details(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String BillingAddress,String BASuite,String BAZipCode,String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String DunAndBstreetNumber,String NumberOfEmployes,String YearEstablished,String AnnualRevenue,String RequestedCreditLine) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			bi=new BusinessInfo_Page(driver);
			bi.EntervalueInBiFields(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, BillingAddress, BASuite, BAZipCode, BusinessPhone, Ext, EmailAddress, TaxPayerId, DunAndBstreetNumber,NumberOfEmployes, YearEstablished, AnnualRevenue, RequestedCreditLine);
			//gu.captureupdateOTR(driver, document, " entering values in bi page ");

		} catch (Exception e) {
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());	
		}

	}
	@When("^user Verifies that the Dun and Bradstreet field is displayed below Taxpayer ID field on BI page \"([^\"]*)\"$")
	public void user_Verifies_that_the_Dun_and_Bradstreet_field_is_displayed_below_Taxpayer_ID_field_on_BI_page(String dunAndBstreetNumber) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		//bi.verifyDunAndBstreetNumber(dunAndBstreetNumber);
		gu.captureupdateOTR(driver, document, "DunAndBstreetNumber is not present");
	}
	@Then("^Verify that the Optional text is displayed below the Dun and Bradstreet field text box \"([^\"]*)\"$")
	public void verify_that_the_Optional_text_is_displayed_below_the_Dun_and_Bradstreet_field_text_box(String Optional) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		//bi.verifyOptiontext(Optional);
		gu.captureupdateOTR(driver, document, "Option is not present");
	}	
	@Then("^Verify that the help text is displayed when the cursor is placed on the field$")
	public void verify_that_the_help_text_is_displayed_when_the_cursor_is_placed_on_the_field() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		//bi.verifyVerbiage(); ///DandBverbiage,DunAndBstreetNumber
		gu.captureupdateOTR(driver, document, "DandBverbiage is not present");
	}
	//@Then("^Verify that the help text is displayed when the cursor is placed on the field $") //\"([^\"]*)\"\\.$")   String DandBverbiage,String DunAndBstreetNumber
	//public void verify_that_the_help_text_is_displayed_when_the_cursor_is_placed_on_the_field() throws Throwable {
	//    // Write code here that turns the phrase above into concrete actions
	//	bi=new BusinessInfo_Page(driver);
	//	bi.verifyVerbiage(); ///DandBverbiage,DunAndBstreetNumber
	//	gu.captureupdateOTR(driver, document, "DandBverbiage is not present");
	//}
	@Then("^Verify that the help text is hidden when the cursor is moved out of the field \"([^\"]*)\"$")
	public void verify_that_the_help_text_is_hidden_when_the_cursor_is_moved_out_of_the_field(String NumberOfEmployes) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bi=new BusinessInfo_Page(driver);
		//bi.verifyVerbiageHide(NumberOfEmployes);
		gu.captureupdateOTR(driver, document, "DandBverbiage is not present");
	}


	@Then("^user should check the checkbox and click on Homeaddress field and validate verbiage \"([^\"]*)\"$")
	public void user_should_check_the_checkbox_and_click_on_Homeaddress_field_and_validate_verbiage(String PGHomeaddressVerbiage) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pg =new PG_Page(driver);
		pg.verifyverbiageinpgpage(PGHomeaddressVerbiage);
		gu.captureupdateOTR(driver, document, "DandBverbiage is not present");
	}
	@Then("^User should click on Homeaddress and validate verbiage \"([^\"]*)\"$")
	public void user_should_click_on_Homeaddress_and_validate_verbiage(String CTHomeaddressVerbiage) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.CTHomeaddressvalidate(CTHomeaddressVerbiage);
	}
	@Then("^user select someone else and enter all deatils for Benificial Owner one \"([^\"]*)\"   \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_all_deatils_for_Benificial_Owner_one(String BO0, String BOFirstName0, String BOmi0, String BOLastName0, String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.EnterallvaluesInBO0Fields(BO0, BOFirstName0, BOmi0, BOLastName0, BOHomeAddress0, BOZipCode0, BOssn0, BODob0);
		gu.captureupdateOTR(driver, document, "BOHomeaddress is not present");
	}

	@Then("^User should click on Homeaddress and validate verbiage \"([^\"]*)\"  \"([^\"]*)\"$")
	public void user_should_click_on_Homeaddress_and_validate_verbiage(String BO0, String BO0HomeaddressVerbiage) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.BOHomeaddressValidation(BO0,BO0HomeaddressVerbiage);
	}

	@Then("^user select someone else and enter BOFirstPage deatils for Benificial Owner one \"([^\"]*)\"   \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_BOFirstPage_deatils_for_Benificial_Owner_one(String BO0, String BOFirstName0, String BOmi0, String BOLastName0, String BOHomeAddress0, String BOHomeaddressValidation,String BOZipCode0, String BOssn0, String BODob0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.ValidateBO0Verbiage(BO0, BOFirstName0, BOmi0, BOLastName0, BOHomeAddress0, BOHomeaddressValidation,BOZipCode0, BOssn0, BODob0);
		gu.captureupdateOTR(driver, document, "BOHomeaddress is not present");
	}

	@Then("^user select someone else and enter BOSecond deatils for Benificial Owner one \"([^\"]*)\"   \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_BOSecond_deatils_for_Benificial_Owner_one(String BO1, String BOFirstName1, String BOmi1, String BOLastName1, String BOHomeAddress1, String BOHomeaddressValidation, String BOZipCode1, String BOssn1, String BODob1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.ValidateBO2Homeaddress(BO1, BOFirstName1, BOmi1, BOLastName1, BOHomeAddress1,BOHomeaddressValidation, BOZipCode1, BOssn1, BODob1);
		//bo.EntervalueInBOFieldsIsUsCitizen1(BO1, BOFirstName1, BOmi1, BOLastName1, BOHomeAddress1, BOZipCode1, BOssn1, BODob1);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 1");	
	}

	@Then("^user select someone else  and enter BOThird deatils for Benificial Owner Two \"([^\"]*)\"    \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_BOThird_deatils_for_Benificial_Owner_Two(String BO2, String BOFirstName2, String BOmi2, String BOLastName2, String BOHomeAddress2, String BOHomeaddressValidation, String BOZipCode2, String BOssn2, String BODob2) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.ValidateBo3Homepageaddress(BO2, BOFirstName2, BOmi2, BOLastName2, BOHomeAddress2,BOHomeaddressValidation, BOZipCode2, BOssn2, BODob2);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 2");
	}


	@Then("^user select someone else  and enter BOFourth deatils for Benificial Owner Three \"([^\"]*)\"    \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_select_someone_else_and_enter_BOFourth_deatils_for_Benificial_Owner_Three(String BO3, String BOFirstName3, String BOmi3, String BOLastName3, String BOHomeAddress3, String BOHomeaddressValidation, String BOZipCode3, String BOssn3, String BODob3) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo=new BO_Page(driver);
		bo.ValidateBO3HomeaddressVerbiage(BO3, BOFirstName3, BOmi3, BOLastName3, BOHomeAddress3,BOHomeaddressValidation, BOZipCode3, BOssn3, BODob3);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 3");
	}

	@Then("^Enter value in CTpage without checking UScitizen \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void enter_value_in_CTpage_without_checking_UScitizen(String CTFirstName, String CTmi, String CTLastName, String CTJobTitle, String CTHomeAddress, String CTZipCode, String CTssn, String CTDob) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ct=new CT_Page(driver);
		ct.EntervalueinCTbydefaultcheckbox( CTFirstName,  CTmi,  CTLastName , CTJobTitle , CTHomeAddress,  CTZipCode,  CTssn,  CTDob);
		gu.captureupdateOTR(driver, document, " ----- Entering CT Fieldsdetails in CT page-for Not us citizen------");

	}

	@Then("^user should enter the BO details without unchecking UScitizen  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_should_enter_the_BO_details_without_unchecking_UScitizen(String BOFirstName0, String BOmi0, String BOLastName0, String BOHomeAddress0, String BOZipCode0, String BOssn0, String BODob0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		bo.EntervalueInBObydefaultcheckUScitizen( BOFirstName0,BOmi0,  BOLastName0, BOHomeAddress0,  BOZipCode0,  BOssn0,  BODob0);
		gu.captureupdateOTR(driver, document, " Entering field details for BO 2");
	}


	//	@When("^User enter BI page details by making default check of billing address \"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	//	public void user_enter_BI_page_details_by_making_default_check_of_billing_address(String CompanyFullLegalName, String DBAName, String TypeOfBusiness, String PromCode, String BusinessAddress, String Suite, String ZipCode, String BusinessPhone, String Ext, String EmailAddress, String TaxPayerId, String DunAndBstreetNumber, String NumberOfEmployes, String YearEstablished, String RequestedCreditLine) throws Throwable {
	//	    // Write code here that turns the phrase above into concrete actions
	//		try {
	//			bi=new BusinessInfo_Page(driver);
	//			bi.EntervalueInBibydafaultFields(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, BusinessPhone, Ext, EmailAddress, TaxPayerId, DunAndBstreetNumber,NumberOfEmployes, YearEstablished, RequestedCreditLine);
	//			gu.captureupdateOTR(driver, document, " entering values in bi page ");
	//
	//		} catch (Exception e) {
	//			logger.info("Issue in entering values in business info  page.... "+e.getMessage());	
	//		}
	//	}

	//		@When("^User enter BI page details by making default check of billing address \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	//		public void user_enter_BI_page_details_by_making_default_check_of_billing_address(String CompanyFullLegalName, String DBAName, String TypeOfBusiness, String PromCode, String BusinessAddress, String Suite, String ZipCode, String BusinessPhone, String Ext, String EmailAddress, String TaxPayerId, String DunAndBstreetNumber, String NumberOfEmployes, String YearEstablished, String RequestedCreditLine) throws Throwable {
	//		    // Write code here that turns the phrase above into concrete actions
	//			try {
	//				bi=new BusinessInfo_Page(driver);
	//				bi.EntervalueInBibydefaultFields(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, BusinessPhone, Ext, EmailAddress, TaxPayerId, DunAndBstreetNumber,NumberOfEmployes, YearEstablished, RequestedCreditLine);
	//				gu.captureupdateOTR(driver, document, " entering values in bi page ");
	//
	//			} catch (Exception e) {
	//				logger.info("Issue in entering values in business info  page.... "+e.getMessage());	
	//			}
	//		}

	@Then("^user should Verify that the Annual Revenue field is removed Verify that the Requested Credit Line field is displayed below Number of Employees and Year Established text fields on Business page$")
	public void user_should_Verify_that_the_Annual_Revenue_field_is_removed_Verify_that_the_Requested_Credit_Line_field_is_displayed_below_Number_of_Employees_and_Year_Established_text_fields_on_Business_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			bi=new BusinessInfo_Page(driver);
			bi.ValidateRemovalofAnnualField(); 
			gu.captureupdateOTR(driver, document, " creditLineRequested is below Noofemployee and Year established field ");

		} catch (Exception e) {
			logger.info("creditLineRequested field is not below Noofemployee and Year established field.... "+e.getMessage());	
		}
	}

	//		@When("^User enter BI page details by making default check of billing address \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	//		public void user_enter_BI_page_details_by_making_default_check_of_billing_address(String CompanyFullLegalName, String DBAName, String TypeOfBusiness, String PromCode, String BusinessAddress, String Suite, String ZipCode, String CityandState, String BusinessPhone, String Ext, String EmailAddress, String TaxPayerId, String DunAndBstreetNumber, String NumberOfEmployes, String YearEstablished, String RequestedCreditLine) throws Throwable {
	//		    // Write code here that turns the phrase above into concrete actions
	//			try {
	//				bi=new BusinessInfo_Page(driver);
	//				bi.EntervalueInBibydefaultFields(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode,CityandState, BusinessPhone, Ext, EmailAddress, TaxPayerId, DunAndBstreetNumber,NumberOfEmployes, YearEstablished, RequestedCreditLine);
	//				gu.captureupdateOTR(driver, document, " entering values in bi page ");
	//
	//			} catch (Exception e) {
	//				logger.info("Issue in entering values in business info  page.... "+e.getMessage());	
	//			}
	//		}

	@When("^User enter BI page details by making default check of billing address \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_BI_page_details_by_making_default_check_of_billing_address(String CompanyFullLegalName, String DBAName, String TypeOfBusiness, String PromCode, String BusinessAddress, String Suite, String ZipCode, String CityandState, String BusinessPhone, String Ext, String EmailAddress, String TaxPayerId, String DunAndBstreetNumber, String NumberOfEmployes, String YearEstablished, String AnnualRevenue, String RequestedCreditLine) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			bi=new BusinessInfo_Page(driver);
			bi.EntervalueInBibydefaultFields(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode,CityandState, BusinessPhone, Ext, EmailAddress, TaxPayerId, DunAndBstreetNumber,NumberOfEmployes, YearEstablished, AnnualRevenue, RequestedCreditLine);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");

		} catch (Exception e) {
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());	
		}
	}

	@Then("^user enters valid PG page field details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_valid_PG_page_field_details(String PgHomeAddress, String PgZipCode, String PgCityandState, String PgEmailAddress, String PgPersonalPhone, String PgSsn, String PgDob, String PgAnuualNetIncome) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		pg =new PG_Page(driver);
		pg.EntervaluesInPGFields(PgHomeAddress, PgZipCode, PgCityandState, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome);
		// gu.pageScrollUpByPixel(driver);
		gu.captureupdateOTR(driver, document, " Entered PG page field values");	
	}



	@Then("^validate the error page \"([^\"]*)\"$")
	public void validate_the_error_page(String FinalResults) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		res=new Results_Page(driver);
		res.errorpagevalidation(FinalResults);
	}

	@When("^User enter BI page details by making default check of billing address with AnnualRevenue field \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_BI_page_details_by_making_default_check_of_billing_address_with_AnnualRevenue_field(String CompanyFullLegalName, String DBAName, String TypeOfBusiness, String PromCode, String BusinessAddress, String Suite, String ZipCode, String CityandState, String BusinessPhone, String Ext, String EmailAddress, String TaxPayerId, String DunAndBstreetNumber, String NumberOfEmployes, String YearEstablished, String AnnualRevenue, String RequestedCreditLine) throws Throwable {

		try {
			bi=new BusinessInfo_Page(driver);
			bi.EntervalueInBiFieldswithAnnualRevenue(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, CityandState,  BusinessPhone, Ext, EmailAddress, TaxPayerId, DunAndBstreetNumber, NumberOfEmployes, YearEstablished, AnnualRevenue, RequestedCreditLine);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");

		} catch (Exception e) {
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());	
		}

	}

	@When("^User enters valid bi page details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters_valid_bi_page_details(String CompanyFullLegalName, String DBAName, String TypeOfBusiness, String PromCode, String BusinessAddress, String Suite, String ZipCode, String BillingAddress, String BASuite, String BAZipCode, String BusinessPhone, String Ext, String EmailAddress, String TaxPayerId, String DunAndBstreetNumber, String NumberOfEmployes, String YearEstablished, String RequestedCreditLine) throws Throwable {
		try {
			bi=new BusinessInfo_Page(driver);
			bi.EntervalueInBiFieldsinQA(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, BillingAddress, BASuite, BAZipCode, BusinessPhone, Ext, EmailAddress, TaxPayerId, DunAndBstreetNumber,NumberOfEmployes, YearEstablished,RequestedCreditLine);
			//gu.captureupdateOTR(driver, document, " entering values in bi page ");

		} catch (Exception e) {
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());	
		}

	}


	@Then("^Enter all the mandatory fields on AR page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void enter_all_the_mandatory_fields_on_AR_page(String ApFirstName, String ApMI, String APLastName, String ApJobTitle, String ApPhoneNumber, String ApEmailAddress) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		ar=new AR_Page(driver);
		ar.EntervaluesinARpage(ApFirstName, ApMI, APLastName, ApJobTitle, ApPhoneNumber, ApEmailAddress);
		gu.captureupdateOTR(driver, document, " Entered AR page field values");	

	}

	@Then("^Verify that the Phone Number field is displayed below Job Title text field on AR page$")
	public void verify_that_the_Phone_Number_field_is_displayed_below_Job_Title_text_field_on_AR_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			ar=new AR_Page(driver);
			ar.valiPhoneNumberinAR(); 
			gu.captureupdateOTR(driver, document, " creditLineRequested is below Noofemployee and Year established field ");

		} catch (Exception e) {
			logger.info("creditLineRequested field is not below Noofemployee and Year established field.... "+e.getMessage());	
		}
	}

	@Then("^Verify that the Email Address field is displayed below Phone Number text field on AR page$")
	public void verify_that_the_Email_Address_field_is_displayed_below_Phone_Number_text_field_on_AR_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			ar=new AR_Page(driver);
			ar.valiEmailAddressinAR(); 
			gu.captureupdateOTR(driver, document, " creditLineRequested is below Noofemployee and Year established field ");

		} catch (Exception e) {
			logger.info("creditLineRequested field is not below Noofemployee and Year established field.... "+e.getMessage());	
		}
	}

	@Then("^Verify that the Email Address field is removed from the PG Page$")
	public void verify_that_the_Email_Address_field_is_removed_from_the_PG_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			pg =new PG_Page(driver);
			pg.verifyEmailaddressRemoved();
			gu.captureupdateOTR(driver, document, " creditLineRequested is below Noofemployee and Year established field ");
		} catch (Exception e){
			logger.info("creditLineRequested field is not below Noofemployee and Year established field.... "+e.getMessage());
		}

	}

	@Then("^Verify that the Personal Phone field is removed from the PG Page$")
	public void verify_that_the_Personal_Phone_field_is_removed_from_the_PG_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			pg =new PG_Page(driver);
			pg.verifyPgPhonenumberRemoved();
			gu.captureupdateOTR(driver, document, " creditLineRequested is below Noofemployee and Year established field ");
		} catch (Exception e){
			logger.info("creditLineRequested field is not below Noofemployee and Year established field.... "+e.getMessage());
		}

	}

	@Then("^validate Tap for details Link for the Top banner-Displayed$")
	public void validate_Tap_for_details_Link_for_the_Top_banner_Displayed() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try{
			bi=new BusinessInfo_Page(driver);
			bi.ValidateTapfordetailsLink();
			gu.captureupdateOTR(driver, document, "Tap for details link is below the top banner in BI Page");

		}
		catch (Exception e){
			logger.info("Tap for details link is not below the top banner in BI Page"+e.getMessage());
		}
	} 

	@Then("^Tap for details Link should be displayed and should validate hide details and verbiage$")
	public void tap_for_details_Link_should_be_displayed_and_should_validate_hide_details_and_verbiage() throws Throwable {

		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateTapfordetailsVerbiage();

			gu.captureupdateOTR(driver, document, "Hide details text and TapforDetailsverbiage is displayed ");
		}
		catch (Exception e){
			logger.info("HideDetailstext and TapforDetails verbiage is not displayed"+e.getMessage());
		}  
	}	

	@Then("^click on hide details Link and validate the verbiage hidden$")
	public void click_on_hide_details_Link_and_validate_the_verbiage_hidden() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateverbiagehidden();
			gu.captureupdateOTR(driver, document, "TapforDetails verbiage is hidden");
		}
		catch (Exception e){
			logger.info("TapforDetails verbiage is not hidden"+e.getMessage());
		} 
	}

	@Then("^Validate the section horizontal line and section icon should displayed$")
	public void validate_the_section_horizontal_line_and_section_icon_should_displayed() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateHorizontallineandSectionicon();
			gu.captureupdateOTR(driver, document, "Section horizontal line and Section icon is displayed");
		}
		catch (Exception e){
			logger.info("Section horizontal line and Section icon is not displayed"+e.getMessage());
		} 

	}
	@Then("^Validate HeaderinfoTextParagraph and should displayed below Sub Header$")
	public void validate_HeaderinfoTextParagraph_and_should_displayed_below_Sub_Header() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateHeaderinfoTextdisplayedbelowSubHeader();
			gu.captureupdateOTR(driver, document, "Headerinfotext is displayed below subheader in Bipage");
		}
		catch (Exception e){
			logger.info("Headerinfotext is not displayed below subheader in Bipage"+e.getMessage());
		} 

	}

	@Then("^validate MainHeadersection is displayed below the section horizontal line in Bi page$")
	public void validate_MainHeadersection_is_displayed_below_the_section_horizontal_line_in_Bi_page() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateMainHeaderSection();
			//gu.captureupdateOTR(driver, document, "MainHeaderInfo is below the Section horizontalline in Bipage");
		}
		catch (Exception e){
			logger.info("MainHeaderInfo is not below the Section horizontalline in Bipage"+e.getMessage());
		}   


	}


	@Then("^validate the Subheader section is displayed below the Mainheader section$")
	public void validate_the_Subheader_section_is_displayed_below_the_Mainheader_section() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validatesubheadersection();
		}
		catch (Exception e){
			logger.info("Subheadersection is not below the MainHeadersection in Bipage"+e.getMessage());
		}   

	}

	@Then("^validate TermsandConditions link should displayed$")
	public void validate_TermsandConditions_link_should_displayed() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateTermsandconditionslink();
		}
		catch (Exception e){
			logger.info("pleasereadTermsandConditions text is not below the progresbar in Bipage"+e.getMessage());
		}   

	}

	@Then("^user should click on TermsandConditions link and validate modal window$")
	public void user_should_click_on_TermsandConditions_link_and_validate_modal_window() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateModelWindow();
		}
		catch (Exception e){
			logger.info("TermsandConditions are not displayed in ModelWindow"+e.getMessage());
		}   
	}

	@Then("^user should click on cross symbol and should validate the page is back to Bussiness info$")
	public void user_should_click_on_cross_symbol_and_should_validate_the_page_is_back_to_Bussiness_info() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.verifyBusinessInfoPageisbackafterclickingOnCrossButton();
		}
		catch (Exception e){
			logger.info("BusinessInfoPage is back after clicking On CrossButton in terms and conditions"+e.getMessage());
		}   

	}

	@Then("^user should Verify the Progress bar is displayed$")
	public void user_should_Verify_the_Progress_bar_is_displayed() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateProgressbarinBipage();
		}
		catch (Exception e){
			logger.info("Subheadersection is not below the MainHeadersection in Bipage"+e.getMessage());
		}    
	}

	@Then("^user should Verify  the Offer Area A is displayed$")
	public void user_should_Verify_the_Offer_Area_A_is_displayed() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateOfferBannerA();
		}
		catch (Exception e){
			logger.info("OfferbannerA  is not displayed below the SamsclubLogo in Bipage"+e.getMessage());
		}     
	}

	@When("^user click on Company contact validate the verbiage \"([^\"]*)\"$")
	public void user_click_on_Company_contact_validate_the_verbiage(String Bicomapnycontactverbiage) throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateCompanyContactVerbiage(Bicomapnycontactverbiage);
		}
		catch (Exception e){
			logger.info("OfferbannerA  is not displayed below the SamsclubLogo in Bipage"+e.getMessage());
		}  
	}

	@When("^verify that info text This person will be primary contact is disappered when user click outside company contact field$")
	public void verify_that_info_text_This_person_will_be_primary_contact_is_disappered_when_user_click_outside_company_contact_field() throws Throwable {
		try{
			bi=new BusinessInfo_Page(driver);
			bi.validateCompanyContactVerbiagedisappear( );
		}
		catch (Exception e){
			logger.info("CompanyContact Verbiage not disappeared after clicking outside company contact in Bipage"+e.getMessage());
		}  
	}

	@Then("^Verify the check box above BusinessPhone and Ext is unchecked and validate Billingaddressverbiage is appear when user click on billing address field \"([^\"]*)\"$")
	public void verify_the_check_box_above_BusinessPhone_and_Ext_is_unchecked_and_validate_Billingaddressverbiage_is_appear_when_user_click_on_billing_address_field(String BiBillingaddressverbiage) throws Throwable {

		try{
			bi=new BusinessInfo_Page(driver);
			bi.validatecheckboxisUncheckedandbillingaddressverbiage(BiBillingaddressverbiage);
		}
		catch (Exception e){
			logger.info("CompanyContact Verbiage not disappeared after clicking outside company contact in Bipage"+e.getMessage());
		}  	
	}

	@Then("^validate billing address info text is diappeared when user clicked outside billing address field$")
	public void validate_billing_address_info_text_is_diappeared_when_user_clicked_outside_billing_address_field() throws Throwable {
		bi=new BusinessInfo_Page(driver);
		bi.validateBillingaddressVerbiagedisappear( );
	}

	@Then("^verify Businessaddress info text is appeared when user click on Businessaddress field \"([^\"]*)\"$")
	public void verify_Businessaddress_info_text_is_appeared_when_user_click_on_Businessaddress_field(String BiBusinessaddressverbiage) throws Throwable {

		bi=new BusinessInfo_Page(driver);
		bi.validateBusinessaddressverbiage(BiBusinessaddressverbiage);
	}

	@Then("^validate Businessaddress info text is diappeared when user click on outside Businessaddress field$")
	public void validate_Businessaddress_info_text_is_diappeared_when_user_click_on_outside_Businessaddress_field() throws Throwable {

		bi=new BusinessInfo_Page(driver);
		bi.validateBusinessaddressVerbiagedisappear( );
	}

	@Then("^verify Businessphone info text is appeared when user click on Businessphone field \"([^\"]*)\"$")
	public void verify_Businessphone_info_text_is_appeared_when_user_click_on_Businessphone_field(String BiBusinessPhoneverbiage) throws Throwable {
		bi=new BusinessInfo_Page(driver);
		bi.validateBusinessphoneverbiage(BiBusinessPhoneverbiage);
	}

	@Then("^validate Businessphone info text is diappeared when user click on outside Businessphone field$")
	public void validate_Businessphone_info_text_is_diappeared_when_user_click_on_outside_Businessphone_field() throws Throwable {

		bi=new BusinessInfo_Page(driver);
		bi.validateBusinessphoneVerbiagedisappear( );
	}

	@Then("^validate second section fields displayed along with below fieldtext$")
	public void validate_second_section_fields_displayed_along_with_below_fieldtext() throws Throwable {

		bi=new BusinessInfo_Page(driver);
		bi.validateSecondsectionfieldsalongwithbelowfieldtext( );
			}

	@Then("^validate the Second Section horizontal line is displayed below the company contact$")
	public void validate_the_Second_Section_horizontal_line_is_displayed_below_the_company_contact() throws Throwable {

		bi=new BusinessInfo_Page(driver);
		bi.validatesecondsectionhorizontallineisbelowthecompanycontact( );
		
	}

	@Then("^validate the Businessphone and Ext text fields are displayed below the billingaddress checkbox of Second section$")
	public void validate_the_Businessphone_and_Ext_text_fields_are_displayed_below_the_billingaddress_checkbox_of_Second_section() throws Throwable {

		bi=new BusinessInfo_Page(driver);
		bi.validatebusinessphoneandExttextfieldsarebelowsecondsectioncheckbox( );
	}

	@Then("^validate all the below fields after unchecking the billingaddress checkbox$")
	public void validate_all_the_below_fields_after_unchecking_the_billingaddress_checkbox() throws Throwable {

		bi=new BusinessInfo_Page(driver);
		bi.validateallfieldsafteruncheckingthebillingaddresscheckbox( );
		
	}
	
	
		
	@When("^User enter BI page details by making default check of billing address \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enter_BI_page_details_by_making_default_check_of_billing_address(String CompanyFullLegalName, String DBAName, String TypeOfBusiness, String PromCode, String BusinessAddress, String Suite, String ZipCode, String BusinessPhone, String Ext, String EmailAddress, String TaxPayerId, String DunAndBstreetNumber, String NumberOfEmployes, String YearEstablished, String RequestedCreditLine) throws Throwable {
		try {
			bi=new BusinessInfo_Page(driver);
			bi.EnterallBIpageDetailsInLowes(CompanyFullLegalName, DBAName, TypeOfBusiness, PromCode, BusinessAddress, Suite, ZipCode, BusinessPhone, Ext, EmailAddress, TaxPayerId, DunAndBstreetNumber, NumberOfEmployes, YearEstablished, RequestedCreditLine);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");

		} catch (Exception e) {
			logger.info("Issue in entering values in business info  page.... "+e.getMessage());	
		}
		
	}

	

@Then("^validate TapforDetails Link should Displayed below the Bottom banner$")
public void validate_TapforDetails_Link_should_Displayed_below_the_Bottom_banner() throws Throwable {
  
	try{
		bi=new BusinessInfo_Page(driver);
		bi.ValidateTapForDetailsLinkbelowtheBottomBanner();
	}
	catch (Exception e){
		logger.info("Tapfordetails link is not Present below the Bottom banner in BI Page"+e.getMessage());
	}
}

@Then("^click on TapforDetails link and should validate HideDetails text and verbiage for Bottom banner$")
public void click_on_TapforDetails_link_and_should_validate_HideDetails_text_and_verbiage_for_Bottom_banner() throws Throwable {
    
	try{
		bi=new BusinessInfo_Page(driver);
		bi.validateTapfordetailsVerbiageforBottonbanner();

		gu.captureupdateOTR(driver, document, "Hide details text and TapforDetailsverbiage is displayed for Bottom banner ");
	}
	catch (Exception e){
		logger.info("HideDetailstext and TapforDetails verbiage is not displayed for Bottom banner"+e.getMessage());
	}  
}

@Then("^click on hide details Link and validate the verbiage hidden below the Bottom banner$")
public void click_on_hide_details_Link_and_validate_the_verbiage_hidden_below_the_Bottom_banner() throws Throwable {
  
	try{
		bi=new BusinessInfo_Page(driver);
		bi.validateverbiagehiddenforBottombanner();
		gu.captureupdateOTR(driver, document, "tap for details for Bottom banner verbiage is hidden");
	}
	catch (Exception e){
		logger.info("TapforDetails verbiage is not hidden"+e.getMessage());
	} 
}


@Then("^validate the Third section fields should displayed in Business Info page$")
public void validate_the_Third_section_fields_should_displayed_in_Business_Info_page() throws Throwable {
 
	bi=new BusinessInfo_Page(driver);
	bi.validateThirdsectionfields();

}

@Then("^validate the Third Section horizontal line should displayed in BI page$")
public void validate_the_Third_Section_horizontal_line_should_displayed_in_BI_page() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validateThirdSectionHorizontalline();
   
}

@Then("^user should Verify the Offer Area B is displayed at the bottom of the BI page$")
public void user_should_Verify_the_Offer_Area_B_is_displayed_at_the_bottom_of_the_BI_page() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validateOfferBannerB();
   
}

@Then("^validate the TaxPayerID verbiage should display when user click on the TaxPayerID text field \"([^\"]*)\"$")
public void validate_the_TaxPayerID_verbiage_should_display_when_user_click_on_the_TaxPayerID_text_field(String BITaxPayerIDVerbiage) throws Throwable {
   
	bi=new BusinessInfo_Page(driver);
	bi.validateTaxPayerIDinfotext(BITaxPayerIDVerbiage);
}

@Then("^validate TaxPayerID info text is disappeared when user click on outside of the TaxPayerID field$")
public void validate_TaxPayerID_info_text_is_disappeared_when_user_click_on_outside_of_the_TaxPayerID_field() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validateTaxPayerIDinfotextdisappear();
}

@Then("^validate the Dun&Bradstreet Number Infotext should display when user click on Dun & Bradstreet Number text field \"([^\"]*)\"$")
public void validate_the_Dun_Bradstreet_Number_Infotext_should_display_when_user_click_on_Dun_Bradstreet_Number_text_field(String BIDunandBradstreetverbiage) throws Throwable {
   
	bi=new BusinessInfo_Page(driver);
	bi.validateDunandBradstreetinfotext(BIDunandBradstreetverbiage);
}

@Then("^validate Dun & Bradstreet Number info text is disappeared when user click on outside of the Dun & Bradstreet Number field$")
public void validate_Dun_Bradstreet_Number_info_text_is_disappeared_when_user_click_on_outside_of_the_Dun_Bradstreet_Number_field() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validateDunandBradStreetinfotextDisappear();
}

@Then("^user should click on consent to Electronic Communications link and validate the modal window  should displayed$")
public void user_should_click_on_consent_to_Electronic_Communications_link_and_validate_the_modal_window_should_displayed() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validateConsenttoEClinkmodelwindow();
}

@Then("^validate the model window should be closed after clicking the Close button$")
public void validate_the_model_window_should_be_closed_after_clicking_the_Close_button() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validatecloseModelWindow();
}

@Then("^user should click on Privacy Policy link and validate the modal window  should displayed$")
public void user_should_click_on_Privacy_Policy_link_and_validate_the_modal_window_should_displayed() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validatePrivacypolicylinkmodelwindow();
}

@Then("^user should click on Web Site Usage Agreement link and validate the modal window  should displayed$")
public void user_should_click_on_Web_Site_Usage_Agreement_link_and_validate_the_modal_window_should_displayed() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validateWenSiteusageAgreementModelwindow(); 
}

@Then("^user should click on SYF Internet Privacy Policy link and validate the modal window should displayed$")
public void user_should_click_on_SYF_Internet_Privacy_Policy_link_and_validate_the_modal_window_should_displayed() throws Throwable {
   
	bi=new BusinessInfo_Page(driver);
	bi.validateSYFInternetPrivacypolicyModelwindow();
}

@Then("^user should validate the First section fields in BI page$")
public void user_should_validate_the_First_section_fields_in_BI_page() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validateBIFirstSectionFields();
}

@Then("^user should validate the Footersection displayed at bottom of the BI page$")
public void user_should_validate_the_Footersection_displayed_at_bottom_of_the_BI_page() throws Throwable {
	bi=new BusinessInfo_Page(driver);
	bi.validateFooterSectionInBI();
}

@When("^User should enter BI page details  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
public void user_should_enter_BI_page_details(String CompanyFullLegalName, String TypeOfBusiness, String CompanyContact, String BusinessAddress, String Suite, String ZipCode, String BusinessPhone, String Ext, String TaxPayerId, String DunAndBstreetNumber, String YearEstablished) throws Throwable {
   
	bi=new BusinessInfo_Page(driver);
	bi.EnterBiFieldDetailsforsams(CompanyFullLegalName,TypeOfBusiness,CompanyContact,BusinessAddress,Suite,ZipCode,BusinessPhone,Ext,TaxPayerId,DunAndBstreetNumber,YearEstablished);
}

@Then("^Verify that applicant role subnav should displayed$")
public void verify_that_applicant_role_subnav_should_dispalyed() throws Throwable {
	ar=new AR_Page(driver);
	ar.validateApplicantSubnavinAR(); 
    
}

@Then("^verify applicant role subnav should display with the following fields AR PG CT and BO$")
public void verify_applicant_role_subnav_should_display_with_the_following_fields_AR_PG_CT_and_BO() throws Throwable {
   
	ar=new AR_Page(driver);
	ar.validateApplicantSubnavfields(); 
    
}


@Then("^validate horizontallines of applicantsubnavigation should displayed$")
public void validate_horizontallines_of_applicantsubnavigation_should_displayed() throws Throwable {

	ar=new AR_Page(driver);
	ar.validateHorizontallinesofApplicantsubnav();
}

@Then("^validate that the Horizontal line and Section icon are displayed with the Sams branding$")
public void validate_that_the_Horizontal_line_and_Section_icon_are_displayed_with_the_Sams_branding() throws Throwable {
	
	ar=new AR_Page(driver);
	ar.validateHorizontallineWithSectionIconinARpage(); 
}

@Then("^validate that the Secondary header section is displayed in AR page$")
public void validate_that_the_Secondary_header_section_is_displayed_in_AR_page() throws Throwable {
    
	ar=new AR_Page(driver);
	ar.validateSecondaryHeadertextinARpage(); 
}

@Then("^user should validate the Text fields in the AR page are displayed$")
public void user_should_validate_the_Text_fields_in_the_AR_page_are_displayed() throws Throwable {
	ar=new AR_Page(driver);
	ar.validateAllTextFieldsinARpage();
}

@Then("^validate applicant role subnav should display the following fields as AR and PG$")
public void validate_applicant_role_subnav_should_display_the_following_fields_as_AR_and_PG() throws Throwable {
	ar=new AR_Page(driver);
	ar.validateApplicantSubnavfieldsARandPG();
}

@Then("^user should verify Continue button is displayed below the Email address textfield in AR page$")
public void user_should_verify_Continue_button_is_displayed_below_the_Email_address_textfield_in_AR_page() throws Throwable {
	ar=new AR_Page(driver);
	ar.validateContinuebuttonIsBelowtheEmailadrressfieldinARpage();
}

@Then("^Validate the text below the continue button should displayed in AR page$")
public void validate_the_text_below_the_continue_button_should_displayed_in_AR_page() throws Throwable {
	ar=new AR_Page(driver);
	ar.validateTextIsDisplayedbelowtheContinuebuttoninARpage(); 
}

@Then("^validate  the Main header section should displayed in AR page$")
public void validate_the_Main_header_section_should_displayed_in_AR_page() throws Throwable {
	ar=new AR_Page(driver);
	ar.validateMainHeadertextinARpage();
}


@Then("^user should Verify the Secondary header section along with paragraph is displayed$")
public void user_should_Verify_the_Secondary_header_section_along_with_paragraph_is_displayed() throws Throwable {
	ar=new AR_Page(driver);
	ar.validateSubHeaderAlongwithparagraph();
	
}

@Then("^verify Emailaddress info text is appeared when user click on Emailaddress field in ARpage \"([^\"]*)\"$")
public void verify_Emailaddress_info_text_is_appeared_when_user_click_on_Emailaddress_field_in_ARpage(String AREmailAddressinfo) throws Throwable {
	ar=new AR_Page(driver);
	ar.ValidateEmailAddressinfotext(AREmailAddressinfo);
}

@Then("^validate Emailaddress info text is disappeared when user click on outside Emailaddress field in ARpage$")
public void validate_Emailaddress_info_text_is_disappeared_when_user_click_on_outside_Emailaddress_field_in_ARpage() throws Throwable {
	ar=new AR_Page(driver);
	ar.ValidateEmailAddressinfotextdisappeared();   
}

@Then("^verify FirstName info text is appeared when user click on FirstName field in ARpage \"([^\"]*)\"$")
public void verify_FirstName_info_text_is_appeared_when_user_click_on_FirstName_field_in_ARpage(String ARFirstNameinfo) throws Throwable {
    
	ar=new AR_Page(driver);
	ar.ValidateFirstNameinfotext(ARFirstNameinfo);
}

@Then("^validate FirstName info text is disappeared when user click on outside FirstName field in ARpage$")
public void validate_FirstName_info_text_is_disappeared_when_user_click_on_outside_FirstName_field_in_ARpage() throws Throwable {
	ar=new AR_Page(driver);
	ar.ValidateFirstNameinfotextdisappeared(); 
}

@Then("^verify MembershipNumber info text is appeared when user click on MembershipNumber field in ARpage \"([^\"]*)\"$")
public void verify_MembershipNumber_info_text_is_appeared_when_user_click_on_MembershipNumber_field_in_ARpage(String ARMembershipNumberinfo) throws Throwable {
	ar=new AR_Page(driver);
	ar.ValidateMembershipNumberinfotext(ARMembershipNumberinfo);
}

@Then("^validate MembershipNumber info text is disappeared when user click on outside MembershipNumber field in ARpage$")
public void validate_MembershipNumber_info_text_is_disappeared_when_user_click_on_outside_MembershipNumber_field_in_ARpage() throws Throwable {
	ar=new AR_Page(driver);
	ar.ValidateMembershipNumberinfotextdisappeared(); 
}

@Then("^verify PhoneNumber info text is appeared when user click on PhoneNumber field in ARpage \"([^\"]*)\"$")
public void verify_PhoneNumber_info_text_is_appeared_when_user_click_on_PhoneNumber_field_in_ARpage(String ARPhoneNumberinfo) throws Throwable {
	ar=new AR_Page(driver);
	ar.ValidatePhoneNumberinfotext(ARPhoneNumberinfo);
}

@Then("^validate PhoneNumber info text is disappeared when user click on outside PhoneNumber field in ARpage$")
public void validate_PhoneNumber_info_text_is_disappeared_when_user_click_on_outside_PhoneNumber_field_in_ARpage() throws Throwable {
	ar=new AR_Page(driver);
	ar.ValidatePhoneNumberinfotextdisappeared(); 
}

@Then("^user enters valid PG page field details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
public void user_enters_valid_PG_page_field_details(String PgHomeAddress, String PgZipCode, String PgSsn, String PgDob, String PgAnuualNetIncome) throws Throwable {
	
		// Write code here that turns the phrase above into concrete actions
		pg =new PG_Page(driver);
		pg.EntervalueInPGFields(PgHomeAddress, PgZipCode, PgSsn, PgDob, PgAnuualNetIncome);
		// gu.pageScrollUpByPixel(driver);
		gu.captureupdateOTR(driver, document, " Entered PG page field values");	

}

@When("^user clicks on please verify customer checkbox$")
public void user_clicks_on_please_verify_customer_checkbox() throws Throwable {
	lp=new Landing_Page(driver);
	lp.Click_verifycustomer();
}

@When("^User enter AR Field values and validate with different test data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
public void user_enter_AR_Field_values_and_validate_with_different_test_data(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    
}

}
