package com.cmlb2bapply.pageobject;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.LogStatus;

public class Options_Page extends RunnerTest  {

	//Utilities-Object Creation
	GenericUtilities gu=new GenericUtilities();

	public Options_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	@FindBy(name="opAdditionalBuyer")
	private WebElement dropdown_opBuyerType;

	@FindBy(id="opSingleSaleTransactions")
	private WebElement input_opSingleSaleTransactions;

	@FindBy(id="orderCheck")
	private WebElement input_orderCheck;

	@FindBy(id="addBuyers[0].chkSendCard")
	private WebElement input_chkboxSendCard1;

	@FindBy(id="addBuyers[1].chkSendCard")
	private WebElement input_chkboxSendCard2;

	@FindBy(id="addBuyers[2].chkSendCard")
	private WebElement input_chkboxSendCard3;

	@FindBy(id="addBuyers[3].chkSendCard")
	private WebElement input_chkboxSendCard4;

	@FindBy(name="addBuyers[0].opBuyerType")
	private WebElement select_opBuyerType0;

	@FindBy(name="addBuyers[0].opFirstName")
	private WebElement input_opFirstName0;

	@FindBy(name="addBuyers[0].opLastName")
	private WebElement input_opLastName0;

	//@FindBy(name="addBuyers[1].opBuyerType")
	@FindBy(xpath="//select[@name='addBuyers[1].opBuyerType']")
	private WebElement select_opBuyerType1;

	@FindBy(name="addBuyers[1].opFirstName")
	private WebElement input_opFirstName1;

	@FindBy(name="addBuyers[1].opLastName")
	private WebElement input_opLastName1;

	//@FindBy(xpath="//select[@name='addBuyers[2].opBuyerType']")
	@FindBy(name="addBuyers[2].opBuyerType")
	private WebElement select_opBuyerType2;

	@FindBy(name="addBuyers[2].opFirstName")
	private WebElement input_opFirstName2;

	@FindBy(name="addBuyers[2].opLastName")
	private WebElement input_opLastName2;

	@FindBy(name="addBuyers[3].opBuyerType")
	//@FindBy(xpath="//*[@*='addBuyers[3].opBuyerType']")
	private WebElement select_opBuyerType3;

	@FindBy(name="addBuyers[3].opFirstName")
	private WebElement input_opFirstName3;

	@FindBy(name="addBuyers[3].opLastName")
	private WebElement input_opLastName3;

	//@FindBy(xpath="//*[contains(text(),'Add another buyer')]")
	@FindBy(xpath="//*[@id='root']/div/div[5]/div/div[1]/form/div[1]/div[2]/div[2]/div[*]/div/span/div")
	private WebElement link_AddAnotherBuyer;

	@FindBy(xpath="(//span[contains(text(),'Remove')])[1]")
	private WebElement link_RemoveThisPerson1;

	@FindBy(xpath="(//span[contains(text(),'Remove')])[2]")
	private WebElement link_RemoveThisPerson2;

	@FindBy(xpath="(//span[contains(text(),'Remove')])[3]")
	private WebElement link_RemoveThisPerson3;

	@FindBy(xpath="//button[contains(text(),'Continue')]")
	private WebElement click_continueButton;
	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;


	public void Click_ContinueButton() throws Exception{
		try {
			click_continueButton.click();
			logger.info("User clicks on Continue Button");
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button");
			throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			throw(e2);
		}
	}
	public void OptionsPage_Elementvalidation(WebDriver driver) throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, dropdown_opBuyerType, 10)){
				status=true;
			}else{
				status=false;
			}
		}catch(Exception e){

			e.printStackTrace();
			throw(e);
		}
		Assert.assertTrue(status, "Options Page Filed Validation failed");
	}

	public void navigatedTo_OptionsPage(WebDriver driver) throws Exception{
		//Thread.sleep(2000);
		try{
			String urlNew = driver.getCurrentUrl();
			if (urlNew.contains("options")){
				logger.info("Navigated to options  page");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"---Navigated to options  page--- :" + loggerE.addScreenCapture(screenshotPath));
			}
		}catch(Exception e){
			e.printStackTrace();
			logger.info("Not Navigated to options  page"+e.getMessage());
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.FAIL ,"----Not Navigated to options  page--- :" + loggerE.addScreenCapture(screenshotPath));
			//throw(e);
		}
	}
	public void selectAddBuyer(String AddBuyer) throws Exception{
		try {
			gu.selectdropdown(dropdown_opBuyerType, "value",AddBuyer );
			logger.info(" add buyer  value selected  :"+dropdown_opBuyerType);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," add buyer  value selected  :"+dropdown_opBuyerType + loggerE.addScreenCapture(screenshotPath));
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in selecting  AddBuyer" + e1.getMessage());
			System.out.println("Issue in selecting  AddBuyerr" + e1.getMessage());
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.FAIL ,"Issue in selecting  AddBuyer" + e1.getMessage()+ loggerE.addScreenCapture(screenshotPath));
			//throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info(e2.getMessage());
			//throw(e2);
		}
	}
	public void limitForSingleSaleTranx(String LmitForSingleSaleTxn) throws Exception{
		try {
			if(input_opSingleSaleTransactions.isDisplayed()==true){
				gu.entertext(input_opSingleSaleTransactions, LmitForSingleSaleTxn);
				logger.info("input_opSingleSaleTransactions value entered :"+LmitForSingleSaleTxn); 
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage()); 
		}
	}
	public void ClickOrderCheckBox() throws Exception{
		try {
			//gu.click(input_orderCheck);
			gu.clickByJs(driver, "orderCheck");
			logger.info("clicked on ordercheck box");
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage()); 
		}
	}
	public void EnterValuesInOptionsField0(String opAB0, String opFirstName0 ,String opLastName0) throws Exception{
		try {
			gu.selectdropdown(select_opBuyerType0, "text",opAB0 );
			gu.entertext(input_opFirstName0, opFirstName0);
			//logger.info("input_opFirstName0 value entered :"+input_opFirstName0);
			//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			//loggerE.log(LogStatus.PASS ,"opFirstName0 value entered: "+opFirstName0 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_opLastName0, opLastName0);
			//logger.info("input_opLastName0 value entered :"+input_opLastName0);
			//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			//loggerE.log(LogStatus.PASS ,"opLastName0 value entered: "+opLastName0 + loggerE.addScreenCapture(screenshotPath));
			gu.click(input_chkboxSendCard1);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"send card check box 0 is clicked : " + loggerE.addScreenCapture(screenshotPath));

		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}
	}


	public void EnterfewmorevalueInOptionsPage(String opFirstName0) throws Exception{
		try {				
			gu.entertext(input_opFirstName0, opFirstName0);
			//logger.info("input_opFirstName0 value entered :"+input_opFirstName0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"opFirstName0 value entered: "+opFirstName0 + loggerE.addScreenCapture(screenshotPath));		
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}
	}

	public void EnterfewvalueInOptionsPage(String LmitForSingleSaleTxn,String opAB0 ) throws Exception{
		try {


			if(input_opSingleSaleTransactions.isDisplayed()==true){
				gu.entertext(input_opSingleSaleTransactions, LmitForSingleSaleTxn);
				logger.info("input_opSingleSaleTransactions value entered :"+LmitForSingleSaleTxn); 
			}			
			gu.selectdropdown(select_opBuyerType0, "text",opAB0 );				
			//logger.info("input_opFirstName0 value entered :"+input_opFirstName0);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);				
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}
	}

	public void EnterValuesInOptionsField1(String opAB1, String opFirstName1 ,String opLastName1) throws Exception{
		Thread.sleep(2000);
		Thread.sleep(2000);
		boolean status=false;
		try {
			if(select_opBuyerType1.isDisplayed()==true){

				gu.selectdropdown(select_opBuyerType1, "text", opAB1);
				//gu.selecDropDownByInx(select_opBuyerType1, "1");
				status=true;
			}

			if(input_opFirstName1.isDisplayed()==true){
				gu.entertext(input_opFirstName1, opFirstName1);
				//logger.info("input_opFirstName1 value entered :"+input_opFirstName1);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"opFirstName1 value entered: "+opFirstName1 + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_opLastName1, opLastName1);
				//logger.info("input_opLastName1 value entered :"+input_opLastName1);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"opLastName1 value entered: "+opLastName1 + loggerE.addScreenCapture(screenshotPath));

				gu.click(input_chkboxSendCard2);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"send card check box 1 is clicked : " + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				logger.info("drop down issue in option page");
				status=false;
			}
			Assert.assertTrue(status, "Add buyers");
		} catch (Exception e) {
			status=false;
			// TODO: handle exception
			logger.info(e.getMessage());
		}
		Assert.assertTrue(status, "Add buyers");
	}
	public void EnterValuesInOptionsField2(String opAB2, String opFirstName2 ,String opLastName2) throws Exception{
		Thread.sleep(2000);
		try {
			gu.selectdropdown(select_opBuyerType2, "text",opAB2 );
			gu.entertext(input_opFirstName2, opFirstName2);
			//logger.info("input_opFirstName2 value entered :"+input_opFirstName2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"opFirstName2 value entered: "+opFirstName2 + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_opLastName2, opLastName2);
			//logger.info("input_opLastName2 value entered :"+input_opLastName2);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"opLastName2 value entered: "+opLastName2 + loggerE.addScreenCapture(screenshotPath));
			gu.click(input_chkboxSendCard3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"send card check box 2 is clicked: " + loggerE.addScreenCapture(screenshotPath));

		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}
	}
	public void EnterValuesInOptionsField3(String opAB3, String opFirstName3 ,String opLastName3) throws Exception{
		//Thread.sleep(2000);
		try {
			//gu.selectdropdown(select_opBuyerType3, "text",opAB3 );
			gu.selectdropdown(select_opBuyerType3, "value",opAB3 );
			gu.entertext(input_opFirstName3, opFirstName3);
			//logger.info("input_opFirstName3 value entered :"+input_opFirstName3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"opFirstName3 value entered: "+opFirstName3 + loggerE.addScreenCapture(screenshotPath));


			gu.entertext(input_opLastName3, opLastName3);
			//logger.info("input_opLastName3 value entered :"+input_opLastName3);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"opLastName3 value entered: "+opLastName3 + loggerE.addScreenCapture(screenshotPath));

			gu.click(input_chkboxSendCard4);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"send card check box 3 is clicked: "+ loggerE.addScreenCapture(screenshotPath));


		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}
	}
	public void clickAddAnotherBuyer() throws Exception{
		//Thread.sleep(2000);
		try {
			//gu.click(link_AddAnotherBuyer);
			//gu.clickByJs(driver, "Add another buyer");
			//WebElement nameInputField = driver.findElement(By.xpath("//*[@id='root']/div/div[5]/div/div[1]/form/div[1]/div[2]/div[2]/div[*]/div/span/div"));
			WebElement nameInputField = driver.findElement(By.xpath("//*[contains(text(),'Add another buyer')]"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", nameInputField);				
			logger.info("Clicked on link_AddAnotherBuyer");
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}
	}
	public void validateText(String EnteredText)  throws Exception{
		try {
			String actVal =gu.getEnteredText(select_opBuyerType0);
			if(actVal.equals(EnteredText)){
				//Assert.assertEquals(actVal, EnteredText);
				logger.info(" actual = "+EnteredText);
				gu.captureupdateOTR(driver, document, " Previously entered data is retained, user can continue filling the page further ");
				System.out.println("Previously entered data is retained, user can continue filling the page further");
			}
			else
			{
				System.out.println("Previously entered value is erased, user should start filling the page again");
				gu.captureupdateOTR(driver, document, " Previously entered value is erased, user should start filling the page again ");
			}
		} catch (Exception e) {
			logger.info(e.getMessage());

		}
	}
	public void ValiSendCardChkbox() throws Exception{
		try{
			WebElement CheckBox1=input_chkboxSendCard1;
			WebElement CheckBox2=input_chkboxSendCard2;
			WebElement CheckBox3=input_chkboxSendCard3;
			WebElement CheckBox4=input_chkboxSendCard4;
			gu.WaitForElePresent(input_chkboxSendCard1, wait1);

			/*if(!input_chkboxSendCard1.isSelected()){
                  gu.pageScrollDownWithEle(driver, input_chkboxSendCard1);
                  System.out.println("SendCard Checkbox present");
                  //input_chkboxSendCard1.click();
             }*/
			if(!CheckBox1.isSelected()){
				gu.pageScrollDownWithEle(driver, CheckBox1);
				System.out.println("SendCard Checkbox present");
				//input_chkboxSendCard1.click();
			}
			else if(!CheckBox2.isSelected()){
				gu.pageScrollDownWithEle(driver, CheckBox2);
				System.out.println("SendCard Checkbox present");
				//input_chkboxSendCard1.click();
			}
			else if(!CheckBox3.isSelected()){
				gu.pageScrollDownWithEle(driver, CheckBox3);
				System.out.println("SendCard Checkbox present");
				//input_chkboxSendCard1.click();
			}
			else if(!CheckBox4.isSelected()){
				gu.pageScrollDownWithEle(driver, CheckBox4);
				System.out.println("SendCard Checkbox present");
				//input_chkboxSendCard1.click();
			}
			else
			{
				System.out.println("Invalid CheckBox Selection");
			}
			//Thread.sleep(1000);
			gu.captureupdateOTR(driver, document, "SendCard Checkbox present");      
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			logger.info("Issue in checking SendCard checkbox... "+e.getMessage());
		} 
	}  

	public void ClicksSendCardChkbox(String webelementofCheckBox) throws Exception{
		try{
			WebElement CheckBox = driver.findElement(By.id(webelementofCheckBox)); 
			gu.WaitForElePresent(CheckBox, wait1);

			if(!CheckBox.isSelected()){
				gu.pageScrollDownWithEle(driver, CheckBox);                     
				CheckBox.click();
				System.out.println("SendCard Checkbox clicked");
			}
			else
			{
				System.out.println("Invalid CheckBox cannot be checked");
			}
			gu.captureupdateOTR(driver, document, "SendCard Checkbox checked");      
		}
		catch(Exception e)
		{
			logger.info("Issue in checking SendCard checkbox... "+e.getMessage());

		}
	}
	public void UncheckSendCardChkbox(String webelementofCheckBox) throws Exception{
		try{
			WebElement CheckBox = driver.findElement(By.xpath(webelementofCheckBox)); 
			gu.WaitForElePresent(CheckBox, wait1);

			if(!CheckBox.isSelected()){
				gu.pageScrollDownWithEle(driver, CheckBox);                     
				CheckBox.click();
				System.out.println("SendCard Checkbox unchecked");
			}
			else
			{
				System.out.println("Invalid CheckBox cannot be unchecked");
			}
			gu.captureupdateOTR(driver, document, "SendCard Checkbox unchecked");      
		}
		catch(Exception e)
		{
			logger.info("Issue in unchecking SendCard checkbox... "+e.getMessage());

		}
	}
}

