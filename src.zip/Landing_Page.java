package com.cmlb2bapply.pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.LogStatus;
public class Landing_Page extends RunnerTest  {

	//Utilities-Object Creation
	GenericUtilities gu=new GenericUtilities();

	public Landing_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//input[@id='chkboxbrc']")
	private WebElement checkbox_brc;

	@FindBy(xpath="//input[@id='chkboxprox']")
	private WebElement checkbox_prox;

	@FindBy(xpath="//input[@id='storeNumValue']")
	private WebElement input_storeNumber;

	@FindBy(xpath="//input[@id='associateIDValue']")
	private WebElement input_associateID;

	@FindBy(id="verifyID")
	private WebElement checkbox_verifyID;

	@FindBy(xpath="//button[@id='landingButtom']")
	private WebElement button_getStarted;

	@FindBy(id="companyName")
	private WebElement input_companyName;

	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;
	
	@FindBy(xpath="//input[@type='checkbox']")
	private WebElement CheckboxPrefill;
	

	public void LandingPage_Elementvalidation(WebDriver driver) throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, input_storeNumber, 10)){
				status=true;
			}else{
				status=false;
			}
		}catch(Exception e){

			e.printStackTrace();
			//throw(e);
		}
		Assert.assertTrue(status, "LandingPage-Element Validation failed");
	}
	public void NextPageNavigationValidation(WebDriver driver) throws Exception{

		boolean status=false;	
		try{
			if(gu.WaitForElePresentExplicit(driver, input_companyName, 2000)){
				status=true;
			}else {
				status=false;
			}}
		catch(Exception e){
			e.printStackTrace();
			//throw(e);
		}
		Assert.assertTrue(status, "User not able navigate to business info pafe and comapny field is not vissible");
	}
	public void navigatedTo_BIPage(WebDriver driver) throws Exception{
		boolean status=false;
		gu.fluientWaitforElementToVisible(driver, input_companyName);
		String urlNew = driver.getCurrentUrl();
		try{
			if (urlNew.contains("business-info")){
				logger.info("Navigated to business-info page");
				status=true;
			}
			else
			{
				logger.info("Not Navigated to business-info page");
				status=false;
			}
		}catch(Exception e){
			status=false;
			e.printStackTrace();
			//throw(e);
		}
	}
	public void click_Verify_Id() throws Exception{
		try {
			//gu.click(checkbox_verifyID);
			gu.clickByJs(driver, "verifyID");
			//gu.clickByJs(driver, "checkbox_verifyID");
			logger.info("User clicks on verfiy id  check box");
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking verfiy id checkbox"+e1.getMessage());
			//throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			//throw(e2);

		}
	}
	public void click_Button() throws Exception{
		try {
			gu.fluientWaitforElementToVisible(driver, button_getStarted);
			if(button_getStarted.isDisplayed()){
				//gu.click(button_getStarted);
				gu.clickButtonByJSWithIndex(driver, 0);
				logger.info("User clicks on get started Button");
			}
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking get started Button"+e1.getMessage());
			//throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info(e2.getMessage());
			//throw(e2);
		}
	}
	public void LandingFields(String storeNumValue, String associateIDValue) throws Exception{
		gu.fluientWaitforElementToVisible(driver, input_storeNumber);
		try {
			gu.WaitForElePresentExplicit(driver, input_storeNumber, 2000);
			LandingPage_Elementvalidation(driver);
			logger.info("Landing Page Displayed");

			gu.entertext(input_storeNumber, storeNumValue);
			//logger.info("storeNumValue entered :"+storeNumValue);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"storeNumValue value entered: "+storeNumValue + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_associateID, associateIDValue);
			//logger.info("associateIDValue entered :"+ associateIDValue);
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"associateIDValue value entered: "+associateIDValue + loggerE.addScreenCapture(screenshotPath));
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Entering storeNumValue ,associateIDValue"+e1.getMessage());
			System.out.println("Issue with entering storeNumValue ,associateIDValue ");
			//throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			logger.info("Issue in Entering storeNumValue ,associateIDValue"+e2.getMessage());
			//throw(e2);
		}
	}
	public void Verify_CompanyName_Exist() throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, input_companyName, 20)){
				status=true;
			}else{

				status=false;
			}
		}catch(Exception e){

			e.printStackTrace();
			//throw(e);
		}
		Assert.assertTrue(status, "Companyname field Validation failed");
	}
	public boolean verifyCheckboxisUnticked() throws Exception{

		boolean status=false;	
		try{
			if(!gu.isSelected(checkbox_brc)){
				status=true;
				logger.info("Remember Device Checkbox is Unticked");

			}else {
				status=false;
			}}
		catch(Exception e){
			e.printStackTrace();
			//throw(e);
		}

		return status;
	}
	public void click_checkbox_prox() throws Exception{
		boolean status=false;	
		try {
			//gu.click(checkbox_prox);
			gu.clickByJs(driver, "chkboxprox");
			Thread.sleep(2000);
			logger.info("User clicks on prox  check box");
			status=true;
			Assert.assertTrue(status, "PROX CHECK BOX");
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			status=false;
			logger.info("Issue in Clicking prox checkbox"+e1.getMessage());
			//throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			status=false;
			logger.info("Issue in Clicking prox checkbox"+e2.getMessage());
			//throw(e2);
		}
		Assert.assertTrue(status, "PROX CHECK BOX");
	}
	public void ValiLowesBusinessChkbox() throws Exception{
		try{
			gu.WaitForElePresent(checkbox_brc, wait1);
			if(!checkbox_brc.isSelected()){
				gu.pageScrollDownWithEle(driver, checkbox_brc);
				System.out.println("Brc Checkbox present");
				//checkbox_brc.click();
			}
			//Thread.sleep(1000);
			gu.captureupdateOTR(driver, document, "Brc Checkbox present");           
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			logger.info("Issue in finding checkbox... "+e.getMessage());
		} 
	}
	public void ValiLowesReceivableChkbox() throws Exception{
		try{
			gu.WaitForElePresent(checkbox_prox, wait1);
			if(!checkbox_prox.isSelected()){
				gu.pageScrollDownWithEle(driver, checkbox_prox);
				System.out.println("Prox Checkbox present");
				//checkbox_prox.click();
			}
			//Thread.sleep(1000);
			gu.captureupdateOTR(driver, document, "Prox Checkbox present");           
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			logger.info("Issue in finding Prox checkbox... "+e.getMessage());
		} 
	}

//	public void ClicksLowesBusinessChkbox() throws Exception{
//		try{
//			gu.WaitForElePresent(checkbox_brc, wait1);
//			if(!checkbox_brc.isSelected()){
//				gu.pageScrollDownWithEle(driver, checkbox_brc);                  
//				checkbox_brc.click();
//				System.out.println("Brc Checkbox checked");
//			}
//			//Thread.sleep(1000);
//			gu.captureupdateOTR(driver, document, "Brc Checkbox checked");           
//			//Thread.sleep(2000);
//		}
//		catch(Exception e)
//		{
//			logger.info("Issue in checking checkbox... "+e.getMessage());
//		} 
//	}
	
	public void ClicksLowesBusinessChkbox() throws Exception{
		  boolean status=false;	
			try {
					//gu.click(checkbox_prox);
					gu.clickByJs(driver, "chkboxbrc");
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					Thread.sleep(2000);
					logger.info("User clicks on prox  check box");
					status=true;
				Assert.assertTrue(status, "BRC CHECK BOX");
			} 
			catch (NoSuchElementException e1) 
			{
				e1.printStackTrace();
				status=false;
				logger.info("Issue in Clicking BRC checkbox"+e1.getMessage());
				//throw(e1);
			}
			catch (Exception e2) {
				e2.printStackTrace();
				status=false;
				logger.info("Issue in Clicking prox checkbox"+e2.getMessage());
				//throw(e2);
			}
			Assert.assertTrue(status, "BRC CHECK BOX");
	  }
	public void ClicksLowesReceivableChkbox() throws Exception{
		try{
			gu.WaitForElePresent(checkbox_prox, wait1);           
			if(!checkbox_prox.isSelected()){
				gu.pageScrollDownWithEle(driver, checkbox_prox);
				//checkbox_prox.click();
				gu.clickByJs(driver, "chkboxprox");
				System.out.println("Prox Checkbox checked");

			}
			//Thread.sleep(1000);
			gu.captureupdateOTR(driver, document, "Prox Checkbox checked");           
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			logger.info("Issue in checking checkbox... "+e.getMessage());
		} 
	}
	public void UncheckLowesBusinessChkbox() throws Exception{
		try{
			gu.fluientWaitforElementToVisible(driver, checkbox_brc);
			//Thread.sleep(2000);
			//if(!checkBox1.isSelected()){
			gu.pageScrollDownWithEle(driver, checkbox_brc);
			System.out.println("Brc Checkbox unchecked");
			//checkbox_brc.click();
			gu.clickByJs(driver, "chkboxprox");
			//}
			//Thread.sleep(1000);
			gu.captureupdateOTR(driver, document, "Brc Checkbox unchecked");           
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			logger.info("Issue in unchecking Brc checkbox... "+e.getMessage());
		} 
	}
	public void UncheckLowesReceivableChkbox() throws Exception{
		try{
			gu.fluientWaitforElementToVisible(driver, checkbox_prox);
			//Thread.sleep(2000);
			//if(!checkBox1.isSelected()){
			gu.pageScrollDownWithEle(driver, checkbox_prox);
			System.out.println("Checkbox unchecked");
			checkbox_prox.click();
			//gu.clickByJs(driver, "taxExempt");
			//}
			//Thread.sleep(1000);
			gu.captureupdateOTR(driver, document, " Checkbox unchecked");           
			//Thread.sleep(2000);
		}
		catch(Exception e)
		{
			logger.info("Issue in unchecking checkbox... "+e.getMessage());
		} 
	}
	public void verifyGetStarted_ButtonisEnabled() throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, button_getStarted);
			if(button_getStarted.isEnabled()){
				status=true;
				logger.info("get started Button enabled");

			}else{
				status=false;
				logger.info("get started Button disabled");

			}

		} catch(Exception e){

			e.printStackTrace();
			throw(e);
		}
		Assert.assertTrue(status, "get started Button disabled");
	}

	
	public void Click_verifycustomer() throws Exception{
		try{
			gu.click(CheckboxPrefill);
			gu.captureupdateOTR(driver, document, " Checkbox checked"); 
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		}
		catch(Exception e){
			
			logger.info("Issue in checking checkbox in landing page... "+e.getMessage());
		}
	}

		
}



