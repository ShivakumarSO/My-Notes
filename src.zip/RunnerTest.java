package com.cmlb2bapply.runner;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testobject.appium.junit.TestObjectAppiumSuiteWatcher;

import com.cmlb2bapply.step.Baseclass;
import com.cmlb2bapply.utility.ExcelUtility;
import com.cmlb2bapply.utility.HtmlReport;
import com.google.common.collect.ImmutableMap;
import com.relevantcodes.extentreports.ExtentReports;
import com.saucelabs.saucerest.SauceREST;
import com.vimalselvam.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.junit.Cucumber;
import gherkin.formatter.model.ScenarioOutline;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;


@RunWith(Cucumber.class)
	@CucumberOptions(features ="src//com//cmlb2bapply//featurefile",
	tags = {"@sanityTesting12345"},
	dryRun =false,
	glue= {"com/cmlb2bapply/step"},
	plugin = {"pretty", "html:target/destination12"},
	//plugin = {"html:target/site/cucumber-pretty","html:target/destination12"},
	monochrome = false)

public class RunnerTest  extends Baseclass {                                                                                                                                                                                        

	public static  String sessionId;

	@BeforeClass
	
	public static void setup() throws InvalidFormatException, IOException,Exception {

		
		try {
			Runtime.getRuntime().exec("Taskkill /IM chrome.exe /F");
		//Runtime.getRuntime().exec("Taskkill /IM iexplore.exe /F");
		Runtime.getRuntime().exec("Taskkill /IM firefox.exe /F");
			Runtime.getRuntime().exec("Taskkill /IM chromedriver.exe /F");
		} catch (IOException e) {
			System.out.println("Not able to kill the process");
			e.printStackTrace();
		}
		
		System.getProperties().put("https.proxyHost", "dalladcusrproxy.gdn.syfbank.com");
		System.getProperties().put("https.proxyPort", "8080");
		System.getProperties().put("https.proxyUser", "502484280");//user SSO id
		System.getProperties().put("https.proxyPassword","A@44@word");


		String workingpath=System.getProperty("user.dir");
		File srcexcelFile=new File(workingpath+"//Test-Output//ExcelOutput//Template//Detailed_Execution_status.xlsx");
		File oexeclFile= new File(workingpath+"//Test-Output//ExcelOutput//Detailed_Execution_status.xlsx");
		File srclogfile=new File(workingpath+"//Test-Output//Logs//logfile.log");
		ex=new ExcelUtility();


		try {
			FileUtils.copyFile(srcexcelFile, oexeclFile);           
			if(srclogfile.exists()){

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			DateFormat dateFormat = new SimpleDateFormat("MM_dd_yyyy HH_mm_ss");
			//get current date time with Date()
			Date date = new Date();
			// Now format the date
			String tDate= dateFormat.format(date);


			extent = new ExtentReports(System.getProperty("user.dir") +"/Test-Output/Reports/"+ "CML B2B Apply Automation_Execution_Summary_Report_"+tDate+".html", false);

			extent
			.addSystemInfo("Host Name", "BRC/PROX APPLY")
			.addSystemInfo("Environment", "BRC/PROX Web")
			.addSystemInfo("User Name", "Asha Rani AM");
			extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
			//loggerE = extent.startTest(TCNameNew);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}



	@AfterClass
	public static void teardown() {
		// bsLocal.stop();
		String workingpath=System.getProperty("user.dir");
		SimpleDateFormat df = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");              
		Date today;
		String reportDate;
		HtmlReport hr =new HtmlReport();
		String excelpath=workingpath+"//Test-Output//ExcelOutput//Detailed_Execution_status.xlsx";
		String sheetname="Detailed";
		hr.converttohtml (excelpath, sheetname);
		today = Calendar.getInstance().getTime();       
		reportDate = df.format(today);
		File dir =new File(workingpath+"//Test-Output//ExcelOutput//Detailed_Execution_"+reportDate+"//");
		dir.mkdir();
		dir =new File(workingpath+"//Test-Output//Logs//Logs_"+reportDate+"//");
		dir.mkdir();
		File oexeclFile= new File(workingpath+"//Test-Output//ExcelOutput//Detailed_Execution_"+reportDate+"//Detailed_Execution_status.xlsx");
		File srcexcelFile = new File(excelpath);
		File srchtmlfile=new File(workingpath+"//Test-Output//ExcelOutput//Detailed_Execution_status_Detailed.html");
		File ohtmlFile= new File(workingpath+"//Test-Output//ExcelOutput//Detailed_Execution_"+reportDate+"//Detailed_Execution_status_Detailed.html");
		File srclogfile=new File(workingpath+"//Test-Output//Logs//logfile.log");
		File ologFile= new File(workingpath+"//Test-Output//Logs//Logs_"+reportDate+"//logfile.log");



		try {
			FileUtils.copyFile(srcexcelFile,oexeclFile);
			FileUtils.copyFile(srchtmlfile,ohtmlFile);
			FileUtils.copyFile(srclogfile, ologFile);
		} catch (IOException e) {

			e.printStackTrace();
			System.out.println("File copy Output file not found");
		}

		System.out.println("extend report genrated");
		//extent.endTest(loggerE);
		extent.flush();
		extent.close();
	}




	@SuppressWarnings("deprecation")
	public static WebDriver launch_browser(String Cloud_Execution,String Platform,String Browser,String Browser_version) throws MalformedURLException{

		try {

			if (Cloud_Execution.equalsIgnoreCase("Yes"))
			{
				//****************Browser stack code ********************
				/*DesiredCapabilities caps = new DesiredCapabilities();
                                                caps.setCapability("browser", Browser);
                                    caps.setCapability("browser_version", Browser_version);
                                    caps.setCapability("os",OS);
                                    caps.setCapability("os_version",OS_version);
                                    caps.setCapability("browserstack.local", "true");
                                    caps.setCapability("browserstack.debug", "true");
                                    caps.setCapability("browserstack.networkLogs", "true");
                                    driver = new RemoteWebDriver(new URL(URL), caps);*/
				//*******************Sauce labs code *****************************     

				if (Browser.equalsIgnoreCase("Firefox")) {
					
					DesiredCapabilities caps = DesiredCapabilities.firefox();
					caps.setCapability("extendedDebugging",true);
					caps.setCapability("platform",Platform);                                                              
					caps.setCapability("version",Browser_version);
					driver=new RemoteWebDriver(new URL(URL), caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
				}else if(Browser.equalsIgnoreCase("Chrome")){
					
					DesiredCapabilities caps = DesiredCapabilities.chrome();
					caps.setCapability("extendedDebugging",true);
					caps.setCapability("platform",Platform);
					caps.setCapability("version",Browser_version);
					driver=new RemoteWebDriver(new URL(URL), caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
					System.out.println(sessionId);
				}else if (Browser.equalsIgnoreCase("Ie")) {
					DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
					caps.setCapability("extendedDebugging",true);
					caps.setCapability("platform",Platform);
					caps.setCapability("version",Browser_version);
					driver=new RemoteWebDriver(new URL(URL), caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
				}else if (Browser.equalsIgnoreCase("Edge")){
					DesiredCapabilities caps = DesiredCapabilities.edge();
					caps.setCapability("extendedDebugging",true);
					caps.setCapability("platform",Platform);
					caps.setCapability("version",Browser_version);
					driver=new RemoteWebDriver(new URL(URL), caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
				}else if (Browser.equalsIgnoreCase("Safari")){
					DesiredCapabilities caps = DesiredCapabilities.safari();
					caps.setCapability("extendedDebugging",true);
					caps.setCapability("platform",Platform);
					caps.setCapability("version",Browser_version);
					//driver=new RemoteWebDriver(new URL(URL), caps);
					//sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();

				}else if(Platform.equalsIgnoreCase("iOS_simulator")){

					// DesiredCapabilities caps = DesiredCapabilities.iphone();
					/*caps.setCapability("appiumVersion", "1.8.1");
                                           caps.setCapability("deviceName","iPhone X Simulator");
                                           caps.setCapability("deviceOrientation", "portrait");
                                           caps.setCapability("platformVersion","11.0");
                                           caps.setCapability("platformName", "iOS");
                                           caps.setCapability("browserName", "Safari");*/

					DesiredCapabilities caps = DesiredCapabilities.iphone();
					if (Browser.equalsIgnoreCase("iPhone 7 Plus")){


						caps.setCapability("appiumVersion", "1.9.1");
						caps.setCapability("deviceName","iPhone 7 Plus Simulator");
						caps.setCapability("deviceOrientation", "portrait");
						caps.setCapability("platformVersion","12.0");
						caps.setCapability("platformName", "iOS");
						caps.setCapability("browserName", "Safari");
					}
					else if (Browser.equalsIgnoreCase("iPad Pro")){
						caps.setCapability("appiumVersion", "1.7.1");
						caps.setCapability("deviceName","iPad Pro Simulator");
						caps.setCapability("deviceOrientation", "portrait");
						caps.setCapability("platformVersion","9.3");
						caps.setCapability("platformName", "iOS");
						caps.setCapability("browserName", "Safari");
					}

					driver=new RemoteWebDriver(new URL(URL), caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
				}else if(Platform.equalsIgnoreCase("Android_simulator")){


					DesiredCapabilities caps = DesiredCapabilities.android();
					if (Browser.equalsIgnoreCase("Samsung Galaxy S8")){
						caps.setCapability("appiumVersion", "1.9.1");
						caps.setCapability("deviceName","Samsung Galaxy S8 GoogleAPI Emulator");
						caps.setCapability("deviceOrientation", "landscape");
						caps.setCapability("browserName", "Chrome");
						caps.setCapability("platformVersion", "7.0");
						caps.setCapability("platformName","Android");
					}
					else if (Browser.equalsIgnoreCase("Samsung Galaxy Tab S2")){
						caps.setCapability("appiumVersion", "1.9.1");
						caps.setCapability("deviceName","Samsung Galaxy Tab S2 GoogleAPI Emulator");
						caps.setCapability("deviceOrientation", "portrait");
						caps.setCapability("browserName", "Chrome");
						caps.setCapability("platformVersion", "7.0");
						caps.setCapability("platformName","Android");
					}
					driver=new RemoteWebDriver(new URL(URL), caps);

					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();        

				}else if(Platform.equalsIgnoreCase("iOS")){

					DesiredCapabilities caps = new DesiredCapabilities(); 
					caps.setCapability("testobject_api_key","64C0A40A6CA94801947EDC6F5D3D18C7");
					// caps.setCapability("testobject_test_report_id", resultWatcher.getTestReportId());
					caps.setCapability("platformName", Platform);
					System.out.println(Platform.toString());
					caps.setCapability("platformVersion", Browser_version);
					System.out.println(Browser_version);
					caps.setCapability("deviceName", Browser.toString());
					System.out.println(Browser);
					caps.setCapability("deviceOrientation", "Portrait");
					//caps.setCapability("browserName", "Chrome");
					//caps.setCapability("phoneOnly",false);
					// caps.setCapability("tabletOnly",false);
					caps.setCapability("privateDevicesOnly",false);
					caps.setCapability("testobject_app_id", "1");
					caps.setCapability("testobject_suite_name","cmlb2b");

					caps.setCapability("testobject_test_name",RealDeviceScenarioName);
					//caps.setCapability("tunnelIdentifier", "cmlb2b");
					caps.setCapability("appiumVersion", "1.9.1");
					/*if (Browser.equalsIgnoreCase("iPhone 7 Plus")){
                                                                 driver = new RemoteWebDriver(new URL(RealDeviceEu_URL),caps);
                                                                 sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
                                                                 }
                                                                 else{
                                                                 driver = new RemoteWebDriver(new URL(RealDevice_URL),caps);
                                                                 sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
                                                                 }*/
					driver = new RemoteWebDriver(new URL(RealDevice_URL),caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
				}
				else if(Platform.equalsIgnoreCase("BS_iOS")){

					DesiredCapabilities caps = new DesiredCapabilities();
					caps.setCapability("os_version", "10.3");
					caps.setCapability("device", "iPhone 7 Plus");
					caps.setCapability("real_mobile", "true");
					caps.setCapability("browserstack.local", "false");
					caps.setCapability("browserstack.appium_version", "1.8.0");
					caps.setCapability("deviceOrientation", "landscape");

					driver = new RemoteWebDriver(new URL(BS_URL),caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();


				}else if(Platform.equalsIgnoreCase("iOS_EU")){

					DesiredCapabilities caps = new DesiredCapabilities(); 
					caps.setCapability("testobject_api_key","64C0A40A6CA94801947EDC6F5D3D18C7");
					caps.setCapability("platformName", "iOS");
					System.out.println(Platform.toString());
					caps.setCapability("platformVersion", Browser_version);
					System.out.println(Browser_version);
					caps.setCapability("deviceName", Browser.toString());
					System.out.println(Browser);
					caps.setCapability("deviceOrientation", "Portrait");
					//caps.setCapability("phoneOnly",false);
					// caps.setCapability("tabletOnly",false);
					caps.setCapability("privateDevicesOnly",false);
					caps.setCapability("testobject_app_id", "1");
					caps.setCapability("testobject_suite_name","cmlb2b");

					caps.setCapability("testobject_test_name",RealDeviceScenarioName);
					caps.setCapability("appiumVersion", "1.9.1");
					//caps.setCapability("tunnelIdentifier", "cmlb2b");
					// caps.setCapability("appiumVersion", "1.8.1");
					/*if (Browser.equalsIgnoreCase("iPhone 7 Plus")){
                                                                 driver = new RemoteWebDriver(new URL(RealDeviceEu_URL),caps);
                                                                 sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
                                                                 }
                                                                 else{
                                                                 driver = new RemoteWebDriver(new URL(RealDevice_URL),caps);
                                                                 sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
                                                                 }*/
					driver = new RemoteWebDriver(new URL(RealDeviceEu_URL),caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();



				}  else if(Platform.equalsIgnoreCase("Android")){
					DesiredCapabilities caps = new DesiredCapabilities();
					caps.setCapability("testobject_api_key","64C0A40A6CA94801947EDC6F5D3D18C7");

					caps.setCapability("platformName", Platform);
					System.out.println(Platform);
					caps.setCapability("platformVersion", Browser_version);
					System.out.println(Browser_version);
					caps.setCapability("deviceName", Browser);
					System.out.println(Browser);
					// caps.setCapability("deviceOrientation", "landscape");
					//caps.setCapability("phoneOnly",false);
					// caps.setCapability("tabletOnly",false);
					caps.setCapability("privateDevicesOnly",false);
					caps.setCapability("testobject_app_id", "1");
					caps.setCapability("testobject_suite_name","cmlb2b");

					caps.setCapability("testobject_test_name",RealDeviceScenarioName);
					caps.setCapability("appiumVersion", "1.8.1");
					//caps.setCapability("name", "cmlb2b");
					//caps.setCapability("tunnelIdentifier", "cmlb2b");
					//caps.setCapability("appiumVersion", "1.8.1");
					if (Browser.equalsIgnoreCase("Samsung Galaxy Tab S2")){
						driver = new RemoteWebDriver(new URL(RealDeviceEu_URL),caps);
						sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
					}
					else{
						driver = new RemoteWebDriver(new URL(RealDevice_URL),caps);
						sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
					}
				} else if(Platform.equalsIgnoreCase("iOSL")){

					DesiredCapabilities caps = new DesiredCapabilities(); 
					caps.setCapability("testobject_api_key","64C0A40A6CA94801947EDC6F5D3D18C7");
					caps.setCapability("platformName", "iOS");
					System.out.println(Platform.toString());
					caps.setCapability("platformVersion", Browser_version);
					System.out.println(Browser_version);
					caps.setCapability("deviceName", Browser.toString());
					System.out.println(Browser);
					//caps.setCapability("deviceOrientation", "landscape");
					//caps.setCapability("phoneOnly",false);
					// caps.setCapability("tabletOnly",false);
					caps.setCapability("privateDevicesOnly",false);
					caps.setCapability("testobject_app_id", "2");
					caps.setCapability("testobject_suite_name","cmlb2b");

					caps.setCapability("testobject_test_name",RealDeviceScenarioName);
					//caps.setCapability("tunnelIdentifier", "cmlb2b");
					// caps.setCapability("appiumVersion", "1.8.1");

					driver = new RemoteWebDriver(new URL(RealDevice_URL),caps);
					sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();

				}else if(Platform.equalsIgnoreCase("AndroidL")){
					DesiredCapabilities caps = new DesiredCapabilities();
					caps.setCapability("testobject_api_key","64C0A40A6CA94801947EDC6F5D3D18C7");

					caps.setCapability("platformName", "Android");
					System.out.println(Platform);
					caps.setCapability("platformVersion", Browser_version);
					System.out.println(Browser_version);
					caps.setCapability("deviceName", Browser);
					System.out.println(Browser);
					//caps.setCapability("deviceOrientation", "Landscape");
					//caps.setCapability("phoneOnly",false);
					// caps.setCapability("tabletOnly",false);
					caps.setCapability("privateDevicesOnly",false);
					caps.setCapability("testobject_app_id", "2");
					caps.setCapability("testobject_suite_name","cmlb2b regression1.2");

					caps.setCapability("testobject_test_name",RealDeviceScenarioName);
					//caps.setCapability("name", "cmlb2b");
					//caps.setCapability("tunnelIdentifier", "cmlb2b");
					//caps.setCapability("appiumVersion", "1.8.1");
					if (Browser.equalsIgnoreCase("Samsung Galaxy Tab S2")){
						driver = new RemoteWebDriver(new URL(RealDeviceEu_URL),caps);
						sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
					}
					else{
						driver = new RemoteWebDriver(new URL(RealDevice_URL),caps);
						sessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
					}



				}                                   
				else{
					System.out.println("Invalid Browser Selection");
				}      
			}
			else if (Cloud_Execution.equalsIgnoreCase("No")){
				if(Browser.equalsIgnoreCase("Firefox")) {
					System.setProperty("webdriver.gecko.driver",FirefoxDriverPath);
					driver = new FirefoxDriver();
				}             
				else if(Browser.equalsIgnoreCase("Chrome")){
					ChromeOptions options = new ChromeOptions();
					options.setExperimentalOption("useAutomationExtension", false);      
					options.addArguments("disable-infobars");
					options.addArguments("--start-maximized");
					options.addArguments(
							"--enable-automation",
							"--password-store=basic",
							"--use-mock-keychain",
							"--disable-background-networking",
							"--disable-background-timer-throttling",
							"--disable-client-side-phishing-detection",
							"--disable-default-apps",
							"--disable-extensions",
							"--disable-hang-monitor",
							"--disable-popup-blocking",
							"--disable-prompt-on-repost",
							"--disable-sync",
							"--disable-translate",
							"--metrics-recording-only",
							"--no-first-run",
							"--safebrowsing-disable-auto-update",
							//  "--headless",
							"--mute-audio",
							"--disable-gpu",
							"--hide-scrollbars",
							"--false-useAutomationExtension");
					System.setProperty("webdriver.chrome.driver",ChromeDriverPath);
					driver=new ChromeDriver(options);
				}
				else if (Browser.equalsIgnoreCase("Ie")){
					DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
					capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
					capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
					System.setProperty("webdriver.ie.driver", IEDriverPath);
					driver=new InternetExplorerDriver(capabilities);//IEBrowserDriverObject.driver;
				}
				else if(Browser.equalsIgnoreCase("CE")){
					System.setProperty("webdriver.chrome.driver",ChromeDriverPath);
					if (Browser_version.equalsIgnoreCase("Samsung Galaxy S8")) {
						Map<String, Object> deviceMetrics = new HashMap<>();
						deviceMetrics.put("width", 360);
						deviceMetrics.put("height", 740);
						deviceMetrics.put("pixelRatio", 3.0);
						Map<String, Object> mobileEmulation = new HashMap<>();
						mobileEmulation.put("deviceMetrics", deviceMetrics);
						mobileEmulation.put("userAgent", "Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G950F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/5.2 Chrome/66.0.3359.139 Mobile Safari/537.36");
						ChromeOptions chromeOptions = new ChromeOptions();
						chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
						chromeOptions.setExperimentalOption("useAutomationExtension", false);
						driver = new ChromeDriver(chromeOptions);


					}
					if (Browser_version.equalsIgnoreCase("Samsung Galaxy S8 Landscape")) {
						Map<String, Object> deviceMetrics = new HashMap<>();
						deviceMetrics.put("width", 740);
						deviceMetrics.put("height", 360);
						deviceMetrics.put("pixelRatio", 3.0);
						Map<String, Object> mobileEmulation = new HashMap<>();
						mobileEmulation.put("deviceMetrics", deviceMetrics);
						mobileEmulation.put("userAgent", "Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G950F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/5.2 Chrome/66.0.3359.139 Mobile Safari/537.36");
						ChromeOptions chromeOptions = new ChromeOptions();
						chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
						chromeOptions.setExperimentalOption("useAutomationExtension", false);
						driver = new ChromeDriver(chromeOptions);


					}
					if (Browser_version.equalsIgnoreCase("Samsung Galaxy Tab S2")) {
						Map<String, Object> deviceMetrics = new HashMap<>();
						deviceMetrics.put("width", 1536);
						deviceMetrics.put("height", 2048);
						deviceMetrics.put("pixelRatio", 2.0);
						Map<String, Object> mobileEmulation = new HashMap<>();
						mobileEmulation.put("deviceMetrics", deviceMetrics);
						mobileEmulation.put("userAgent", "Mozilla/5.0 (Linux; Android 4.2.2; GT-P5110 Build/JDQ39) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36");
						ChromeOptions chromeOptions = new ChromeOptions();
						chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
						chromeOptions.setExperimentalOption("useAutomationExtension", false);
						driver = new ChromeDriver(chromeOptions);


					} else {
						Map<String, String> mobileEmulation = new HashMap<String, String>();
						mobileEmulation.put("deviceName",Browser_version); 
						ChromeOptions chromeOptions = new ChromeOptions();
						chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
						chromeOptions.setExperimentalOption("useAutomationExtension", false);
						driver =new ChromeDriver(chromeOptions);
					}



					//driver.orientation = "LANDSCAPE";

				}
				else{
					System.out.println("Invalid Browser Selection");
				} 
			}
			else{
				System.out.println("Please select the yes or no for cloud execution");
			}
		}catch (WebDriverException e) {
			System.out.println(e.getMessage());
		}
		try {
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver;
	}

	public void Navigateto(String URL) throws InterruptedException{

		driver.get(URL);
		Thread.sleep(3000);
	}

	public void clickOnElementWithCssSelector(String cssSelector){
		js.executeScript("$(" + cssSelector + ").click();");
	}

	//*********SauceLab Code to produce customized Sauce Lab Results*********
	//********Author:Arun T S********
	//********Please do inform before making any Changes*********

	private static SauceREST sauceRESTClient;

	private static SauceREST getSauceRestClient(String username, String accessKey){
		if (sauceRESTClient == null) {
			sauceRESTClient = new SauceREST(username, accessKey);
		}
		return sauceRESTClient;
	}

	public static void UpdateResults(String username, String accessKey, boolean testResults, String sessionId, String jobName)
			throws JSONException, IOException {
		SauceREST client = getSauceRestClient(username, accessKey);
		Map<String, Object> updates = new HashMap<String, Object>();
		if(testResults)
		{
			updates.put("name", jobName);
			updates.put("passed", testResults);
		}
		else
		{
			updates.put("name", jobName);
			updates.put("passed", testResults);
		}
		client.updateJobInfo(sessionId, updates);
	}

}
