package com.cmlb2bapply.pageobject;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;
import com.relevantcodes.extentreports.LogStatus;

public class PG_Page extends RunnerTest  {

	//Utilities-Object Creation
	GenericUtilities gu=new GenericUtilities();

	public PG_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}

	@FindBy(name="willIncludePG")
	private WebElement checkbox_willIncludePG;

	@FindBy(id="address1")
	private WebElement input_homeAddress;

	@FindBy(name="zipCode")
	private WebElement input_pgZipCode;
	
	@FindBy(name ="zipCodeCityStates")
	private WebElement select_zipCodeCityStates;

	@FindBy(name="homePhone")
	public WebElement input_pgHomePhone;

	@FindBy(name="applicantEmailAddress")
	private WebElement input_pgEmailAddress;

	@FindBy(name="socialSecurityNumber")
	private WebElement input_pgSSN;

	@FindBy(name="dateOfBirth")
	private WebElement input_pgDOB;

	@FindBy(name="applicantIncome")
	private WebElement input_pgAnnualIncome;

	@FindBy(xpath="//Input[@name='privateGuarantorFlag']")
	private WebElement checkbox_pgCheckBox;

	@FindBy(xpath="//button[contains(text(),'Continue')]")
	private WebElement click_continueButton;
	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;


	@FindBy(xpath="//*[@id='address1'and contains(text(),'Do not use a P.O. Box. Instead, use your physical address.')]")
	//@FindBy(xpath="//p[text()='Do not use a P.O. Box. Instead, use your physical address.')]")
	//@FindBy(className  = "sc-frDJqD jklxiK")
	//	@FindBy(id="address1") 
	private WebElement PgHomeaddressVerbiage;		

	public void Click_ContinueButton() throws Exception{
		try {
			gu.click(click_continueButton);

			logger.info("User clicks on Continue Button");
		} 
		catch (NoSuchElementException e1) 
		{
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+ e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			e2.printStackTrace();
			throw(e2);
		}
	}
	public void EnterfewvaluesInPGField(String PgHomeAddress,String PgZipCode,String PgEmailAddress,String PgPersonalPhone) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_homeAddress);
			status=gu.WaitForElePresent(input_homeAddress, wait1);
			if(status==true){

				gu.entertext(input_homeAddress, PgHomeAddress);
				//logger.info(" PgHomeAddress value entered :"+PgHomeAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgHomeAddress value entered: "+PgHomeAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgZipCode, PgZipCode);
				//logger.info("  PgZipCode value entered :"+PgZipCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgZipCode value entered: "+PgZipCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgEmailAddress, PgEmailAddress);
			
				//logger.info(" PgEmailAddress value entered :"+PgEmailAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgEmailAddress value entered: "+PgEmailAddress + loggerE.addScreenCapture(screenshotPath));
				//Thread.sleep(50000);
				gu.entertext(input_pgHomePhone, PgPersonalPhone);
				//logger.info(" PgPersonalPhone value entered :"+PgPersonalPhone);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgPersonalPhone value entered: "+PgPersonalPhone + loggerE.addScreenCapture(screenshotPath));

			}
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e1.getMessage());
			System.out.println("Issue with entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "PG PAGE");
	}



	public void verifyverbiageinpgpage(String PGHomeaddressVerbiage) throws Exception{

		boolean status=false;
		try{
			gu.clickByJs(driver, "willIncludePG");
			gu.click(input_homeAddress);

			/*String S1=PgHomeaddressVerbiage.getText();
				System.out.println(S1);*/

			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{

				S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(PGHomeaddressVerbiage))
				{
					status =true;
					logger.info("PG homeaddress verbiage verified successfully");
					break;
				}

			}




			/*String text=driver.findElement(By.xpath("//p[@id='address1']/following::p")).getText();
				System.out.println(text);*/


			//Assert.assertEquals(S, PGHomeaddVerbiage);
			System.out.println("PG homeaddress verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with PG homeaddress verbiage");
			logger.info(e.getMessage());
		}



		// gu.isTextpresentpsource(driver,"Do not use a P.O. Box. Instead, use your physical address.");
		//gu.pageScrollDownWithEle(driver, input_homeAddress);
		//	screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		//	gu.captureupdateOTR(driver, document, " PGHomeAddressVerbiage is present");
		//boolean actVal =gu.isDisplayed(PgHomeaddressVerbiage);
		//String Pghomeaddressverbiage1= PgHomeaddressVerbiage.getText();
		//System.out.println(Pghomeaddressverbiage1);
		//String ExpextedPgHomeaddressVerbiage=""
		//boolean actVal =gu.isDisplayed(PgHomeaddressVerbiage);
		//boolean actval1 = gu.isTextpresent(PgHomeaddressVerbiage," Do not use a P.O. Box. Instead, use your physical address");
		//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);

		// gu.clickByJs(driver, "willIncludePG");





		//Assert.assertEquals(PgHomeaddressVerbiage, Pghomeaddressverbiage1);


		//			(PgHomeaddressVerbiage);
		//			if(arg2.isEmpty()){		
		//			//if(checkBox1.isSelected()){
		//			
		//			System.out.println("PgHomeaddressVerbiage is"+Pghomeaddressverbiage);
		//			 if(Pghomeaddressverbiage.contains("Do not use a P.O. Box. Instead, use your physical address.")){
		//				gu.pageScrollDownWithEle(driver, PgHomeaddressVerbiage);
		//				System.out.println("PgHomeaddressVerbiage Present");
		//			    //checkBox1.click();
		//				status=true;
		//			}
		//			
		//			}
		//Thread.sleep(2000);
	}



	public void CTHomeaddressvalidate(String CTHomeaddressVerbiage) throws Exception{

		boolean status=false;
		try{
			gu.clickByJs(driver, "willIncludePG");
			gu.click(input_homeAddress);

			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{

				S=i.getText();

				System.out.println(S);
				if(S.equalsIgnoreCase(CTHomeaddressVerbiage))
				{
					status =true;
					logger.info("PG homeaddress verbiage verified successfully");
					break;
				}

			}


			//Assert.assertEquals(S, PGHomeaddVerbiage);
			System.out.println("PG homeaddress verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with PG homeaddress verbiage");
			logger.info(e.getMessage());
		}









	}



	public void EnterremainingvaluesInPGField(String PgPersonalPhone,String PgSsn,String PgDob,String PgAnuualNetIncome) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_pgHomePhone);
			status=gu.WaitForElePresent(input_pgHomePhone, wait1);
			if(status==true){


				gu.entertext(input_pgHomePhone, PgPersonalPhone);
				//logger.info(" PgPersonalPhone value entered :"+PgPersonalPhone);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgPersonalPhone value entered: "+PgPersonalPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgSSN, PgSsn);
				//logger.info(" PgSsn value entered :"+PgSsn);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgSsn value entered: "+PgSsn + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgDOB, PgDob);
				//logger.info("  PgDob value entered :"+PgDob);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgDob value entered: "+PgDob + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgAnnualIncome, PgAnuualNetIncome);
				//logger.info("PgAnuualNetIncome  value entered :"+ PgAnuualNetIncome);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgAnuualNetIncome value entered: "+PgAnuualNetIncome + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkbox_pgCheckBox);
				gu.clickByJs(driver, "privateGuarantorFlag");

				logger.info("I agree to personally guarantee the performance of all obligations of this Account.check box checked");
				status=true;
			}else{
				logger.info(" Issue in PG Page");
				status=false;
			}
			Assert.assertTrue(status, "PG PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e1.getMessage());
			System.out.println("Issue with entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "PG PAGE");
	}

	public void EntervalueInPGFields(String PgHomeAddress,String PgZipCode,String PgSsn,String PgDob,String PgAnuualNetIncome) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_homeAddress);
			status=gu.WaitForElePresent(input_homeAddress, wait1);
			if(status==true){

				gu.entertext(input_homeAddress, PgHomeAddress);
				//logger.info(" PgHomeAddress value entered :"+PgHomeAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgHomeAddress value entered: "+PgHomeAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgZipCode, PgZipCode);
				//logger.info("  PgZipCode value entered :"+PgZipCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgZipCode value entered: "+PgZipCode + loggerE.addScreenCapture(screenshotPath));

//				gu.entertext(input_pgEmailAddress, PgEmailAddress);
//				//logger.info(" PgEmailAddress value entered :"+PgEmailAddress);
//				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
//				loggerE.log(LogStatus.PASS ,"PgEmailAddress value entered: "+PgEmailAddress + loggerE.addScreenCapture(screenshotPath));
//
//				gu.entertext(input_pgHomePhone, PgPersonalPhone);
//				//logger.info(" PgPersonalPhone value entered :"+PgPersonalPhone);
//				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
//				loggerE.log(LogStatus.PASS ,"PgPersonalPhone value entered: "+PgPersonalPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgSSN, PgSsn);
				//logger.info(" PgSsn value entered :"+PgSsn);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgSsn value entered: "+PgSsn + loggerE.addScreenCapture(screenshotPath));
				gu.pageScrollDownByPixel(driver);
				
				
				gu.entertext(input_pgDOB, PgDob);
				//logger.info("  PgDob value entered :"+PgDob);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgDob value entered: "+PgDob + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgAnnualIncome, PgAnuualNetIncome);
				//logger.info("PgAnuualNetIncome  value entered :"+ PgAnuualNetIncome);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgAnuualNetIncome value entered: "+PgAnuualNetIncome + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkbox_pgCheckBox);
				gu.clickByJs(driver, "privateGuarantorFlag");

				logger.info("I agree to personally guarantee the performance of all obligations of this Account.check box checked");
				status=true;
			}else{
				logger.info(" Issue in PG Page");
				status=false;
			}
			Assert.assertTrue(status, "PG PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e1.getMessage());
			System.out.println("Issue with entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "PG PAGE");
	}
	
	public void EntervaluesInPGFields(String PgHomeAddress,String PgZipCode,String PgCityandState,String PgEmailAddress,String PgPersonalPhone,String PgSsn,String PgDob,String PgAnuualNetIncome) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_homeAddress);
			status=gu.WaitForElePresent(input_homeAddress, wait1);
			if(status==true){
				
				
				gu.entertext(input_homeAddress, PgHomeAddress);  //zipCodeCityStates
				
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				//logger.info(" PgHomeAddress value entered :"+PgHomeAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgHomeAddress value entered: "+PgHomeAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgZipCode, PgZipCode);
				//logger.info("  PgZipCode value entered :"+PgZipCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgZipCode value entered: "+PgZipCode + loggerE.addScreenCapture(screenshotPath));
				
				
				Thread.sleep(3000);
//				Select sel=new Select(select_zipCodeCityStates);
//				System.out.println(sel.getOptions().get(1));
				gu.selectdropdown(select_zipCodeCityStates, "value",PgCityandState );
				//logger.info(" TypeOfBusiness value selected : "+TypeOfBusiness);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CityandState value was selected: "+PgCityandState + loggerE.addScreenCapture(screenshotPath));

				
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				gu.entertext(input_pgEmailAddress, PgEmailAddress);
				//logger.info(" PgEmailAddress value entered :"+PgEmailAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgEmailAddress value entered: "+PgEmailAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgHomePhone, PgPersonalPhone);
				//logger.info(" PgPersonalPhone value entered :"+PgPersonalPhone);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgPersonalPhone value entered: "+PgPersonalPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgSSN, PgSsn);
				//logger.info(" PgSsn value entered :"+PgSsn);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgSsn value entered: "+PgSsn + loggerE.addScreenCapture(screenshotPath));
				
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				
				
				gu.entertext(input_pgDOB, PgDob);
				//logger.info("  PgDob value entered :"+PgDob);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgDob value entered: "+PgDob + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgAnnualIncome, PgAnuualNetIncome);
				//logger.info("PgAnuualNetIncome  value entered :"+ PgAnuualNetIncome);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgAnuualNetIncome value entered: "+PgAnuualNetIncome + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkbox_pgCheckBox);
				gu.clickByJs(driver, "privateGuarantorFlag");

				logger.info("I agree to personally guarantee the performance of all obligations of this Account.check box checked");
				status=true;
			}else{
				logger.info(" Issue in PG Page");
				status=false;
			}
			Assert.assertTrue(status, "PG PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e1.getMessage());
			System.out.println("Issue with entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "PG PAGE");
	}

	public void EnterfewvalueInPGFields(String PgHomeAddress,String PgZipCode,String PgEmailAddress) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_homeAddress);
			status=gu.WaitForElePresent(input_homeAddress, wait1);
			if(status==true){

				gu.entertext(input_homeAddress, PgHomeAddress);
				//logger.info(" PgHomeAddress value entered :"+PgHomeAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgHomeAddress value entered: "+PgHomeAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgZipCode, PgZipCode);
				//logger.info("  PgZipCode value entered :"+PgZipCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgZipCode value entered: "+PgZipCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgEmailAddress, PgEmailAddress);
				//logger.info(" PgEmailAddress value entered :"+PgEmailAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgEmailAddress value entered: "+PgEmailAddress + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}else{
				logger.info(" Issue in PG Page");
				status=false;
			}
			Assert.assertTrue(status, "PG PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress"+e1.getMessage());
			System.out.println("Issue with entering  PgHomeAddress, PgZipCode, PgEmailAddress");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "PG PAGE");
	}

	public void EnterfewmorevalueInPGFields(String PgPersonalPhone,String PgSsn) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_homeAddress);
			status=gu.WaitForElePresent(input_homeAddress, wait1);
			if(status==true){
				gu.entertext(input_pgHomePhone, PgPersonalPhone);
				//logger.info(" PgPersonalPhone value entered :"+PgPersonalPhone);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgPersonalPhone value entered: "+PgPersonalPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgSSN, PgSsn);
				//logger.info(" PgSsn value entered :"+PgSsn);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgSsn value entered: "+PgSsn + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}else{
				logger.info(" Issue in PG Page");
				status=false;
			}
			Assert.assertTrue(status, "PG PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  PgPersonalPhone, PgSsn"+e1.getMessage());
			System.out.println("Issue with entering PgPersonalPhone, PgSsn");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering   PgPersonalPhone, PgSsn"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "PG PAGE");
	}


	public void PGPage_Elementvalidation(WebDriver driver) throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, input_homeAddress, wait1)){
				status=true;
			}else{
				status=false;
			}
		}catch(Exception e){

			e.printStackTrace();
			throw(e);
		}
		Assert.assertTrue(status, "PG Page Filed Validation failed");
	}

	public void navigatedTo_PgPage(WebDriver driver) throws Exception{
		//gu.fluientWaitforElementToVisible( driver, input_homeAddress );
		boolean status = false;
		String urlNew = driver.getCurrentUrl();
		try{
			if (urlNew.contains("applicant-pg")){
				logger.info("Navigated to PG page");
				status =true;
			}			
		}catch(Exception e){
			e.printStackTrace();
			logger.info("Not Navigated to PG page" +e.getMessage());
			throw(e);
		}
		Assert.assertTrue(status, "PG PAGE.........");
		logger.info("-------PG PAGE-------"+status);
	}
	public void EntervalueInPGPageAndCheckIAgreeCheckbox(String PgHomeAddress,String PgZipCode,String PgEmailAddress,String PgPersonalPhone,String PgSsn,String PgDob,String PgAnuualNetIncome) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToclick(driver, checkbox_willIncludePG);
			gu.clickByJs(driver, "willIncludePG");
			logger.info("I Will Include PG Check box checked");
			Thread.sleep(1000);
			status=gu.WaitForElePresent(input_homeAddress, wait1);
			if(status==true){

				gu.entertext(input_homeAddress, PgHomeAddress);
				//logger.info(" PgHomeAddress value entered :"+PgHomeAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgHomeAddress value entered: "+PgHomeAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgZipCode, PgZipCode);
				//logger.info("  PgZipCode value entered :"+PgZipCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgZipCode value entered: "+PgZipCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgEmailAddress, PgEmailAddress);
				//logger.info(" PgEmailAddress value entered :"+PgEmailAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgEmailAddress value entered: "+PgEmailAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgHomePhone, PgPersonalPhone);
				//logger.info(" PgPersonalPhone value entered :"+PgPersonalPhone);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgPersonalPhone value entered: "+PgPersonalPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgSSN, PgSsn);
				//logger.info(" PgSsn value entered :"+PgSsn);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgSsn value entered: "+PgSsn + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgDOB, PgDob);
				//logger.info("  PgDob value entered :"+PgDob);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgDob value entered: "+PgDob + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_pgAnnualIncome, PgAnuualNetIncome);
				//logger.info("PgAnuualNetIncome  value entered :"+ PgAnuualNetIncome);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PgAnuualNetIncome value entered: "+PgAnuualNetIncome + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkbox_pgCheckBox);

				gu.clickByJs(driver, "privateGuarantorFlag");
				logger.info("I agree to personally guarantee the performance of all obligations of this Account.check box checked");

				status=true;
			}else{
				logger.info(" Issue in PG Page");
				status=false;
			}

			Assert.assertTrue(status, "PG PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e1.getMessage());
			System.out.println("Issue with entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome");

			logger.info(e1.getMessage());
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome"+e2.getMessage());
			logger.info(e2.getMessage());
		}
		Assert.assertTrue(status, "PG PAGE");
	}

	public void iwillincludepg_checkbox(){
		boolean status = false;
		try {
			gu.fluientWaitforElementToclick(driver, checkbox_willIncludePG);
			//gu.click(checkbox_willIncludePG);
			gu.clickByJs(driver, "willIncludePG");

			logger.info("I Will Include PG Check box checked");
			status =true;
		} catch (Exception e) {
			// TODO: handle exception
			status =false;
			e.getStackTrace();
			logger.info("I Will Include PG Check box not checked"+e.getMessage());
		}
		Assert.assertTrue(status, "I Will Include PG");
	}

	public void validateText(String EnteredText)  throws Exception{
		try {
			String actVal =gu.getEnteredText(input_pgEmailAddress);
			if(actVal.equals(EnteredText)){
				//Assert.assertEquals(actVal, EnteredText);
				logger.info(" actual = "+EnteredText);
				gu.captureupdateOTR(driver, document, " Previously entered data is retained, user can continue filling the page further ");
				System.out.println("Previously entered data is retained, user can continue filling the page further");
			}
			else
			{
				System.out.println("Previously entered value is erased, user should start filling the page again");
				gu.captureupdateOTR(driver, document, " Previously entered value is erased, user should start filling the page again ");
			}
		} catch (Exception e) {
			logger.info(e.getMessage());

		}
	}
	
	public void verifyPgPhonenumberRemoved() throws Exception{
		//boolean status=false;
		try {
			//gu.fluientWaitforElementToVisible(driver, input_homeAddress);
			WebElement HomephoneelePresent = input_pgHomePhone;
			//status=gu.WaitForElePresent(input_pgHomePhone, wait1);
			//if(status==true||input_pgHomePhone.isDisplayed()){
			if (!HomephoneelePresent.isDisplayed()){

				logger.info("PgPhoneNumber has removed from the PG page");
				
				
			}
		}
		catch (NoSuchElementException e1) 
		{
			//status=false;
			e1.printStackTrace();
			
			//System.out.println("Issue with entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome");
			loggerE.log(LogStatus.PASS ,"PgPersonalPhone value entered: " + loggerE.addScreenCapture(screenshotPath));

			logger.info(e1.getMessage());
		}
		
		//Assert.assertTrue(status, "PG PAGE");
	}
	
	public void verifyEmailaddressRemoved( ) throws Exception{
		//boolean status=false;
		try {

					
			//gu.fluientWaitforElementToVisible(driver, input_homeAddress);
			//status=gu.WaitForElePresent(input_pgEmailAddress, wait1);
			WebElement emailaddresselePresent = input_pgEmailAddress;
			if(!emailaddresselePresent.isDisplayed()){
				
				logger.info("PgEmailAddress has removed from the PG page");
				
				
			}
		}
		catch (NoSuchElementException e1) 
		{
			//status=true;
			e1.printStackTrace();
			
			//System.out.println("Issue with entering  PgHomeAddress, PgZipCode, PgEmailAddress, PgPersonalPhone, PgSsn, PgDob, PgAnuualNetIncome");
			loggerE.log(LogStatus.PASS ,"PgEmailAddress value entered: " + loggerE.addScreenCapture(screenshotPath));
			logger.info("Element is Present");
			logger.info(e1.getMessage());
		}
		
		//Assert.assertTrue(status, "PG PAGE");
	}
}