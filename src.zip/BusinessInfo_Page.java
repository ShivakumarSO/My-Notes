package com.cmlb2bapply.pageobject;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.cmlb2bapply.runner.RunnerTest;
import com.cmlb2bapply.utility.GenericUtilities;

import com.cmlb2bapply.step.Hooks.*;

import com.google.common.primitives.Ints;
import com.relevantcodes.extentreports.LogStatus;
import com.vimalselvam.cucumber.listener.Reporter;

public class BusinessInfo_Page extends RunnerTest{
	//Utilities-Object Creation
	GenericUtilities gu=new GenericUtilities();
	public WebElement textfield ;
	public BusinessInfo_Page(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	boolean status =false;
	@FindBy(id="companyzipCodeCityStates")
	private WebElement select_zipcodename;

	@FindBy(id="baZipCodeCityStates")
	private WebElement select_bazipcodename;

	@FindBy(id="companyName")
	private WebElement input_companyName;

	@FindBy(id="doingBusinessAs")
	private WebElement input_doingBusinessAs;
	@FindBy(name="taxExempt")
	private WebElement checkBox1;

	@FindBy(id="businessType")
	private WebElement dropdown_businessType;

	@FindBy(id="promoCode")
	private WebElement input_promcode;

	@FindBy(id="companyAddress1")
	private WebElement input_businessaddress;

	@FindBy(id="businessSuiteEx")
	private WebElement input_businessSuiteEx;
	
	@FindBy(name="companyzipCode")
	private WebElement input_zipcode;

	@FindBy(name= "companyzipCodeCityStates")
	public WebElement select_companyzipCodeCityStates;

	//@FindBy(id="billAddSame")
	@FindBy(xpath="//input[@name='billAddSame']")
	private WebElement checkbox_mybillingaddress;

	@FindBy(id="baBillingAddress")
	private WebElement input_baBillingAddress;

	@FindBy(id="baBuilding")
	private WebElement input_babillingsuite;

	@FindBy(name="baZipCode")
	private WebElement input_baZipCode;

	@FindBy(name="[name='baZipCodeCityStates']")
	private WebElement input_bacityandstate;

	@FindBy(id="companyPhNo")
	private WebElement input_businessPhone;

	@FindBy(id="businessPhoneEx")
	private WebElement input_businessExt;

	@FindBy(id="emailAddress")
	public WebElement input_emailAddress;

	@FindBy(id="taxNumber")
	private WebElement input_taxPayerID;

	@FindBy (xpath = "//*[@id='dunAndBstreetNumber']")
	private WebElement input_dunAndBstreetNumber;

	@FindBy(id="numberOfEmployees")
	private WebElement input_noOfEmployees;

	@FindBy(id="inBusinessSince")
	private WebElement input_yearEstablished;

	@FindBy(id="annualRevenue")
	private WebElement input_annualRevenue;

	@FindBy(id="creditLineRequested")
	private WebElement input_requestedCreditLine;

	@FindBy(xpath="//button[contains(text(),'Continue')]")
	//@FindBy(xpath="//button[@type='submit']")
	private WebElement click_continueButton;

	@FindBy(xpath="//button[@type='submit'])")
	private WebElement click_submitButton;

	//Field validation errors objects

	@FindBy(xpath="//select[@name='companyzipCodeCityStates']")
	private WebElement input_ctPassportNumber;

	@FindBy(xpath="//input[@name='busOwns[0].boCheckUSCitizen']")
	private WebElement input_boCheckUSCitizen0;

	@FindBy(id="apFirstName")
	private WebElement input_apFirstName;

	@FindBy(id="apMiddleName")
	private WebElement input_apMiddleName;

	@FindBy(id="apLastName")
	private WebElement input_apLastName;

	@FindBy(xpath="//select[@name='busOwns[0].boType']")
	private WebElement select_boType0;

	@FindBy(xpath="//input[@name='busOwns[0].boFirstname']")
	private WebElement input_boFirstname0;

	@FindBy(xpath="//input[@name='busOwns[0].boMiddleName']")
	private WebElement input_boMiddleName0;

	@FindBy(xpath="//input[@name='busOwns[0].boLastname']")
	private WebElement input_boLastname0;

	@FindBy(xpath="//input[@name='busOwns[0].boHomeaddress']")
	private WebElement input_boHomeaddress0;

	@FindBy(xpath="//input[@name='busOwns[0].boZipcode']")
	private WebElement input_boZipcode0;

	@FindBy(xpath="//input[@name='busOwns[0].boCitystate']")
	private WebElement input_boCitystate0;

	@FindBy(xpath="//input[@name='busOwns[0].boSocialnumber']")
	private WebElement input_boSocialnumber0;

	@FindBy(xpath="//input[@name='busOwns[0].boDateOfBirth']")
	private WebElement input_boDateOfBirth0;

	@FindBy(xpath="//input[@name='busOwns[0].boPassportnumber']")
	private WebElement input_boPassportnumber0;

	@FindBy(xpath="//input[@name='busOwns[0].boPassportnumber']")
	private WebElement input_boidentificationDocNo0;

	@FindBy(xpath="//select[@name='busOwns[0].boCountryList']")
	private WebElement select_boCountryList0;

	@FindBy(xpath="//select[@name='busOwns[0].boDescriptiondocument']")
	private WebElement select_boDescriptiondocument0;

	@FindBy(xpath="//input[@name='busOwns[0].boDocumentIssueDate']")
	private WebElement input_boDocumentIssueDate0;

	@FindBy(xpath="//input[@name='busOwns[0].boDocumentExpirationDate']")
	private WebElement input_boDocumentExpirationDate0;

	@FindBy(id="address1")
	private WebElement input_homeAddress;

	@FindBy(name="zipCode")
	private WebElement input_pgZipCode;

	@FindBy(id="businessTitle")
	private WebElement input_apJobTitle;

	@FindBy(name="homePhone")
	private WebElement input_pgHomePhone;

	@FindBy(name="applicantEmailAddress")
	private WebElement input_pgEmailAddress;

	@FindBy(name="socialSecurityNumber")
	private WebElement input_pgSSN;

	@FindBy(name="dateOfBirth")
	private WebElement input_pgDOB;

	@FindBy(name="applicantIncome")
	private WebElement input_pgAnnualIncome;

	//Field validation errors objects

	@FindBy(xpath="//span[contains(text(), 'Required field')]")
	public WebElement requiredfield;

	@FindBy(xpath="//span[contains(text(), 'Must be at least 4 characters')]")
	public WebElement MustBe4Characters;

	@FindBy(xpath="//span[contains(text(), 'Must be 5 characters')]")
	public WebElement MustBe5Characters;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid email address')]")
	public WebElement validEmailAddress;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Taxpayer ID or FEIN Number')]")
	public WebElement validTaxpayerId;

	@FindBy(xpath="//span[contains(text(),'Can't be a future date']")
	public WebElement CantBeFutureDate;

	@FindBy(xpath="//span[contains(text(), 'Invalid Year')]")
	public WebElement InvalidYear;

	@FindBy(xpath="//span[contains(text(), 'Invalid Date')]")
	public WebElement InvalidDate;

	@FindBy(xpath="//span[contains(text(),'Must be atleast 18 years old')]")
	public WebElement MustBe18YearsOld;

	@FindBy(xpath="//span[contains(text(), 'Must be at least $1000')]")
	public WebElement MustBe$1000;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Business Phone')]")
	public WebElement validBusinessPhone ;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Personal Phone')]")
	public WebElement validPersonalPhone;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Social Security Number')]")
	public WebElement validSSN ;

	@FindBy(xpath="//span[contains(text(), 'Please enter a valid Date of Birth')]")
	public WebElement validDOB;

	@FindBy(xpath="//span[contains(text(), 'Must be at least 6 characters')]")
	public WebElement MustBe6Characters ;

	@FindBy(xpath="//span[contains(text(), 'Must be greater than issue date')]")
	public WebElement MustBeGreaterThanIssueDate;

	@FindBy(xpath="//span[contains(text(), 'Must be greater than current date')]")
	public WebElement MustBeGreaterThanCurrentDate;
	
	@FindBy(xpath="//span[contains(text(),'Must be 17 characters')]")
	public WebElement MustBeSeventeenCharacters;
	

	@FindBy(xpath="//*[text()='Application timeout']")
	public WebElement PopupAppTimeout;

	@FindBy(xpath="//*[text()=' TIME REMAINING:']")
	public WebElement PopupTimeRemaining;

	@FindBy(xpath="//button[contains(text(),'Start Over')]")
	private WebElement click_StartOverButton;

	@FindBy(xpath="//button[contains(text(),'Continue Application')]")
	private WebElement click_ContinueAppButton;

	@FindBy(xpath="//span/a[contains(text(), 'complete your exemption status online')]")
	public WebElement click_temsLink;


	//@FindBy(xpath="//*[text()='My business is tax exempt.']")
	@FindBy(id="taxExempt")
	private WebElement checkBoxTaxExempt;

	@FindBy(xpath="//span[@class='ensightencustomevent sc-jVODtj ekcDPE'][@data-type='Header_banner']")
	public WebElement Tap_for_details;
	//public WebElement TapforDetails;


	@FindBy(xpath="//span[@class='ensightencustomevent sc-jVODtj ekcDPE'][@data-type='Header_banner']")
	public WebElement Hide_details;

	@FindBy(xpath="//div[@id='Header_banner_OfferPromotion']")
	public WebElement tap_for_details_verbiage;

	@FindBy(xpath="//div[@class='sc-jWBwVP gISDaj']")
	public WebElement HorizontallineandSectionicon;

	@FindBy(xpath="//div[@class='sc-eHgmQL cJQfOb']")
	public WebElement subheader_Bipage;

	@FindBy(xpath="//div[@class='sc-cvbbAY fOcTMJ']")
	public WebElement Headerinfotext_Bipage;

	@FindBy(xpath="//h2[contains(text(),'About Your Business')]")
	public WebElement MainHeaderinfo;

	@FindBy(xpath ="ul[@class='sc-bmyXtO hcNRrB']")
	public WebElement Biprogressbar;

	@FindBy(xpath="//div[@class='sc-kEYyzF dMErre'][2]")
	public WebElement BipleasereadTermsandConditions;
	
	@FindBy(xpath="//a[contains(text(),'Terms & Conditions')]")
	public WebElement TermsandConditions;
	
	@FindBy(xpath="//div[@class='sc-eqIVtm bkhtkT']")
	public WebElement TermsandConditionsModelWindow;
	
	@FindBy(xpath="//p[contains(text(),'SAMS BUSINESS ACCOUNT AGREEMENT')]")
	public WebElement SamsBusinesstextinmodelwindow;

	@FindBy(xpath="//div[contains(text(),'X')]")
	public WebElement click_Crossbutton;

	@FindBy(xpath="//img[@class='sc-cqCuEk ghEwCu']")
	public WebElement OfferbannerA;
	
	@FindBy(xpath="//img[@class='sc-krDsej incxRj']")
	public WebElement SamsclubLogo;
	
	@FindBy(id = "companyContact")
	public WebElement Bicompanycontact;
	
	@FindBy(xpath="//p[contains(text(),'Optional') and @id='companyContact']")
	public WebElement BicompanycontactbelowText;
	
	//p[contains(text(),'Optional') and @id='companyContact']

	@FindBy(xpath="//p[@id='businessSuiteEx']")
	public WebElement Suitefieldbelowtext;

	
	@FindBy(xpath="//p[@id='companyzipCodeCityStates']")
	public WebElement companycityandstatebelowtext;

	@FindBy(xpath="//div[contains(text(),'My billing address is the same as my business address.')")
	public WebElement checkboxalongwithbillingaddresstext;

	@FindBy(xpath="//p[@id='businessPhoneEx']")
	public WebElement businessphoneExbelowtext;

	@FindBy(xpath="//hr[@class='sc-eNQAEJ ljwaXC'][1]")
	public WebElement bisecondsectionhorizontalline;

	@FindBy(xpath="//p[@id='baBuilding']")
	public WebElement billingsuitebelowtext;

	@FindBy(xpath="//p[@id='baZipCodeCityStates']")
	public WebElement bacityandstatebelowtext;

	@FindBy(xpath="//p[@id='businessPhoneEx']")
	public WebElement baphoneExbelowtext;

	@FindBy(xpath="//span[contains(text(),'Tap for details')][@data-type='Footer_banner']")
	public WebElement TapForDetails_Footer;

	@FindBy(xpath="//span[contains(text(),'Hide details')][@data-type='Footer_banner']")
	public WebElement HideDetails_Footer;

	@FindBy(id = "Footer_banner_OfferPromotion")
	public WebElement HideDetailsverbiage_footer;

	@FindBy(xpath="//a[@href=' /cs/groups/public/documents/eb_appdoc/CML/eb048702.html']")
	public WebElement Consentto_Electronic_communication;

	@FindBy(xpath="//a[@href=' /cs/groups/public/documents/eb_privacypolicy/CML/eb048699.html']")
	public WebElement PrivacyPolicylink;

	@FindBy(xpath="//a[@href=' /cs/groups/public/documents/eb_appdoc/CML/eb048701.pdf']")
	public WebElement WebSiteusageAgreementlink;

	@FindBy(xpath="//a[@href=' /cs/groups/public/documents/eb_appdoc/CML/eb048700.pdf']")
	public WebElement SYFInternetPolicy;

	@FindBy(xpath="//hr[@class='sc-eNQAEJ ljwaXC'][2]")
	public WebElement biThirdSectionHorizontalline;

	@FindBy(xpath="//img[@src=' /cs/groups/public/documents/eb_image/CML/eb048698.png']")
	public WebElement OfferbannerB;

	@FindBy(xpath="//form[@name='frmApplication' and @target='_self']")
	public WebElement ConsenttoElectroniccommunication_modelwindow;

	@FindBy(xpath="//html[@xmlns='http://www.w3.org/1999/xhtml']")
	public WebElement PrivacyPolicylink_modelwindow;

	@FindBy(xpath="//embed[@id='plugin' and @internalinstanceid='49']")
	public WebElement WebSiteusageAgreementlink_modelwindow;

	@FindBy(xpath="//embed[@id='plugin' and @internalinstanceid='43']")
	public WebElement SYFInternetPolicy_modelwindow;

	@FindBy(xpath="//div[contains(text(),'X')]")
	public WebElement click_crosssymbol;

	@FindBy(xpath="//div[@class='sc-eMigcr eTAFIC']")
	public WebElement BIFootersection;
	
	@FindBy(id="membershipNumber")
	public WebElement Ar_membershipnum;

	
	

	public void EnterfewvaluesinBiFields(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			status=gu.WaitForElePresent(input_companyName, wait1);
			if(status==true){
				if(!CompanyFullLegalName.isEmpty())    {
					gu.entertext(input_companyName, CompanyFullLegalName);
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ,"CompanyFullLegalName value entered: "+CompanyFullLegalName + loggerE.addScreenCapture(screenshotPath));
					System.out.println(screenshotPath);
				}             

				gu.entertext(input_doingBusinessAs, DBAName);
				screenshotPath = gu.getScreenshot(driver,DBAName,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"DBAName value entered: "+DBAName + loggerE.addScreenCapture(screenshotPath));

				gu.selectdropdown(dropdown_businessType, "text",TypeOfBusiness );
				
				screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"TypeOfBusiness value entered: "+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_promcode, PromCode);
				
				screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PromCode value entered: "+PromCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessaddress, BusinessAddress);
				
				screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"BusinessAddress value entered: "+BusinessAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessSuiteEx, Suite);
				
				screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"Suite value entered: "+Suite + loggerE.addScreenCapture(screenshotPath));
				
				gu.entertext(input_zipcode, ZipCode);
				//gu.enterTextWithJS(driver, "companyzipCode", ZipCode);
				driver.findElement(By.xpath("//input[@name='companyzipCode' and @id='companyzipCode' or @placeholder='ZIP Code']")).sendKeys(ZipCode);

				try {
					gu.fluientWaitforElementToVisible(driver, select_zipcodename);
					screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,1, stepNum++);
					loggerE.log(LogStatus.PASS ,"ZipCode value entered: "+ZipCode + loggerE.addScreenCapture(screenshotPath));
				} catch (Exception e) {

					e.printStackTrace();
					screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,0, stepNum++);
					loggerE.log(LogStatus.FAIL ,"ZipCode value entered: "+ZipCode + loggerE.addScreenCapture(screenshotPath));
					loggerE.log(LogStatus.ERROR,"zipcode state not loaded"+e.getMessage());
				}	                                  
				Thread.sleep(2000);	                     
			}	                                         
			
			else{
				status=false;
				logger.info("Business info page web elements are not present or error in bi page");
			}
			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}


	public void pageReload()
	{
		gu.fluientWaitforElementToVisible(driver, input_companyName);
	}

	public void waitFewMins(int a)
	{
		gu.fluientWaitforFewMinsForElementToVisible(driver, PopupTimeRemaining,a );

	}
	public void waitFewMinsForStartOver(int a)
	{
		gu.fluientWaitforFewMinsForElementToVisible(driver, click_StartOverButton,a );

	}

	public void EnterrestvalueInBiFields(String ZipCode,String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String NumberOfEmployes,String YearEstablished,String AnnualRevenue,String RequestedCreditLine) throws Exception{
		boolean status=false;
		try {
			Thread.sleep(2000);

			logger.info(" ZipCode value entered :"+ZipCode);

			Thread.sleep(2000);


			Thread.sleep(2000);
			gu.entertext(input_businessPhone, BusinessPhone);

			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_businessExt, Ext);

			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_emailAddress, EmailAddress);

			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," EmailAddress value entered :"+EmailAddress + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_taxPayerID, TaxPayerId);

			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," TaxPayerId value entered :"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_noOfEmployees, NumberOfEmployes);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," NumberOfEmployes value entered :"+NumberOfEmployes + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_yearEstablished, YearEstablished);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," YearEstablished value entered :"+YearEstablished + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_annualRevenue, AnnualRevenue);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," AnnualRevenue value entered :"+AnnualRevenue + loggerE.addScreenCapture(screenshotPath));

			//gu.entertext(input_requestedCreditLine, RequestedCreditLine);
			driver.findElement(By.id("creditLineRequested")).sendKeys(RequestedCreditLine); 
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," RequestedCreditLine value entered :"+RequestedCreditLine + loggerE.addScreenCapture(screenshotPath));
			status=true;


			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}   
	public void Click_ContinueButton() throws Exception{
		Thread.sleep(1000);

		gu.fluientWaitforElementToVisible(driver, click_continueButton);
		//gu.fluientWaitforElementToVisible(driver, click_ContinueAppButton);
		boolean status=false;
		try {
			if(click_continueButton.isDisplayed()==true){
				//gu.click(click_continueButton);

				gu.clickButtonByJSWithIndex(driver, 0);

				logger.info("User clicks on Continue Button");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," User clicks on Continue Button" + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else if(click_ContinueAppButton.isDisplayed()==true){
				//gu.click(click_continueButton);
				gu.clickButtonByJSWithIndex(driver, 1);

				logger.info("User clicks on Continue AppButton");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," User clicks on Continue Button" + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else if(click_submitButton.isDisplayed()==true){
				//gu.click(click_continueButton);
				logger.info("User clicks on Continue Button");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," User clicks on Continue Button" + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				logger.info("User not clicks on Continue Button");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.FAIL ," User not clicks on Continue Button" + loggerE.addScreenCapture(screenshotPath));
				status=false;
				status=requiredfield.isDisplayed();
				Assert.assertTrue(status, "continue button"+status);
			}					
			Assert.assertTrue(status, "continue button"+status);
		} 
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+e1.getMessage());
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.FAIL ," User not clicks on Continue Button" + loggerE.addScreenCapture(screenshotPath));
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+e2.getMessage());
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.FAIL ," User not clicks on Continue Button" + loggerE.addScreenCapture(screenshotPath));
		}
		Assert.assertTrue(status, "continue button"+status);
	}

	public void click_ContinueAppButtonPopUp() throws Exception{
		Thread.sleep(1000);
		gu.fluientWaitforElementToVisible(driver,click_ContinueAppButton );
		//gu.fluientWaitforElementToVisible(driver, click_ContinueAppButton);
		boolean status=false;
		try {
			if(click_ContinueAppButton.isDisplayed()==true){
				//gu.click(click_continueButton);
				gu.clickButtonByJSWithIndex(driver, 1);			
				logger.info("User clicks on Continue AppButton PopUp");
				status=true;
			}
			else{
				logger.info("User not clicks on Continue Button");
				status=false;
			}					
			Assert.assertTrue(status, "continue button"+status);
		} 
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+e1.getMessage());	
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Clicking Continue Button PopUp"+e2.getMessage());
		}
		Assert.assertTrue(status, "continue button"+status);
	}


	public void clickStartOverButton() throws Exception{
		Thread.sleep(1000);
		gu.fluientWaitforElementToVisible(driver,click_StartOverButton );
		//gu.fluientWaitforElementToVisible(driver, click_StartOverButton);
		boolean status=false;
		try {
			if(click_StartOverButton.isDisplayed()==true){
				//gu.click(click_StartOverButton);					
				gu.clickButtonByJSWithIndex(driver, 1);			
				logger.info("User clicks on Start Over Button");
				status=true;
			}				
			else{
				logger.info("User does not clicks on Start Over Button");
				status=false;
			}					
			Assert.assertTrue(status, "continue button"+status);
		} 
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Clicking Continue Button"+e1.getMessage());	
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Clicking Continue Button PopUp"+e2.getMessage());
		}
		Assert.assertTrue(status, "continue button"+status);
	}


	public void ValiTaxExempt() throws Exception{
		try{

			if(!checkBox1.isSelected()){
				gu.pageScrollDownWithEle(driver, checkBox1);
				System.out.println("Checkbox Present");
				//checkBox1.click();
			}

			gu.captureupdateOTR(driver, document, " Checkbox present");		

		}
		catch(Exception e)
		{
			logger.info("Issue in verifying checkbox... "+e.getMessage());
		}

	}

	public void CheckTaxExempt() throws Exception{
		try{

			if(!checkBox1.isSelected()){
				gu.pageScrollDownWithEle(driver, checkBox1);
				System.out.println("Checkbox checked");
				checkBox1.click();
			}
			
			gu.captureupdateOTR(driver, document, " Checkbox checked");		
			
		}
		catch(Exception e)
		{
			logger.info("Issue in checking checkbox... "+e.getMessage());
		} 
	}

	public void UncheckTaxExempt() throws Exception{
		try{
			gu.fluientWaitforElementToVisible(driver, checkBox1);

			//if(!checkBox1.isSelected()){
			gu.pageScrollDownWithEle(driver, checkBox1);
			System.out.println("Checkbox unchecked");
			checkBox1.click();
			gu.captureupdateOTR(driver, document, " Checkbox unchecked");		
			
		}
		catch(Exception e)
		{
			logger.info("Issue in unchecking checkbox... "+e.getMessage());
		} 
	}



	public void EntervalueInBiFieldUncheckBillingAddr(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String BillingAddress,String BASuite,String BAZipCode,String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String NumberOfEmployes,String YearEstablished,String AnnualRevenue,String RequestedCreditLine) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			status=gu.WaitForElePresent(input_companyName, wait1);
			if(status==true){
				if(!CompanyFullLegalName.isEmpty()) {
					gu.entertext(input_companyName, CompanyFullLegalName);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," CompanyFullLegalName value entered :"+CompanyFullLegalName + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_doingBusinessAs, DBAName);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," DBAName value entered :"+DBAName + loggerE.addScreenCapture(screenshotPath));

					gu.selectdropdown(dropdown_businessType, "text",TypeOfBusiness );
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," TypeOfBusiness value entered :"+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_promcode, PromCode);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," PromCode value entered :"+PromCode + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_businessaddress, BusinessAddress);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," BusinessAddress value entered :"+BusinessAddress + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_businessSuiteEx, Suite);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," Suite value entered :"+Suite + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_zipcode, ZipCode);
					Thread.sleep(1000);
					//sendkeys(driver, input_zipcode, ZipCode);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," ZipCode value entered :"+ZipCode + loggerE.addScreenCapture(screenshotPath));


					gu.clickByJs(driver, "billAddSame");

					//gu.click(checkbox_mybillingaddress);        
					logger.info("my billing address is the same as my business address.check box un checked");

					gu.entertext(input_baBillingAddress, BillingAddress);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," BillingAddress value entered :"+BillingAddress + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_babillingsuite, BASuite);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," BASuite value entered :"+BASuite + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_baZipCode, BAZipCode);
					//sendkeys(driver, input_baZipCode, BAZipCode);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," BAZipCode value entered :"+BAZipCode + loggerE.addScreenCapture(screenshotPath));

					Thread.sleep(1000);
					gu.entertext(input_businessPhone, BusinessPhone);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_businessExt, Ext);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_emailAddress, EmailAddress);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," EmailAddress value entered :"+EmailAddress + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_taxPayerID, TaxPayerId);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," TaxPayerId value entered :"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_noOfEmployees, NumberOfEmployes);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," NumberOfEmployes value entered :"+NumberOfEmployes + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_yearEstablished, YearEstablished);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," YearEstablished value entered :"+YearEstablished + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_annualRevenue, AnnualRevenue);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," AnnualRevenue value entered :"+AnnualRevenue + loggerE.addScreenCapture(screenshotPath));

					gu.entertext(input_requestedCreditLine, RequestedCreditLine);
					
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ," RequestedCreditLine value entered :"+RequestedCreditLine + loggerE.addScreenCapture(screenshotPath));

					status=true;
				}
			}
			else{
				status=false;
				logger.info("Business info page web elements are not present or error in bi page");
			}
			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}
	public void BusinessInfoPage_Elementvalidation(WebDriver driver) throws Exception{
		boolean status=false;
		try{
			if(gu.WaitForElePresentExplicit(driver, input_companyName, 10)){
				status=true;
			}else{
				status=false;
			}
		}catch(Exception e){
			e.printStackTrace();
			throw(e);
		}
		Assert.assertTrue(status, "BusinessInfoPage_Elementvalidation Validation failed");
	}

	public void EntervalueInBiFieldswithAnnualRevenue(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String CityandState, String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String DunAndBstreetNumber,String NumberOfEmployes,String YearEstablished,String AnnualRevenue,String RequestedCreditLine) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			status=gu.WaitForElePresent(input_companyName, wait1);
			if(status==true){
				if(!CompanyFullLegalName.isEmpty())	{
					gu.entertext(input_companyName, CompanyFullLegalName);

					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					System.out.println(screenshotPath);
				}		

				gu.entertext(input_doingBusinessAs, DBAName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"DBAName value entered: "+DBAName + loggerE.addScreenCapture(screenshotPath));

				gu.selectdropdown(dropdown_businessType, "text",TypeOfBusiness );
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"TypeOfBusiness value entered: "+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_promcode, PromCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PromCode value entered: "+PromCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessaddress, BusinessAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"BusinessAddress value entered: "+BusinessAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessSuiteEx, Suite);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"Suite value entered: "+Suite + loggerE.addScreenCapture(screenshotPath));


				driver.findElement(By.xpath("//input[@name='companyzipCode' and @id='companyzipCode' or @placeholder='ZIP Code']")).sendKeys(ZipCode);

				gu.entertext(select_zipcodename, "New York, NY");

				//text();
				logger.info(" ZipCode value entered :"+ZipCode);


				
				gu.entertext(input_businessPhone, BusinessPhone);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessExt, Ext);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_emailAddress, EmailAddress);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," EmailAddress value entered :"+EmailAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_taxPayerID, TaxPayerId);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxPayerId value entered :"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkBoxTaxExempt);
				gu.clickByJs(driver, "taxExempt");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxExempt Check box clicked:"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_dunAndBstreetNumber, DunAndBstreetNumber);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," dunAndBstreetNumber value entered :"+ DunAndBstreetNumber + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_noOfEmployees, NumberOfEmployes);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," NumberOfEmployes value entered :"+NumberOfEmployes + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_yearEstablished, YearEstablished);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," YearEstablished value entered :"+YearEstablished + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_annualRevenue, AnnualRevenue);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," AnnualRevenue value entered :"+AnnualRevenue + loggerE.addScreenCapture(screenshotPath));

				/*JavascriptExecutor jsn=(JavascriptExecutor)driver;
					jsn.executeScript("document.getElementById('creditLineRequested').value='1000';");*/
				gu.entertext(input_requestedCreditLine, RequestedCreditLine);

				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," RequestedCreditLine value entered :"+RequestedCreditLine + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				status=false;
				logger.info("Business info page web elements are not present or error in bi page");
			}
			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}	

	public void EntervalueInBiFields(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String BillingAddress,String BASuite,String BAZipCode,String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String DunAndBstreetNumber,String NumberOfEmployes,String YearEstablished,String AnnualRevenue,String RequestedCreditLine) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			status=gu.WaitForElePresent(input_companyName, wait1);
			if(status==true){
				gu.pageScrollDownWithEle(driver, input_companyName);
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				
				if(!CompanyFullLegalName.isEmpty())	{
					gu.entertext(input_companyName, CompanyFullLegalName);

					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					//loggerE.log(LogStatus.PASS ,"TypeOfBusiness value entered: "+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

					//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					//loggerE.log(LogStatus.PASS ,"CompanyFullLegalName value entered: "+CompanyFullLegalName + loggerE.addScreenCapture(screenshotPath));
					System.out.println(screenshotPath);
				}		

				gu.entertext(input_doingBusinessAs, DBAName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"DBAName value entered: "+DBAName + loggerE.addScreenCapture(screenshotPath));

				gu.selectdropdown(dropdown_businessType, "text",TypeOfBusiness );
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"TypeOfBusiness value entered: "+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_promcode, PromCode);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PromCode value entered: "+PromCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessaddress, BusinessAddress);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"BusinessAddress value entered: "+BusinessAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessSuiteEx, Suite);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"Suite value entered: "+Suite + loggerE.addScreenCapture(screenshotPath));

				//gu.entertext(input_zipcode, ZipCode);
				//gu.enterTextWithJS(driver, "companyzipCode", ZipCode);
				driver.findElement(By.xpath("//input[@name='companyzipCode' and @id='companyzipCode' or @placeholder='ZIP Code']")).sendKeys(ZipCode);
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				gu.entertext(select_zipcodename, "New York, NY");
				/*try {
						gu.fluientWaitforElementToVisible(driver, select_zipcodename);
						screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,1, stepNum++);
						loggerE.log(LogStatus.PASS ,"ZipCode value entered: "+ZipCode + loggerE.addScreenCapture(screenshotPath));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,0, stepNum++);
						loggerE.log(LogStatus.FAIL ,"ZipCode value entered: "+ZipCode + loggerE.addScreenCapture(screenshotPath));
						loggerE.log(LogStatus.ERROR,"zipcode state not loaded"+e.getMessage());
					}
				 */

				
				//enterkey();
				/*gu.entertext(input_zipcode, ZipCode);
					Thread.sleep(3000);
					gu.entertext(input_zipcode, ZipCode);
					Thread.sleep(3000);*/
				//sendkeys(driver, "companyzipCode", ZipCode);
				//driver.findElement(By.name("companyzipCode")).sendKeys(ZipCode); 
				//tab();
				//text();
				logger.info(" ZipCode value entered :"+ZipCode);
				/*status=gu.WaitForEleInVisibility(driver, zipcodeCityName, 10);
					if(status==true){
						status=true;
					}else{
						status=false;
					}*/
				Thread.sleep(1000);
				gu.clickByJs(driver, "billAddSame");
				//gu.click(checkbox_mybillingaddress);		
				logger.info("my billing address is the same as my business address.check box un checked");
				//gu.entertext(select_zipcodename, "New York, NY");
				gu.entertext(input_baBillingAddress, BillingAddress);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BillingAddress value entered :"+BillingAddress + loggerE.addScreenCapture(screenshotPath));


				gu.entertext(input_babillingsuite, BASuite);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BASuite value entered :"+BASuite + loggerE.addScreenCapture(screenshotPath));

				//gu.entertext(input_baZipCode, BAZipCode);
				//gu.enterTextWithJS(driver, "baZipCode", ZipCode);
				//sendkeys(driver, "baZipCode", BAZipCode);
				//driver.findElement(By.name("baZipCode")).sendKeys(BAZipCode); 
				//tab();
				//text();
				
				//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				//loggerE.log(LogStatus.PASS ," BAZipCode value entered :"+BAZipCode + loggerE.addScreenCapture(screenshotPath));
				driver.findElement(By.xpath("//input[@name='baZipCode' and @id='baZipCode' or @placeholder='ZIP Code']")).sendKeys(BAZipCode);
				//gu.entertext(select_bazipcodename, "New York, NY");

				/*try {
						gu.fluientWaitforElementToVisible(driver, select_bazipcodename);
						screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,1, stepNum++);
						loggerE.log(LogStatus.PASS ,"BA ZipCode value entered: "+ZipCode + loggerE.addScreenCapture(screenshotPath));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						screenshotPath = gu.getScreenshot(driver,TypeOfBusiness,0, stepNum++);
						loggerE.log(LogStatus.FAIL ,"BA ZipCode value entered: "+ZipCode + loggerE.addScreenCapture(screenshotPath));
						loggerE.log(LogStatus.ERROR,"BA zipcode state not loaded"+e.getMessage());
					}*/

				
				gu.entertext(input_businessPhone, BusinessPhone);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessExt, Ext);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));

				gu.captureupdateOTR(driver, document, "entering values in bi page ");
				gu.entertext(input_emailAddress, EmailAddress);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," EmailAddress value entered :"+EmailAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_taxPayerID, TaxPayerId);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxPayerId value entered :"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkBoxTaxExempt);
				gu.clickByJs(driver, "taxExempt");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxExempt Check box clicked:"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_dunAndBstreetNumber, DunAndBstreetNumber);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," dunAndBstreetNumber value entered :"+ DunAndBstreetNumber + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_noOfEmployees, NumberOfEmployes);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," NumberOfEmployes value entered :"+NumberOfEmployes + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_yearEstablished, YearEstablished);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," YearEstablished value entered :"+YearEstablished + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_annualRevenue, AnnualRevenue);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," AnnualRevenue value entered :"+AnnualRevenue + loggerE.addScreenCapture(screenshotPath));

				/*JavascriptExecutor jsn=(JavascriptExecutor)driver;
					jsn.executeScript("document.getElementById('creditLineRequested').value='1000';");*/
				gu.entertext(input_requestedCreditLine, RequestedCreditLine);
				//driver.findElement(By.id("creditLineRequested")).sendKeys(RequestedCreditLine); 
				
				//gu.enterTextWithJS(driver, "creditLineRequested", RequestedCreditLine);
				//gu.entertext(input_requestedCreditLine, RequestedCreditLine);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," RequestedCreditLine value entered :"+RequestedCreditLine + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				status=false;
				logger.info("Business info page web elements are not present or error in bi page");
			}
			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}	


	public void EntervalueInBibydefaultFields(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String CityandState, String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String DunAndBstreetNumber,String NumberOfEmployes,String YearEstablished, String AnnualRevenue,String RequestedCreditLine) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			status=gu.WaitForElePresent(input_companyName, wait1);
			if(status==true){
				if(!CompanyFullLegalName.isEmpty())	{

					gu.entertext(input_companyName, CompanyFullLegalName);

					gu.captureupdateOTR(driver, document, " entering values in bi page ");
					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					loggerE.log(LogStatus.PASS ,"CompanyFullLegalName value entered: "+CompanyFullLegalName + loggerE.addScreenCapture(screenshotPath));
					//System.out.println(screenshotPath);
				}		

				gu.entertext(input_doingBusinessAs, DBAName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"DBAName value entered: "+DBAName + loggerE.addScreenCapture(screenshotPath));



				gu.selectdropdown(dropdown_businessType, "text",TypeOfBusiness );
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"TypeOfBusiness value entered: "+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_promcode, PromCode);
				

				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PromCode value entered: "+PromCode + loggerE.addScreenCapture(screenshotPath));


				gu.entertext(input_businessaddress, BusinessAddress);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"BusinessAddress value entered: "+BusinessAddress + loggerE.addScreenCapture(screenshotPath));

				gu.captureupdateOTR(driver, document, " entering values in bi page ");

				gu.entertext(input_businessSuiteEx, Suite);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"Suite value entered: "+Suite + loggerE.addScreenCapture(screenshotPath));

				//gu.entertext(input_zipcode, ZipCode);
				//gu.enterTextWithJS(driver, "companyzipCode", ZipCode);
				driver.findElement(By.xpath("//input[@name='companyzipCode' and @id='companyzipCode' or @placeholder='ZIP Code']")).sendKeys(ZipCode);

				gu.entertext(select_zipcodename, "New York, NY");
				logger.info(" ZipCode value entered :"+ZipCode);

				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				Thread.sleep(3000);

				gu.selectdropdown(select_companyzipCodeCityStates, "value",CityandState );
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CityandState value was selected: "+CityandState + loggerE.addScreenCapture(screenshotPath));


				
				gu.entertext(input_businessPhone, BusinessPhone);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessExt, Ext);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_emailAddress, EmailAddress);

				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," EmailAddress value entered :"+EmailAddress + loggerE.addScreenCapture(screenshotPath));

				gu.captureupdateOTR(driver, document, " entering values in bi page ");


				gu.entertext(input_taxPayerID, TaxPayerId);

				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxPayerId value entered :"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkBoxTaxExempt);
				gu.clickByJs(driver, "taxExempt");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxExempt Check box clicked:"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_dunAndBstreetNumber, DunAndBstreetNumber);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," dunAndBstreetNumber value entered :"+ DunAndBstreetNumber + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_noOfEmployees, NumberOfEmployes);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," NumberOfEmployes value entered :"+NumberOfEmployes + loggerE.addScreenCapture(screenshotPath));


				gu.entertext(input_yearEstablished, YearEstablished);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," YearEstablished value entered :"+YearEstablished + loggerE.addScreenCapture(screenshotPath));

				gu.captureupdateOTR(driver, document, " entering values in bi page ");

				gu.entertext(input_annualRevenue, AnnualRevenue);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," AnnualRevenue value entered :"+AnnualRevenue + loggerE.addScreenCapture(screenshotPath));



				/*JavascriptExecutor jsn=(JavascriptExecutor)driver;
					jsn.executeScript("document.getElementById('creditLineRequested').value='1000';");*/
				gu.entertext(input_requestedCreditLine, RequestedCreditLine);
				//driver.findElement(By.id("creditLineRequested")).sendKeys(RequestedCreditLine); 
				
				//gu.enterTextWithJS(driver, "creditLineRequested", RequestedCreditLine);
				//gu.entertext(input_requestedCreditLine, RequestedCreditLine);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," RequestedCreditLine value entered :"+RequestedCreditLine + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				status=false;
				logger.info("Business info page web elements are not present or error in bi page");
			}
			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}	




	public void EntersomemorevaluesInBiFields(String BusinessPhone,String Ext,String EmailAddress) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			status=gu.WaitForElePresent(input_companyName, wait1);
			if(status==true){		
				Thread.sleep(2000);
				gu.entertext(input_businessPhone, BusinessPhone);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessExt, Ext);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_emailAddress, EmailAddress);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," EmailAddress value entered :"+EmailAddress + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				status=false;
				logger.info("Business info page web elements are not present or error in bi page");
			}
			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}	



	public void Companyname_FieldValidation(String CompanyFullLegalName,String ErrorMessage,String MaxLenght)throws Exception{
		try {
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			gu.entertext(input_companyName, CompanyFullLegalName);
			logger.info(input_companyName+ "  value entered: "+CompanyFullLegalName);
			if(!ErrorMessage.isEmpty() && !ErrorMessage.equals("")){
				String actMssg =gu.getText(requiredfield);
				logger.info(actMssg);
				boolean status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
				logger.info(status);
				if(status==true){
					status=true;
					logger.info("Error message exist and validated");
				}
				Assert.assertEquals(status, true);
				if (status==false){
					status=false;
					logger.info(input_companyName+"validated");
				}
			}
			Assert.assertEquals(status, false);
			if (!MaxLenght.isEmpty() && !MaxLenght.equals("")){
				String actml1 =gu.getMaxLenght(input_companyName);
				int MaxLenght1= Integer.valueOf(MaxLenght);
				int actual= Integer.valueOf(actml1);
				Assert.assertEquals(actual, MaxLenght1);
			}					
		} catch (Exception e) {
			// TODO: handle exception
			status=false;
			e.printStackTrace();
			logger.info(input_companyName+ "  value not entered: "+CompanyFullLegalName);
			logger.info(e.getMessage());
		}
		Assert.assertEquals(status, true);
	}
	public void navigatedTo_BIPage(WebDriver driver) throws Exception{
		gu.fluientWaitforElementToVisible(driver, input_companyName);
		boolean status = false;
		try{
			String urlNew = driver.getCurrentUrl();
			if (urlNew.contains("business-info")){
				logger.info("Navigated to business info page");
				status = true;		
			}
		}catch(Exception e){
			status = false;	
			e.printStackTrace();
			logger.info("Not Navigated to business info page"+e.getMessage());
			throw(e);
		}
		Assert.assertTrue(status, "Business info page");
		logger.info("-------Business info page-------"+status);
	}
	public void FieldValidation(String CompanyFullLegalName,String ErrorMessage,String MaxLenght)throws Exception{
		try {
			gu.entertext(input_companyName, CompanyFullLegalName);
			logger.info(input_companyName+ "  value entered: "+CompanyFullLegalName);
			if(!ErrorMessage.isEmpty() && !ErrorMessage.equals("")){
				String actMssg =gu.getText(requiredfield);
				logger.info(actMssg);
				boolean status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
				logger.info(status);
				if(status==true){
					status=true;
					logger.info("Error message exist and validated");
				}
				Assert.assertEquals(status, true);
				if (status==false){
					status=false;
					logger.info(input_companyName+"validated");
				}
			}
			Assert.assertEquals(status, false);
			if (!MaxLenght.isEmpty() && !MaxLenght.equals("")){
				String actml1 =gu.getMaxLenght(input_companyName);
				int MaxLenght1= Integer.valueOf(MaxLenght);
				int actual= Integer.valueOf(actml1);
				Assert.assertEquals(actual, MaxLenght1);
			}					
		} catch (Exception e) {
			// TODO: handle exception
			status=false;
			e.printStackTrace();
			logger.info(input_companyName+ "  value not entered: "+CompanyFullLegalName);
			logger.info(e.getMessage());
		}
		Assert.assertEquals(status, true);
	}
	public void fetchOrderOfWebElement(String Header,String order1, String order2, String order3)throws Exception{
		boolean status =false;
		try {
			status =gu.getOrder(driver, Header, order1, order2, order3);
			Assert.assertTrue(status, "Elements order");
		} catch (Exception e) {
			status=false;
			// TODO: handle exception
			logger.info(e.getMessage());	
		}
		Assert.assertTrue(status, "Elements order");
	}
	
	public void EnterallBIpageDetailsInLowes(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String DunAndBstreetNumber,String NumberOfEmployes,String YearEstablished,String RequestedCreditLine) throws Exception{
		boolean status=false;
		try {
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			status=gu.WaitForElePresent(input_companyName, wait1);
			if(status==true){
				if(!CompanyFullLegalName.isEmpty())	{
					gu.entertext(input_companyName, CompanyFullLegalName);

					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
					System.out.println(screenshotPath);
				}		

				gu.entertext(input_doingBusinessAs, DBAName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"DBAName value entered: "+DBAName + loggerE.addScreenCapture(screenshotPath));

				gu.selectdropdown(dropdown_businessType, "text",TypeOfBusiness );
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"TypeOfBusiness value entered: "+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_promcode, PromCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PromCode value entered: "+PromCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessaddress, BusinessAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"BusinessAddress value entered: "+BusinessAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessSuiteEx, Suite);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"Suite value entered: "+Suite + loggerE.addScreenCapture(screenshotPath));


				driver.findElement(By.xpath("//input[@name='companyzipCode' and @id='companyzipCode' or @placeholder='ZIP Code']")).sendKeys(ZipCode);

				gu.entertext(select_zipcodename, "New York, NY");

				//text();
				logger.info(" ZipCode value entered :"+ZipCode);

				gu.click(checkbox_mybillingaddress);
				
				gu.entertext(input_businessPhone, BusinessPhone);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessExt, Ext);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_emailAddress, EmailAddress);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," EmailAddress value entered :"+EmailAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_taxPayerID, TaxPayerId);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxPayerId value entered :"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkBoxTaxExempt);
				gu.clickByJs(driver, "taxExempt");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxExempt Check box clicked:"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_dunAndBstreetNumber, DunAndBstreetNumber);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," dunAndBstreetNumber value entered :"+ DunAndBstreetNumber + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_noOfEmployees, NumberOfEmployes);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," NumberOfEmployes value entered :"+NumberOfEmployes + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_yearEstablished, YearEstablished);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," YearEstablished value entered :"+YearEstablished + loggerE.addScreenCapture(screenshotPath));

				//	jsn.executeScript("document.getElementById('creditLineRequested').value='1000';");*/
				gu.entertext(input_requestedCreditLine, RequestedCreditLine);

				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," RequestedCreditLine value entered :"+RequestedCreditLine + loggerE.addScreenCapture(screenshotPath));
				status=true;
			}
			else{
				status=false;
				logger.info("Business info page web elements are not present or error in bi page");
			}
			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}	
	public void fetchOrderOfWebElementInBO()throws Exception{
		boolean status =false;
		try {
			status =gu.getOrderInBO(driver);
			Assert.assertTrue(status, "Elements order");
		} catch (Exception e) {
			status=false;
			// TODO: handle exception
			logger.info(e.getMessage());	
		}
	}
	public void sendkeys(WebDriver driver,String  ele,String WebElementValue){
		try {

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById(\"'+ele+'\").value=\"'+WebElementValue+'\";");
			Thread.sleep(3000);
		} catch (Exception e) {
			status=false;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public  void enterkey () throws Exception{
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
	}
	public  void tab () throws Exception{
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(2000);
	}
	public  void text () throws Exception{
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_1);
		robot.keyPress(KeyEvent.VK_0);
		robot.keyPress(KeyEvent.VK_1);
		robot.keyPress(KeyEvent.VK_0);
		robot.keyPress(KeyEvent.VK_1);
		Thread.sleep(2000);
	}
	public void FieldValues(WebElement ele,String FieldValue,String ErrorMessage,String MaxLength)throws Exception{
		String[] fieldVal ;	 
		String[] errormsg ;

		fieldVal  = FieldValue.split(",");
		int size = fieldVal.length;
		errormsg = ErrorMessage.split(",");
		int size1 = errormsg.length;
		gu.clickByJs(driver, "billAddSame");
		for (int i = 0; i <= size-1; i++) {

			//for (int J = i; J <= size1-1; J--) {
			System.out.println(fieldVal[i]);
			System.out.println(errormsg[i]);
			gu.entertext(ele,fieldVal[i]);
			gu.captureupdateOTR(driver, document, " Test Data :  "+fieldVal[i]);
			tab ();
			int k =i+1;
			gu.captureupdateOTR(driver, document, k+" Test Data :  "+fieldVal[i]);
			//if (!ErrorMessage.equals(null))
			if (!errormsg[i].equals("null")) {
				status = ErrorMessages(errormsg[i]);
				if (status==true){
					logger.info(status);
					//Assert.assertTrue(status, FieldName);
				}else{
					logger.info(status);
				}

			}
		}   		
		if (!MaxLength.isEmpty()){
			String actml1 =gu.getMaxLenght(ele);
			int MaxLenght1= Integer.valueOf(MaxLength);
			int actual= Integer.valueOf(actml1);
			Assert.assertEquals(actual, MaxLenght1);
			logger.info(" actual = "+MaxLenght1);
			status=true;
			//Arrays.fill(fieldVal, null);
		}
	}
	public void validateText(String EnteredText)  throws Exception{
		try {
			String actVal =gu.getEnteredText(input_zipcode);
			if(actVal.equals(EnteredText)){
				//Assert.assertEquals(actVal, EnteredText);
				logger.info(" actual = "+EnteredText);
				gu.captureupdateOTR(driver, document, " Previously entered data is retained, user can continue filling the page further ");
				System.out.println("Previously entered data is retained, user can continue filling the page further");
			}
			else
			{
				System.out.println("Previously entered value is erased, user should start filling the page again");
				gu.captureupdateOTR(driver, document, " Previously entered value is erased, user should start filling the page again ");
			}
		} catch (Exception e) {
			logger.info(e.getMessage());

		}
	}

	public void ValidateRemovalofAnnualField( )  throws Exception{
		try {
			//String actVal =gu.getEnteredText(input_zipcode);
			//if(actVal.equals(EnteredText)){
			//Assert.assertEquals(actVal, EnteredText);
			//int NoOfEmloyee = driver.findElement(By.xpath("//input[@name='numberOfEmployees']")).getLocation().getY();
			int YearEstablished = driver.findElement(By.xpath("//input[@name='inBusinessSince']")).getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			int creditLineRequested = driver.findElement(By.xpath("//input[@name='creditLineRequested']")).getLocation().getY();

			if(YearEstablished<creditLineRequested){

				System.out.println("element are in order");
				status=true;
				gu.pageScrollDownWithEle(driver, input_yearEstablished);
				gu.captureupdateOTR(driver, document, " creditLineRequested is below Noofemployee and Year established field ");
				//screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Elements are not in order");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}

	}



	public void EntervaluesinField(String FieldName,String FieldValue,String ErrorMessage, String MaxLength,String labelname) throws Exception{
		String actMssg = null;
		switch(FieldName){

		case "CFN" :
			FieldValues(input_companyName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "DBA" :
			FieldValues(input_doingBusinessAs, FieldValue, ErrorMessage, MaxLength);
			break;
		case "BAZIPCode" :
			FieldValues(input_zipcode, FieldValue, ErrorMessage, MaxLength);
			break;
		case "companyContact" :
			FieldValues(Bicompanycontact, FieldValue, ErrorMessage, MaxLength);
			break;

		case "PROMOCode" :
			FieldValues(input_promcode, FieldValue, ErrorMessage, MaxLength);
			break;
		case "ZIPCode2" :
			FieldValues(input_baZipCode, FieldValue, ErrorMessage, MaxLength);
			break;
		case "BusinessAddr" :
			FieldValues(input_businessaddress, FieldValue, ErrorMessage, MaxLength);
			break;
		case "BillingAddr" :
			FieldValues(input_baBillingAddress, FieldValue, ErrorMessage, MaxLength);
			break;
		case "BASuite" :
			FieldValues(input_businessSuiteEx, FieldValue, ErrorMessage, MaxLength);
			break;
		case "BiSuite2" :
			FieldValues(input_babillingsuite, FieldValue, ErrorMessage, MaxLength);
			break;	
		case "BusinessPh" :
			FieldValues(input_businessPhone, FieldValue, ErrorMessage, MaxLength);
			break;
		case "BusinessExt" :
			FieldValues(input_businessExt, FieldValue, ErrorMessage, MaxLength);
			break;
		case "Email" :
			FieldValues(input_emailAddress, FieldValue, ErrorMessage, MaxLength);
			break;
		case "TaxPayer" :
			FieldValues(input_taxPayerID, FieldValue, ErrorMessage, MaxLength);
			break;
		case "EmpNo" :
			FieldValues(input_noOfEmployees, FieldValue, ErrorMessage, MaxLength);
			break;
		case "Year" :
			FieldValues(input_yearEstablished, FieldValue, ErrorMessage, MaxLength);
			break;
		case "Revenue" :
			FieldValues(input_annualRevenue, FieldValue, ErrorMessage, MaxLength);
			break;
		case "RequestedCredit" :
			FieldValues(input_requestedCreditLine, FieldValue, ErrorMessage, MaxLength);
			break;
		case "BusinessType" :
			FieldValues(dropdown_businessType, FieldValue, ErrorMessage, MaxLength);
			break;		
		case "FName" :
			FieldValues(input_apFirstName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "MName" :
			FieldValues(input_apMiddleName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "LName" :
			FieldValues(input_apLastName, FieldValue, ErrorMessage, MaxLength);
			break;
		case "JTitle" :
			FieldValues(input_apJobTitle, FieldValue, ErrorMessage, MaxLength);
			break;
		case "Membershipnum" :
			FieldValues(Ar_membershipnum, FieldValue, ErrorMessage, MaxLength);
			break;	
			
		case "ARPhonenum" :
			FieldValues(input_pgHomePhone, FieldValue, ErrorMessage, MaxLength);
			break;	
		case "AREmail" :
			FieldValues(input_pgEmailAddress, FieldValue, ErrorMessage, MaxLength);
			break;		
		case "PGHomeAdd" :
			FieldValues(input_homeAddress, FieldValue, ErrorMessage, MaxLength);
			break;
		case "pgZipCode" :
			FieldValues(input_pgZipCode, FieldValue, ErrorMessage, MaxLength);
			break;
		case "pgHomePhone" :
			FieldValues(input_pgHomePhone, FieldValue, ErrorMessage, MaxLength);
			break;
		case "pgEmailAddress" :
			FieldValues(input_pgEmailAddress, FieldValue, ErrorMessage, MaxLength);
			break;
		case "pgSSN" :
			FieldValues(input_pgSSN, FieldValue, ErrorMessage, MaxLength);
			break;
		case "pgDOB" :
			FieldValues(input_pgDOB, FieldValue, ErrorMessage, MaxLength);
			break;

		case "pgAnnualIncome" :
			FieldValues(input_pgAnnualIncome, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boType0" :
			FieldValues(select_boType0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boFirstname0" :
			FieldValues(input_boFirstname0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boMiddleName0" :
			FieldValues(input_boMiddleName0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boLastname0" :
			FieldValues(input_boLastname0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boHomeaddress0" :
			FieldValues(input_boHomeaddress0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boZipcode0" :
			FieldValues(input_boZipcode0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCitystate0" :
			FieldValues(input_boCitystate0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCheckUSCitizen0" :
			FieldValues(input_boCheckUSCitizen0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boSocialnumber0" :
			FieldValues(input_boSocialnumber0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDateOfBirth0" :
			FieldValues(input_boDateOfBirth0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boPassportnumber0" :
			FieldValues(input_boPassportnumber0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boCountryList0" :
			FieldValues(select_boCountryList0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDescriptiondocument0" :
			FieldValues(select_boDescriptiondocument0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentIssueDate0" :
			FieldValues(input_boDocumentIssueDate0, FieldValue, ErrorMessage, MaxLength);
			break;
		case "boDocumentExpirationDate0" :
			FieldValues(input_boDocumentExpirationDate0, FieldValue, ErrorMessage, MaxLength);
			break;
			
		case "DunAndBstreetNumber" :
			FieldValues(input_dunAndBstreetNumber, FieldValue, ErrorMessage, MaxLength);
			break;
		}
	}
	public boolean ErrorMessages(String ErrorMessage ){
		String actMssg= null;
		boolean status = false;
		switch(ErrorMessage)
		{
		case "Required field" :
			actMssg =gu.getText(requiredfield);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be at least 4 characters" :
			actMssg =gu.getText(MustBe4Characters);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be 5 characters" :
			actMssg =gu.getText(MustBe5Characters);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid email address" :
			actMssg =gu.getText(validEmailAddress);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid Taxpayer ID or FEIN Number" :
			actMssg =gu.getText(validTaxpayerId);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Can't be a future date" :
			actMssg =gu.getText(CantBeFutureDate);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Invalid Year" :
			actMssg =gu.getText(InvalidYear);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Invalid Date" :
			actMssg =gu.getText(InvalidDate);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be atleast 18 years old" :
			actMssg =gu.getText(MustBe18YearsOld);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be at least $1000" :
			actMssg =gu.getText(MustBe$1000);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid Business Phone" :
			actMssg =gu.getText(validBusinessPhone);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid Personal Phone" :
			actMssg =gu.getText(validPersonalPhone);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid Social Security Number" :
			actMssg =gu.getText(validSSN);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Please enter a valid Date of Birth" :
			actMssg =gu.getText(validDOB);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;

		case "Must be at least 6 characters" :
			actMssg =gu.getText(MustBe6Characters);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be greater than issue date" :
			actMssg =gu.getText(MustBeGreaterThanIssueDate);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be greater than current date" :
			actMssg =gu.getText(MustBeGreaterThanCurrentDate);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
		case "Must be 17 characters" :
			actMssg =gu.getText(MustBeSeventeenCharacters);
			logger.info(actMssg);
			status =actMssg.toLowerCase().contains(ErrorMessage.toLowerCase());
			logger.info(status);
			break;
			
		}
		return status;
	}
	public void scrolldowntoele() throws Exception{
		try {
			gu.pageScrollDownWithEle(driver, input_boCheckUSCitizen0);
			logger.info("Scroll down");
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Issue with Scroll down");
		}
	}

	public void EntervalueInBiFieldsinQA(String CompanyFullLegalName,String DBAName,String TypeOfBusiness,String PromCode,String BusinessAddress,String Suite,String ZipCode,String BillingAddress,String BASuite,String BAZipCode,String BusinessPhone,String Ext,String EmailAddress,String TaxPayerId,String DunAndBstreetNumber,String NumberOfEmployes,String YearEstablished,String RequestedCreditLine) throws Exception{
		boolean status=false;
		try {
		
			gu.fluientWaitforElementToVisible(driver, input_companyName);
			status=gu.WaitForElePresent(input_companyName, wait1);
			if(status==true){
				if(!CompanyFullLegalName.isEmpty())	{
					gu.entertext(input_companyName, CompanyFullLegalName);

					screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);

				}		

				gu.entertext(input_doingBusinessAs, DBAName);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"DBAName value entered: "+DBAName + loggerE.addScreenCapture(screenshotPath));

				gu.selectdropdown(dropdown_businessType, "text",TypeOfBusiness );
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"TypeOfBusiness value entered: "+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_promcode, PromCode);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"PromCode value entered: "+PromCode + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessaddress, BusinessAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"BusinessAddress value entered: "+BusinessAddress + loggerE.addScreenCapture(screenshotPath));
				
				gu.entertext(input_businessSuiteEx, Suite);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"Suite value entered: "+Suite + loggerE.addScreenCapture(screenshotPath));
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				
				//gu.entertext(input_zipcode, ZipCode);
				//gu.enterTextWithJS(driver, "companyzipCode", ZipCode);
				driver.findElement(By.xpath("//input[@name='companyzipCode' and @id='companyzipCode' or @placeholder='ZIP Code']")).sendKeys(ZipCode);
				gu.entertext(select_zipcodename, "New York, NY");
				logger.info(" ZipCode value entered :"+ZipCode);
				
				
				Thread.sleep(2000);
				//gu.clickByJs(driver, "billAddSame");
				gu.click(checkbox_mybillingaddress);		
				logger.info("my billing address is the same as my business address.check box un checked");
				//gu.entertext(select_zipcodename, "New York, NY");
				gu.entertext(input_baBillingAddress, BillingAddress);
				
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BillingAddress value entered :"+BillingAddress + loggerE.addScreenCapture(screenshotPath));


				gu.entertext(input_babillingsuite, BASuite);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BASuite value entered :"+BASuite + loggerE.addScreenCapture(screenshotPath));


				driver.findElement(By.xpath("//input[@name='baZipCode' and @id='baZipCode' or @placeholder='ZIP Code']")).sendKeys(BAZipCode);

				gu.entertext(input_businessPhone, BusinessPhone);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_businessExt, Ext);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				
				gu.entertext(input_emailAddress, EmailAddress);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," EmailAddress value entered :"+EmailAddress + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_taxPayerID, TaxPayerId);
				gu.entertext(input_taxPayerID, TaxPayerId);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxPayerId value entered :"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				//gu.click(checkBoxTaxExempt);
				gu.clickByJs(driver, "taxExempt");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," TaxExempt Check box clicked:"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_dunAndBstreetNumber, DunAndBstreetNumber);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," dunAndBstreetNumber value entered :"+ DunAndBstreetNumber + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_noOfEmployees, NumberOfEmployes);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," NumberOfEmployes value entered :"+NumberOfEmployes + loggerE.addScreenCapture(screenshotPath));

				gu.entertext(input_yearEstablished, YearEstablished);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," YearEstablished value entered :"+YearEstablished + loggerE.addScreenCapture(screenshotPath));


				gu.entertext(input_requestedCreditLine, RequestedCreditLine);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ," RequestedCreditLine value entered :"+RequestedCreditLine + loggerE.addScreenCapture(screenshotPath));
				status=true;
				gu.captureupdateOTR(driver, document, " entering values in bi page ");
			}
			else{
				status=false;
				logger.info("Business info page web elements are not present or error in bi page");
			}
			Assert.assertTrue(status, "BI PAGE");
		}
		catch (NoSuchElementException e1) 
		{
			status=false;
			e1.printStackTrace();
			logger.info("Issue in Entering "+e1.getMessage());
			System.out.println("Issue in Entering "+e1.getMessage());
			throw(e1);
		}
		catch (Exception e2) {
			status=false;
			e2.printStackTrace();
			logger.info("Issue in Entering "+e2.getMessage());
			throw(e2);
		}
		Assert.assertTrue(status, "BI PAGE");
	}	

	public void ValidateTapfordetailsLink() throws Exception{
		try {
			WebElement tapfordetailslink = Tap_for_details; 
			if (tapfordetailslink.isDisplayed()){
				logger.info("tapfordetails link is Present in BI page");
				status=true;
				gu.captureupdateOTR(driver, document, " Tap for details link is below the top banner in BI Page");
			}else{
				status=false;
				System.out.println("Tap for details link is not below the top banner in BI Page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}

	public void validateTapfordetailsVerbiage() throws Exception{
		try {
			gu.click(Tap_for_details);
	        Boolean hidedetailstatus= Hide_details.isDisplayed();	
	        Boolean	verbiagestatus = tap_for_details_verbiage.isDisplayed();
		
			if (hidedetailstatus&verbiagestatus){
				logger.info("Hide details and vebiage are displayed");
				status=true;
				gu.captureupdateOTR(driver, document, "Hide details and vebiage are displayed in BI page");
			}else{
				status=false;
				System.out.println("Hide details and vebiage are not displayed in BI page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}

	public void validateverbiagehidden() throws Exception{
		try {
			gu.click(Hide_details);
			WebElement verbiagedetails= tap_for_details_verbiage;
			if (!verbiagedetails.isDisplayed()){
				logger.info("tap for details for top banner verbiage is hidden");
				gu.captureupdateOTR(driver, document, "tap for details for top banner verbiage is hidden");
			}
		}
		catch (NoSuchElementException e1) 
		{e1.printStackTrace();
		loggerE.log(LogStatus.PASS ,"tap for details verbiage is displayed " + loggerE.addScreenCapture(screenshotPath));
		logger.info(e1.getMessage());
		}
	}

	public void validateHorizontallineandSectionicon() throws Exception{
		try {
			if (HorizontallineandSectionicon.isDisplayed()){
				logger.info("Section horizontal line and Section icon is displayed");
				status=true;
				//gu.captureupdateOTR(driver, document, "Section horizontal line and Section icon is displayed");
			}else{
				status=false;
				System.out.println("Section horizontal line and Section icon is not displayed");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}

	public void validateHeaderinfoTextdisplayedbelowSubHeader( )  throws Exception{
		boolean status;
		try {
			int Bisubheader = subheader_Bipage.getLocation().getY();
			int Biheaderinfotext = Headerinfotext_Bipage.getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			if(Bisubheader<Biheaderinfotext){
				System.out.println("Headerinfotext paragraph is below the subheader in Bipage");
				status=true;
				gu.pageScrollDownWithEle(driver, HorizontallineandSectionicon);
				gu.captureupdateOTR(driver, document, " Headerinfotext paragraph is below the subheader in Bipage ");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Headerinfotext paragraph is not below the subheader in Bipage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
	}

	public void validateMainHeaderSection( )  throws Exception{
		boolean status;
		try {
			int biHorizontalline = HorizontallineandSectionicon.getLocation().getY();
			int biMainheader = MainHeaderinfo.getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			if(biHorizontalline<biMainheader){
				System.out.println("MainHeaderInfo is below the Section horizontalline in Bipage");
				status=true;
				gu.pageScrollDownWithEle(driver, HorizontallineandSectionicon);
				gu.captureupdateOTR(driver, document, " MainHeaderInfo is below the Section horizontalline in Bipage ");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("MainHeaderInfo is not below the Section horizontalline in Bipage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
	}

	public void validatesubheadersection( )  throws Exception{
		boolean status;
		try {
			int biMainheader = MainHeaderinfo.getLocation().getY();
			int bisubheader = subheader_Bipage.getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			if(biMainheader<bisubheader){
				System.out.println("Subheadersection is below the MainHeadersection in Bipage");
				status=true;
				gu.pageScrollDownWithEle(driver, HorizontallineandSectionicon);
				gu.captureupdateOTR(driver, document, " Subheadersection is below the MainHeadersection in Bipage ");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Subheadersection is not below the MainHeadersection in Bipage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
	}
	
	public void validateProgressbarinBipage() throws Exception{
		try {
			if (Biprogressbar.isDisplayed()){
				logger.info("Progressbar is displayed in BI page");
				status=true;
				gu.captureupdateOTR(driver, document, " Progressbar is displayed in BI page");
			}else{
				status=false;
				System.out.println("Progressbar is not displayed in BI page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
	}
	
	public void validateTermsandconditionslink( )  throws Exception{
		boolean status;
		try {
			int biprogresbar = Biprogressbar.getLocation().getY();
			int bireadTermsandconditions = BipleasereadTermsandConditions.getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			if(biprogresbar<bireadTermsandconditions){
				System.out.println("pleasereadTermsandConditions text is below the progresbar in Bipage");
				status=true;
				gu.pageScrollDownWithEle(driver, HorizontallineandSectionicon);
				gu.captureupdateOTR(driver, document, " pleasereadTermsandConditions text is below the progresbar in Bipage ");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("pleasereadTermsandConditions text is not below the progresbar in Bipage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	}
	
	public void validateModelWindow() throws Exception{
		try {
			gu.captureupdateOTR(driver, document, "TermsandConditionslink is displayed ");
			gu.click(TermsandConditions);
			gu.captureupdateOTR(driver, document, "TermsandConditions are displayed in ModelWindow");
			if (TermsandConditionsModelWindow.isDisplayed()){
				logger.info("TermsandConditions are displayed in ModelWindow");
				status=true;
				gu.pageScrollDownWithEle(driver, SamsBusinesstextinmodelwindow);
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				gu.captureupdateOTR(driver, document, "TermsandConditions are displayed in ModelWindow");
			}else{
				status=false;
				System.out.println("TermsandConditions are not displayed in ModelWindow");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}
	
	public void verifyBusinessInfoPageisbackafterclickingOnCrossButton() throws Exception{
		try {
			gu.click(click_Crossbutton);
			if (MainHeaderinfo.isDisplayed()){
				logger.info("BusinessInfoPage is back after clicking On CrossButton");
				status=true;
				gu.pageScrollDownWithEle(driver, HorizontallineandSectionicon);
				gu.captureupdateOTR(driver, document, "BusinessInfoPage is back after clicking On CrossButton in terms and conditions");
			}else{
				status=false;
				System.out.println("BusinessInfoPage is not displayed after clicking On CrossButton in terms and conditions");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}
	
	public void validateOfferBannerA( )  throws Exception{
		boolean status;
		try {

			int biSamsclubLogo = SamsclubLogo.getLocation().getY();
			int biOfferbannerA = OfferbannerA.getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);

			if(biSamsclubLogo<biOfferbannerA){

				System.out.println("OfferbannerA  is displayed below the SamsclubLogo in Bipage");
				status=true;
				gu.pageScrollDownWithEle(driver, HorizontallineandSectionicon);
				gu.captureupdateOTR(driver, document, " OfferbannerA  is displayed below the SamsclubLogo in Bipage ");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("OfferbannerA  is not displayed below the SamsclubLogo in Bipage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}

	}

	public void validateCompanyContactVerbiage(String Bicomapnycontactverbiage) throws Exception{

		boolean status=false;
		try{
			gu.click(Bicompanycontact);
			gu.pageScrollDownWithEle(driver, input_companyName);
			gu.captureupdateOTR(driver, document, " BiCompanycontact verbiage is appeared in Bipage");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			List<WebElement> p= driver.findElements(By.cssSelector("*"));
			for(WebElement i:p)
			{	S=i.getText();
				System.out.println(S);
				if(S.equalsIgnoreCase(Bicomapnycontactverbiage))
				{
					status =true;
					logger.info("BiCompanycontact verbiage verified successfully");
					break;
				}	}

			System.out.println("BiCompanycontact verbiage verified successfully");
		} catch (Exception e) {
			logger.info("Issue with BiCompanycontact verbiage");
			logger.info(e.getMessage());
		}
	}
		
		public void validateCompanyContactVerbiagedisappear( ) throws Exception{

			boolean status=false;
			try{
					gu.click(input_businessSuiteEx);
					gu.captureupdateOTR(driver, document, " BiCompanycontact verbiage is disappeared after clicking outside of the field in Bipage");
                logger.info(" BiCompanycontact verbiage is disappered");
			
			} catch (Exception e) {
				logger.info("Issue with BiCompanycontact verbiage");
				logger.info(e.getMessage());
			}	}
	
		public void validatecheckboxisUncheckedandbillingaddressverbiage(String BiBillingaddressverbiage) throws Exception{

			boolean status=false;
			try{
				Thread.sleep(2000);
				gu.clickByJs(driver, "billAddSame");
				gu.captureupdateOTR(driver, document, " billing address checkbox is unchecked in Bipage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				gu.click(input_baBillingAddress);
				gu.pageScrollDownWithEle(driver, input_zipcode);
				gu.captureupdateOTR(driver, document, " Billing address verbiage is appeared in Bipage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);

				List<WebElement> p= driver.findElements(By.cssSelector("*"));
				for(WebElement i:p)
				{
                  	S=i.getText();
					if(S.equalsIgnoreCase(BiBillingaddressverbiage))
					{
						status =true;
						logger.info("BiBillingaddres verbiage verified successfully");
						break;
					}	}
				
			} catch (Exception e) {
				logger.info("Issue with BiBillingaddres verbiage");
				logger.info(e.getMessage());
			}
		}
	
		public void validateBillingaddressVerbiagedisappear( ) throws Exception{

			boolean status=false;
			try{
			    gu.click(input_businessSuiteEx);
				gu.captureupdateOTR(driver, document, " Billing address verbiage is appeared in Bipage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
                logger.info(" BiBillingaddress verbiage is disappered");
			
			} catch (Exception e) {
				logger.info("Issue with BiBillingaddress verbiage");
				logger.info(e.getMessage());
			}
	}	
		
		public void validateBusinessaddressverbiage(String BiBusinessaddressverbiage) throws Exception{
          
			boolean status=false;
			try{
				gu.pageScrollDownWithEle(driver, Bicompanycontact);
				Thread.sleep(2000);
				gu.click(input_businessaddress);
				gu.captureupdateOTR(driver, document, " businessaddress verbiage is appeared in Bipage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				List<WebElement> p= driver.findElements(By.cssSelector("*"));
				for(WebElement i:p)
				{
					S=i.getText();
					
					if(S.equalsIgnoreCase(BiBusinessaddressverbiage))
					{
						status =true;
						logger.info("BiBusinessaddress verbiageverified successfully");
						break;
					}}
				
			} catch (Exception e) {
				logger.info("Issue with BiBusinessaddress verbiage");
				logger.info(e.getMessage());
			}
		}
	
		public void validateBusinessaddressVerbiagedisappear( ) throws Exception{

			boolean status=false;
			try{
				gu.click(input_businessSuiteEx);
				gu.captureupdateOTR(driver, document, " businessaddress verbiage is disappeared in Bipage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
                logger.info(" BusinessAddress verbiage is disappered");
				} catch (Exception e) {
				logger.info("Issue with BusinessAddress verbiage");
				logger.info(e.getMessage());
			}
	}
	
	
		public void validateBusinessphoneverbiage(String BiBusinessPhoneverbiage) throws Exception{

			boolean status=false;
			try{
				Thread.sleep(2000);
				gu.click(input_businessPhone);
				gu.pageScrollDownWithEle(driver, input_zipcode);
				gu.captureupdateOTR(driver, document, " businessphone verbiage is appeared in Bipage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				List<WebElement> p= driver.findElements(By.cssSelector("*"));
				for(WebElement i:p)
				{
					S=i.getText();
					//System.out.println(S);
					if(S.equalsIgnoreCase(BiBusinessPhoneverbiage))
					{
						status =true;
						logger.info("BiBusinessPhoneverbiage verified successfully");
						break;
					}
				}
				
			} catch (Exception e) {
				logger.info("Issue with BiBusinessPhoneverbiage");
				logger.info(e.getMessage());
			}
		}
		public void validateBusinessphoneVerbiagedisappear( ) throws Exception{
			try{
				gu.click(input_businessSuiteEx);
				gu.captureupdateOTR(driver, document, " businessphone verbiage is disappeared in Bipage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
                logger.info(" Bibusinessphone verbiage is disappered");
			} catch (Exception e) {
				logger.info("Issue with Bibusinessphone verbiage");
				logger.info(e.getMessage());
			}
	}
		
	public void validateSecondsectionfieldsalongwithbelowfieldtext() throws Exception{
		try {
			Thread.sleep(2000);
			gu.pageScrollDownWithEle(driver, Bicompanycontact);
			gu.captureupdateOTR(driver, document, "All the fields in second section are displayed in Bi page");
	        Boolean businessaddressstatus= input_businessaddress.isDisplayed();	
	        Boolean	businesssuitestatus = input_businessSuiteEx.isDisplayed();
	        Boolean suiteverbiage= Suitefieldbelowtext.isDisplayed();	
	        Boolean	zipcodestatus = input_zipcode.isDisplayed();
	        Boolean cityandstatestatus= select_companyzipCodeCityStates.isDisplayed();	
	        Boolean	cityandstateverbiage = companycityandstatebelowtext.isDisplayed();
	        Boolean checkboxwithbillngaddresstext= checkboxalongwithbillingaddresstext.isDisplayed();	
	        Boolean	businessphonestatus = input_businessPhone.isDisplayed();
	        Boolean businessextstatus = input_businessExt.isDisplayed();	
	        Boolean businessextverbiage= businessphoneExbelowtext.isDisplayed();
		
			if (businessaddressstatus&businesssuitestatus&suiteverbiage&zipcodestatus&cityandstatestatus&cityandstateverbiage&checkboxwithbillngaddresstext&businessphonestatus&businessextstatus&businessextverbiage){
				logger.info("All the fields in second section are displayed in Bi page");
				status=true;
				gu.captureupdateOTR(driver, document, "All the fields in second section are displayed in Bi page");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("All the fields in second section are not displayed in BI page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
	}	
	
	public void validatesecondsectionhorizontallineisbelowthecompanycontact( )  throws Exception{
		boolean status;
		try {
			
			gu.pageScrollDownWithEle(driver, input_companyName);
			int companycontact = Bicompanycontact.getLocation().getY();
			int bihorizontalline = bisecondsectionhorizontalline.getLocation().getY();
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			if(companycontact<bihorizontalline){

				System.out.println("Second Section horizontal line is below the company contact in Bipage");
				status=true;
				gu.captureupdateOTR(driver, document, " Second Section horizontal line is displayed below the company contact in Bipage");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Second Section horizontal line is not below the company contact in Bipage");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
	}
	
	public void validatebusinessphoneandExttextfieldsarebelowsecondsectioncheckbox( )  throws Exception{
		boolean status;
		try {
			  Thread.sleep(2000);
			 gu.pageScrollDownWithEle(driver, Bicompanycontact);
			 gu.captureupdateOTR(driver, document, " Businessphone and Ext fields are displayed below the billingaddress checkbox in Bi page");
			int bicheckboxofbillingaddress = checkboxalongwithbillingaddresstext.getLocation().getY();
			int businessphone = input_businessPhone.getLocation().getY();
			int businessExt = input_businessExt.getLocation().getY();
			
			if(bicheckboxofbillingaddress< businessphone && businessphone < businessExt){
				System.out.println("Businessphone and Ext fields are displayed below the billingaddress checkbox in Bi page");
				status=true;
				gu.captureupdateOTR(driver, document, " Businessphone and Ext fields are displayed below the billingaddress checkbox in Bi page");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("Businessphone and Ext fields are not displayed below the billingaddress checkbox in Bi page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}
	}
	
public void validateallfieldsafteruncheckingthebillingaddresscheckbox() throws Exception{
		try {
			
			Thread.sleep(2000);
			gu.pageScrollDownWithEle(driver, input_businessaddress);
			gu.clickByJs(driver, "billAddSame");
			gu.captureupdateOTR(driver, document, "billing adress fields are displayed after unchecking the checkbox Bi page");
	        Boolean billingaddress= input_baBillingAddress.isDisplayed();	
	        Boolean	billingsuitetext = billingsuitebelowtext.isDisplayed();
	        Boolean basuite= input_babillingsuite.isDisplayed();	
	        Boolean	bazipcode = input_baZipCode.isDisplayed();
	        Boolean bacityandstate= input_bacityandstate.isDisplayed();	
	        Boolean	bacityandstatetext = bacityandstatebelowtext.isDisplayed();
	        Boolean babusinessphone= input_businessPhone.isDisplayed();	
	        Boolean	babusinessExt = input_businessExt.isDisplayed();
	        Boolean baphonetext = baphoneExbelowtext.isDisplayed();	
			if (billingaddress&billingsuitetext&basuite&bazipcode&bacityandstate&bacityandstatetext&babusinessphone&babusinessExt&baphonetext){
				logger.info("billing adress fields are displayed after unchecking the checkbox Bi page");
				status=true;
				gu.captureupdateOTR(driver, document, "billing adress fields are displayed after unchecking the checkbox Bi page");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			}else{
				status=false;
				System.out.println("billing adress fields are not displayed after unchecking the checkbox Bi page");
			}
		}catch (Exception e) {
			status=false;
			logger.info(e.getMessage());
		}	
		
	}	
	
public void ValidateTapForDetailsLinkbelowtheBottomBanner() throws Exception{
	try {
		Thread.sleep(2000);
		gu.pageScrollDownWithEle(driver, Consentto_Electronic_communication);
		if (TapForDetails_Footer.isDisplayed()){
			
			logger.info("tapfordetails link is Present below the Bottom banner in BI page");
			status=true;
			gu.captureupdateOTR(driver, document, " tapfordetails link is Present below the Bottom banner in BI Page");
		}else{
			status=false;
			System.out.println("TapforDetails link is not Present below the Bottom banner in BI Page");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}

public void validateTapfordetailsVerbiageforBottonbanner() throws Exception{
	try {
		Thread.sleep(2000);
		gu.pageScrollDownWithEle(driver, Consentto_Electronic_communication);
		gu.click(TapForDetails_Footer);
        Boolean hidedetailsfooterstatus= HideDetails_Footer.isDisplayed();	
        Boolean	verbiagefooterstatus = HideDetailsverbiage_footer.isDisplayed();
	
		if (hidedetailsfooterstatus&verbiagefooterstatus){
			logger.info("Hide details and vebiage are displayed for bottombanner");
			status=true;
			gu.captureupdateOTR(driver, document, "Hide details and vebiage are displayed for bottom banner in BI page");
		}else{
			status=false;
			System.out.println("Hide details and vebiage are not displayed for bottom banner in BI page");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}

public void validateverbiagehiddenforBottombanner() throws Exception{
	try {
		Thread.sleep(2000);
		gu.pageScrollDownWithEle(driver, Consentto_Electronic_communication);
		gu.click(HideDetails_Footer);
		if (!HideDetailsverbiage_footer.isDisplayed()){
			logger.info("tap for details for top banner verbiage is hidden");
			gu.captureupdateOTR(driver, document, "tap for details for Bottom banner verbiage is hidden");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		}
	}
	catch (NoSuchElementException e1) 
	{e1.printStackTrace();
	loggerE.log(LogStatus.PASS ,"tap for details verbiage is displayed " + loggerE.addScreenCapture(screenshotPath));
	logger.info(e1.getMessage());
	}
}

public void validateThirdsectionfields() throws Exception{
	try {
		Thread.sleep(2000);
		gu.pageScrollDownWithEle(driver, biThirdSectionHorizontalline);
        Boolean biTaxpayerID= input_taxPayerID.isDisplayed();	
        Boolean	biDunAndBstreet = input_dunAndBstreetNumber.isDisplayed();
        Boolean biyearestablished= input_yearEstablished.isDisplayed();	
        Boolean	bicontinuebutton = click_continueButton.isDisplayed();
        
		if (biTaxpayerID&biDunAndBstreet&biyearestablished&bicontinuebutton){
			logger.info("Third Section fields are displayed in Bi page");
			status=true;
			gu.captureupdateOTR(driver, document, "Third Section fields are displayed in Bi page");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		}else{
			status=false;
			System.out.println("Third Section fields are not displayed in Bi page");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}	

public void validateThirdSectionHorizontalline() throws Exception{
	try {
		Thread.sleep(2000);
		gu.pageScrollDownWithEle(driver, input_businessPhone);
		if (biThirdSectionHorizontalline.isDisplayed()){
			
			logger.info("Third Section Horizontal line is displayed in BI page");
			status=true;
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			gu.captureupdateOTR(driver, document, " Third Section Horizontal line is displayed in BI page in BI Page");
		}else{
			status=false;
			System.out.println("Third Section Horizontal line is not displayed in BI page in BI Page");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}

public void validateOfferBannerB( )  throws Exception{
	boolean status;
	try {
		Thread.sleep(2000);
		gu.pageScrollDownWithEle(driver, click_continueButton);
		int biOfferbannerB = OfferbannerB.getLocation().getY();
		int biconsentelectronic = Consentto_Electronic_communication.getLocation().getY();
		
		if(biOfferbannerB<biconsentelectronic){
			System.out.println("OfferbannerB  is displayed above the Consent Electronic communication in Bipage");
			status=true;
			gu.captureupdateOTR(driver, document, " OfferbannerB  is displayed above the Consent Electronic communication in Bipage ");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		}else{
			status=false;
			System.out.println("OfferbannerB  is not displayed above the Consent Electronic communication in Bipage");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}

}

public void validateTaxPayerIDinfotext(String BITaxPayerIDVerbiage) throws Exception{

	boolean status=false;
	try{
		Thread.sleep(2000);
		gu.pageScrollDownWithEle(driver, input_businessPhone);
		Thread.sleep(2000);
		gu.click(input_taxPayerID);
		
		gu.captureupdateOTR(driver, document, " TaxPayerID verbiage is appeared in Bipage");
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);

		List<WebElement> p= driver.findElements(By.cssSelector("*"));
		for(WebElement i:p)
		{
			S=i.getText();
			//System.out.println(S);
			if(S.equalsIgnoreCase(BITaxPayerIDVerbiage))
			{
				status =true;
				logger.info("TaxPayerID verbiageverified successfully");
				break;
			}
		}
		
	} catch (Exception e) {
		logger.info("Issue with TaxPayerID verbiage");
		logger.info(e.getMessage());
	}
}

public void validateTaxPayerIDinfotextdisappear( ) throws Exception{
	boolean status=false;
	try{
		gu.click(input_yearEstablished);
		gu.captureupdateOTR(driver, document, " TaxPayerID verbiage is disappeared in Bipage");
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
        logger.info(" TaxPayerID verbiage is disappered");
	} catch (Exception e) {
		logger.info("Issue with TaxPayerID verbiage");
		logger.info(e.getMessage());
	}
}

public void validateDunandBradstreetinfotext(String BIDunandBradstreetverbiage) throws Exception{

	boolean status=false;
	try{
		Thread.sleep(2000);
		gu.pageScrollDownWithEle(driver, input_businessPhone);
		Thread.sleep(2000);
		gu.click(input_dunAndBstreetNumber);
		gu.captureupdateOTR(driver, document, " dunAndBstreetNumber verbiage is appeared in Bipage");
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);

		List<WebElement> p= driver.findElements(By.cssSelector("*"));
		for(WebElement i:p)
		{
			S=i.getText();
			
			if(S.equalsIgnoreCase(BIDunandBradstreetverbiage))
			{
				status =true;
				logger.info("dunAndBstreetNumber verbiageverified successfully");
				break;
			}
		}
		
	} catch (Exception e) {
		logger.info("Issue with dunAndBstreetNumber verbiage");
		logger.info(e.getMessage());
	}
}

public void validateDunandBradStreetinfotextDisappear( ) throws Exception{

	try{
		gu.click(input_yearEstablished);
		gu.captureupdateOTR(driver, document, " dunAndBstreetNumber verbiage is disappeared in Bipage");
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);

        logger.info(" dunAndBstreetNumber verbiage is disappered");
	
	} catch (Exception e) {
		logger.info("Issue with dunAndBstreetNumber verbiage");
		logger.info(e.getMessage());
	}
}

public void validateConsenttoEClinkmodelwindow() throws Exception{
	try {
		
		gu.pageScrollDownWithEle(driver, click_continueButton);
		Thread.sleep(2000);
		gu.click(Consentto_Electronic_communication);
		Thread.sleep(3000);
		gu.captureupdateOTR(driver, document, "ConsenttoECtext is displayed in ModelWindow");
		if (ConsenttoElectroniccommunication_modelwindow.isDisplayed()){
			gu.captureupdateOTR(driver, document, "ConsenttoECtext is displayed in ModelWindow");
			logger.info("ConsenttoEClinktext is displayed in ModelWindow");
			status=true;
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			gu.captureupdateOTR(driver, document, "ConsenttoECtext is displayed in ModelWindow");
		}else{
			status=false;
			//System.out.println("ConsenttoEClinktext is not displayed in ModelWindow");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}

public void validatecloseModelWindow() throws Exception{
	try{
		gu.click(click_crosssymbol);
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		logger.info("modelwindow closed after clicking crosssymbol in Bi page");
		gu.captureupdateOTR(driver, document, "Modelwindow is closed");
	}
	catch(Exception e){
		logger.info(e.getMessage());
	}
}

public void validatePrivacypolicylinkmodelwindow() throws Exception{
	try {
		
        gu.click(PrivacyPolicylink);
        Thread.sleep(5000);
		gu.captureupdateOTR(driver, document, "Privacypolicylinktext is displayed in ModelWindow");
		if (PrivacyPolicylink_modelwindow.isDisplayed()){
			gu.captureupdateOTR(driver, document, "Privacypolicylinktext is displayed in ModelWindow");
			logger.info("Privacypolicylinktext is displayed in ModelWindow");
			status=true;
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			gu.captureupdateOTR(driver, document, "Privacypolicylinktext is displayed in ModelWindow");
		}else{
			status=false;
			//System.out.println("Privacypolicylinktext is not displayed in ModelWindow");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}


public void validateWenSiteusageAgreementModelwindow() throws Exception{
	try {
		gu.click(WebSiteusageAgreementlink);
		Thread.sleep(5000);
		gu.captureupdateOTR(driver, document, "WebSiteusageAgreementlinktext is displayed in ModelWindow");
		screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
		if (WebSiteusageAgreementlink_modelwindow.isDisplayed()){
			logger.info("WebSiteusageAgreementlinktext is displayed in ModelWindow");
			status=true;
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			gu.captureupdateOTR(driver, document, "WebSiteusageAgreementlinktext is displayed in ModelWindow");
		}else{
			status=false;
			System.out.println("WebSiteusageAgreementlinktext is not displayed in ModelWindow");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}


public void validateSYFInternetPrivacypolicyModelwindow() throws Exception{
	try {
	    
		gu.click(SYFInternetPolicy);
		Thread.sleep(5000);
		gu.captureupdateOTR(driver, document, "SYFInternetPolicylinktext is displayed in ModelWindow");
		if (SYFInternetPolicy_modelwindow.isDisplayed()){
			logger.info("SYFInternetPolicylinktext is displayed in ModelWindow");
			status=true;
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			gu.captureupdateOTR(driver, document, "SYFInternetPolicylinktext is displayed in ModelWindow");
		}else{
			status=false;
			System.out.println("SYFInternetPolicylinktext is not displayed in ModelWindow");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}

public void validateBIFirstSectionFields(){
	Boolean status=false;
	try{
		gu.pageScrollDownWithEle(driver, MainHeaderinfo);
		 Boolean bilegalname = input_companyName.isDisplayed();
		 Boolean biBusinessType = dropdown_businessType.isDisplayed(); 
		 Boolean bicompanycontactstatus = Bicompanycontact.isDisplayed();
		 Boolean bicompanycontacttext = BicompanycontactbelowText.isDisplayed();
		 
		if(bilegalname&biBusinessType&bicompanycontactstatus&bicompanycontacttext){
			logger.info("First Section Fields are displayed in BI page");
			status=true;
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			gu.captureupdateOTR(driver, document, "First Section Fields are displayed in BI page");
		}else{
			status=false;
			System.out.println("First Section Fields are not displayed in BI page");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}
public void validateFooterSectionInBI() throws Exception{
	try {
	    
		gu.pageScrollDownWithEle(driver, click_continueButton);
		gu.captureupdateOTR(driver, document, "Footer Section is displayed bottom of the BI page");
		if (BIFootersection.isDisplayed()){
			logger.info("Footer Section is displayed bottom of the BI page");
			status=true;
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			gu.captureupdateOTR(driver, document, "Footer Section is displayed bottom of the BI page");
		}else{
			status=false;
			System.out.println("Footer Section is not displayed bottom of the BI page");
		}
	}catch (Exception e) {
		status=false;
		logger.info(e.getMessage());
	}	
}

public void EnterBiFieldDetailsforsams(String CompanyFullLegalName,String TypeOfBusiness,String CompanyContact,String BusinessAddress,String Suite,String ZipCode,String BusinessPhone,String Ext,String TaxPayerId,String DunAndBstreetNumber,String YearEstablished) throws Exception{
	boolean status=false;
	try {
		gu.fluientWaitforElementToVisible(driver, input_companyName);
		status=gu.WaitForElePresent(input_companyName, wait1);
		if(status==true){
			if(!CompanyFullLegalName.isEmpty())	{

				gu.entertext(input_companyName, CompanyFullLegalName);

				gu.captureupdateOTR(driver, document, " entering values in bi page ");
				screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
				loggerE.log(LogStatus.PASS ,"CompanyFullLegalName value entered: "+CompanyFullLegalName + loggerE.addScreenCapture(screenshotPath));
				//System.out.println(screenshotPath);
			}		

			
			gu.selectdropdown(dropdown_businessType, "text",TypeOfBusiness );
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"TypeOfBusiness value entered: "+TypeOfBusiness + loggerE.addScreenCapture(screenshotPath));

			
			gu.entertext(Bicompanycontact, CompanyContact);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"CompanyContact value entered: "+CompanyContact + loggerE.addScreenCapture(screenshotPath));
			gu.captureupdateOTR(driver, document, " entering values in bi page ");

			gu.entertext(input_businessaddress, BusinessAddress);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"BusinessAddress value entered: "+BusinessAddress + loggerE.addScreenCapture(screenshotPath));
			gu.captureupdateOTR(driver, document, " entering values in bi page ");

			gu.entertext(input_businessSuiteEx, Suite);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ,"Suite value entered: "+Suite + loggerE.addScreenCapture(screenshotPath));
			//gu.entertext(input_zipcode, ZipCode);
			//gu.enterTextWithJS(driver, "companyzipCode", ZipCode);
			driver.findElement(By.xpath("//input[@name='companyzipCode' and @id='companyzipCode' or @placeholder='ZIP Code']")).sendKeys(ZipCode);

			gu.entertext(select_zipcodename, "New York, NY");
			logger.info(" ZipCode value entered :"+ZipCode);
			gu.captureupdateOTR(driver, document, " entering values in bi page ");
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			Thread.sleep(3000);
			
			gu.entertext(input_businessPhone, BusinessPhone);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," BusinessPhone value entered :"+BusinessPhone + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_businessExt, Ext);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," Ext value entered :"+Ext + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_taxPayerID, TaxPayerId);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," TaxPayerId value entered :"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

			//gu.click(checkBoxTaxExempt);
//			gu.clickByJs(driver, "taxExempt");
//			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
//			loggerE.log(LogStatus.PASS ," TaxExempt Check box clicked:"+TaxPayerId + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_dunAndBstreetNumber, DunAndBstreetNumber);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," dunAndBstreetNumber value entered :"+ DunAndBstreetNumber + loggerE.addScreenCapture(screenshotPath));

			gu.entertext(input_yearEstablished, YearEstablished);
			
			screenshotPath = gu.getScreenshot(driver,TCNameNew,1, stepNum++);
			loggerE.log(LogStatus.PASS ," YearEstablished value entered :"+YearEstablished + loggerE.addScreenCapture(screenshotPath));

			gu.captureupdateOTR(driver, document, " entering values in bi page ");

		 status=true;
		}
		else{
			status=false;
			logger.info("Business info page web elements are not present or error in bi page");
		}
		Assert.assertTrue(status, "BI PAGE");
	}
	catch (NoSuchElementException e1) 
	{
		status=false;
		e1.printStackTrace();
		logger.info("Issue in Entering "+e1.getMessage());
		System.out.println("Issue in Entering "+e1.getMessage());
		throw(e1);
	}
	catch (Exception e2) {
		status=false;
		e2.printStackTrace();
		logger.info("Issue in Entering "+e2.getMessage());
		throw(e2);
	}
	Assert.assertTrue(status, "BI PAGE");
}	




}













