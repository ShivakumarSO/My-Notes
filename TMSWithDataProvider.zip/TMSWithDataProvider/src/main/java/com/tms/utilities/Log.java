package com.tms.utilities;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



public class Log {

	private static Logger Log = Logger.getLogger(Log.class.getName()); 
	static String userdir = System.getProperty("user.dir");
	public static void startTestCase(String sTestCaseName){
		PropertyConfigurator.configure(userdir + "//Logs//log4j.properties");
		Log.info("Got property file....");
		Log.info("Started Test case : " + sTestCaseName);
    }


	public static void endTestCase(String sTestCaseName){
		Log.info("Ended Test Case : " + sTestCaseName);		
	}

	public static void info(String message)	{
		Log.info(message);
	}
	
	public static void error(String message)	{
		Log.error(message);
	}
	 
	 public static void debug(String message) {	 
	    Log.debug(message);	 
	 }
	 
}