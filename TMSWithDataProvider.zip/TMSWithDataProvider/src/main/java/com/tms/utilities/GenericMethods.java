package com.tms.utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.util.Units;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.Borders;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.collections.Maps;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;

import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class GenericMethods 
{
	public static FileInputStream fis;
	public static FileInputStream fi=null;
	public static Workbook wb = null;
	public static FileOutputStream fo=null;

	public static String getProperties(String propertyType) throws IOException
	{
		FileReader reader=new FileReader(System.getProperty("user.dir")+"\\Resources\\testdata\\GlobalProperties.properties"); 
		Properties prop=new Properties();
		prop.load(reader);
		String data=prop.getProperty(propertyType);
		return data;
	}
	public static String CurrentDateAndTime() 
	{
		DateFormat dateFormat = new SimpleDateFormat("MM_dd_yyyy HH_mm_ss");
	    //get current date time with Date()
	    Date date = new Date();
	    // Now format the date
	    String dateF= dateFormat.format(date);
	    return dateF;
	}

	public static void ExpWait(WebDriver driver, int waitsec,WebElement WebElementWait) 
	{
		WebDriverWait wait = new WebDriverWait(driver,waitsec);
		wait.until(ExpectedConditions.visibilityOf(WebElementWait));
	}
	public boolean WaitForEleInVisibility(WebDriver driver, WebElement ele, long timeOut) 
	{
		boolean found = false;
		try {
		WebDriverWait wait = new WebDriverWait(driver, timeOut);
		WebElement tempEl = wait.until(ExpectedConditions.visibilityOf(ele));

			if (tempEl != null) {
			found = true;
			}
			} catch (Exception e) {
			found = false;
			}
			return found;
	}	
	
	/*public static ArrayList<String> getDataFromExcelByList(String path,String sheetname, int startRow, int endRow)
	{
		int cellCount;
		try {
			fi=new FileInputStream(path);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			wb = WorkbookFactory.create(fi);
		} catch (EncryptedDocumentException e) {
			
			e.printStackTrace();
			Reporter.log("Exception in getDataFromExcelByList");
		} catch (InvalidFormatException e) {
			
			e.printStackTrace();
			Reporter.log("Exception in getDataFromExcelByList");
		} catch (IOException e) {
			
			e.printStackTrace();
			Reporter.log("Exception in getDataFromExcelByList");
		}
		Sheet sh=wb.getSheet(sheetname);
		cellCount =sh.getRow(startRow).getLastCellNum();
		ArrayList<String> list=new ArrayList<String>();
		for (int i = startRow; i <= endRow; i++) 
		{
			//l cellCount =sh.getRow(i).getLastCellNum();
			for (int j = 0; j < cellCount; j++) 
			{
				list.add(sh.getRow(i).getCell(j).getStringCellValue());
			}
		}
		return list;
	}

	public static HashMap<String, String>  getDataFromExcel(String path,String sheetname, int startRow, int endRow)
	{
		HashMap< String, String> hashMap=new HashMap<String, String>();
		//LinkedHashMultimap<String, String> multiMap = LinkedHashMultimap.create();
		
		int cellCount;
		try {
			fi=new FileInputStream(path);
			wb = WorkbookFactory.create(fi);
			Sheet sh=wb.getSheet(sheetname);
			cellCount =sh.getRow(0).getPhysicalNumberOfCells();
			for (int i = startRow; i <= endRow; i++) 
			{
				for (int j = 0; j < cellCount; j++) 
				{
					boolean valueStatus=(sh.getRow(i).getCell(j).getStringCellValue().isEmpty());
					boolean keyStatus=( sh.getRow(0).getCell(j).getStringCellValue().isEmpty());
				if((keyStatus!=true)|| (valueStatus!=true)){
				}
				//multiMap.put(sh.getRow(0).getCell(j).getStringCellValue().toString(), sh.getRow(i).getCell(j).getStringCellValue().toString());
				
				hashMap.put(sh.getRow(0).getCell(j).getStringCellValue().toString(), sh.getRow(i).getCell(j).getStringCellValue().toString());
					
				
				}
			}
			
		} 
		
		catch(NullPointerException exception)
		{
			System.out.println(exception.getMessage());
			Reporter.log("Exception in getDataFromExcel");
		}
		catch (EncryptedDocumentException e) {
	
			System.out.println(e.getMessage());	
			Reporter.log("Exception in getDataFromExcel");
		} catch (InvalidFormatException e) {

			System.out.println(e.getMessage());	
			Reporter.log("Exception in getDataFromExcel");
		}  catch (FileNotFoundException e1) {
			
			System.out.println(e1.getMessage());
			Reporter.log("Exception in getDataFromExcel");
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
			Reporter.log("Exception in getDataFromExcel");
		}
		catch (Exception e) {
		System.out.println(e.getMessage());	
		Reporter.log("Exception in getDataFromExcel");
		}
		return hashMap;
	}	
	*/
	
// To create Evidence Capture document---------------------------------------------------------------------------------------------------
	public String browserCapture(WebDriver driver, String filepath, String filename) throws IOException 
	{	
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		File targetfile = new File((new StringBuilder(String.valueOf(filepath))).append(filename).append(".png").toString());
		try {
			FileUtils.copyFile(scrFile, targetfile);

		} catch (Exception exception) {

		}
		String Fullpath = targetfile.getAbsolutePath();
		String custom[] = Fullpath.split("TC");
		return "TC" + custom[1];
	}
	
	/*public void createOTR(XWPFDocument document, String testcasenumber, String scenariodescription) {
		try {
			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.DOUBLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.DOUBLE);
			paragraph.setBorderLeft(Borders.DOUBLE);
			XWPFRun run = paragraph.createRun();
			run.setBold(true);
			run.setFontSize(16);
			run.setText("Testcase Name: " + testcasenumber);
			// run.setText("Testcase Name : TC_0"+testcasenumber);
			paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.DOUBLE);
			paragraph.setBorderTop(Borders.SINGLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);

			run = paragraph.createRun();
			run.setText("");
			run.setText("");
			run.setText("");
			run.setText("");
			run.setText("");
			run.setText("");
			run.setBold(true);
			run.setFontSize(14);
			run.setText("Scenario Description: " + scenariodescription);
			run.addBreak(BreakType.PAGE);
		} catch (Exception e) {
			e.printStackTrace();
			 Reporter.log("Exception in createOTR");
		}
	}

	public static void captureupdateOTR(WebDriver driver, XWPFDocument document, String scenariodescription) {
		try {

			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.SINGLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);
			XWPFRun run = paragraph.createRun();
			run.setBold(true);
			run.setFontSize(14);
			run.setText(scenariodescription);
			paragraph = document.createParagraph();
			paragraph.setBorderBottom(Borders.DOUBLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.DOUBLE);
			paragraph.setBorderLeft(Borders.DOUBLE);
			paragraph.setAlignment(ParagraphAlignment.LEFT);
			run = paragraph.createRun();
			fis = new FileInputStream(((TakesScreenshot) driver).getScreenshotAs(org.openqa.selenium.OutputType.FILE));
			run.addBreak();
			run.addPicture(fis, Document.PICTURE_TYPE_JPEG, "test", Units.toEMU(470), Units.toEMU(250)); // 200x200
			// pixels
			fis.close();
			run.addBreak(BreakType.PAGE);
		} catch (Exception e) {

			e.printStackTrace();
			Reporter.log("Exception in captureupdateOTR");
		}
	}

	public void updatestatusOTR(XWPFDocument document, String Status) {
		try {
			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.SINGLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);
			XWPFRun run = paragraph.createRun();
			if (Status.equalsIgnoreCase("passed")) {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("008000");
			} else if (Status.equalsIgnoreCase("failed")) {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("ff0000");
			} else {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("87CEFA");
			}
			run.setText("Execution Status : " + Status);

		} catch (Exception e) {

			e.printStackTrace();
			Reporter.log("Exception in updatestatusOTR");
		}
	}

	public void saveOTR(String writefileOTRpath, XWPFDocument document) {
		FileOutputStream out;
		writefileOTRpath = "P:\\Users\\502477910.ADSYF.000\\TMS\\test-output\\OTR\\";
		try {
			out = new FileOutputStream(new File(writefileOTRpath));
			System.out.println("doc write " + writefileOTRpath);
			document.write(out);
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
			Reporter.log("Exception in saveOTR");
		}
	}

	public String getCurrentdate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate localDate = LocalDate.now();
		String todaysdate = dtf.format(localDate);
		return todaysdate;
	}

	public static void ScreenshotToWord(String testcasename,String filepath) throws InvalidFormatException, IOException 
	{		
            XWPFDocument Document = new XWPFDocument();
            XWPFParagraph paragraph = Document.createParagraph();
            paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.SINGLE);
			paragraph.setBorderTop(Borders.SINGLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);
            XWPFRun run = paragraph.createRun();
            run.setBold(true);
			run.setFontSize(14);
            run.setText("Testcase Name: " + testcasename);
            
            File folder = new File("C:\\TMSScreenshots\\"+filepath+"\\PassScreenshots\\");
            System.out.println(folder);
            File[] listOfFiles = folder.listFiles();
            
//            String[] listOfFiles1 = folder.list();
//            System.out.println(listOfFiles1);           		
//            System.out.println(listOfFiles);
            
            for (int i = 0; i < listOfFiles.length; i++) {
              if (listOfFiles[i].isFile()) {
                     String imageFile= listOfFiles[i].getName();
	                 String imgFile = folder+"\\"+imageFile;	     			 
//	                 run.setText("Testcase Name: " + testcasename);	                
	     			 run = paragraph.createRun();
	                 run.addPicture(new FileInputStream(imgFile), org.apache.poi.xwpf.usermodel.Document.PICTURE_TYPE_JPEG, imageFile, Units.toEMU(460), Units.toEMU(250));
	                 run.addBreak();
              }
            }
            FileOutputStream out = new FileOutputStream("C:\\TMSScreenshots\\"+filepath+"\\"+testcasename+".docx");
            Document.write(out);
            out.close();
            Document.close();
	}
	
	public static int getRowCount(String Path, String SheetName) throws InvalidFormatException, IOException{

		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		int rowCount = 0;
		try {
	          rowCount = wbw.getSheet(SheetName).getLastRowNum();
	           rowCount=rowCount+1;
	           
	    } catch (Exception e) {
	           
	           e.printStackTrace();
	    }
	    return rowCount;
	      
	} 
	public static void writeStringValueIntoExcel_CreateRow(String Path, String SheetName, int Row, int Col, String Val) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);
		XSSFRow row=sheet.createRow(Row);
		XSSFCell cell=row.createCell(Col);
		
		cell.setCellValue(Val);
		FileOutputStream fos=new FileOutputStream(Path);
		wbw.write(fos);
		wbw.close();
		fos.close();
	
			}
	public static void writeStringValueIntoExcel_getRow(String Path, String SheetName, int Row, int Col, String Val) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);
		XSSFRow row=sheet.getRow(Row);
		XSSFCell cell=row.createCell(Col);
		cell.setCellValue(Val);
		FileOutputStream fos=new FileOutputStream(Path);
		wbw.write(fos);
		wbw.close();
		fos.close();
	
			}*/
	
}
