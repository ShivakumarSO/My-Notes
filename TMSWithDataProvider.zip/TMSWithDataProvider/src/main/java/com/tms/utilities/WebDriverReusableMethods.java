package com.tms.utilities;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
//import java.awt.datatransfer.DataFlavor;
//import java.awt.datatransfer.UnsupportedFlavorException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.tms.baseclass.*;
import com.tms.utilities.GenericMethods;

public class WebDriverReusableMethods 
{
	/*public static final String USERNAME = "vinaygowda1";
	public static final String AUTOMATE_KEY = "UhEUGCeKe7XGk4LHKdyP";
	public static final String USERNAME_Sauce = "sanjithshetty";
	public static final String AUTOMATE_KEY_Sauce = "09276c40-eecb-4ea2-bd1f-db55e0ccf20a";	public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
	public static final String SuaceURL = "https://" + USERNAME_Sauce + ":" + AUTOMATE_KEY_Sauce + "@ondemand.saucelabs.com:443/wd/hub"; */
 
    public static final String USERNAME = "ShivakumarO"; 
	public static final String ACCESS_KEY = "def695da-97dc-406e-9db1-cca986a08b60";
	public static final String URL = "https://" + "ShivakumarO" + ":" + "def695da-97dc-406e-9db1-caa986a08b60" + "@ondemand.saucelabs.com:443/wd/hub";
    
	public static final String RealDevice_USERNAME = "shivakumaro";
	public static final String RealDevice_ACCESS_KEY = "55A27B19DBE94CADB8D66D4BFFB88731";
	public static final String RealDevice_URL = "https://us1.appium.testobject.com/wd/hub";
	public static final String RealDeviceEu_URL ="https://eu1.appium.testobject.com/wd/hub";
	public static final String TestObject = "https://us1.appium.testobject.com/wd/hub";
	
    static String dateF= GenericMethods.CurrentDateAndTime();
    
	public static WebDriver launchBrowser(String browserName,WebDriver driver) throws IOException
	{		
		if(browserName.equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\Resources\\Drivers\\IEDriverServer.exe");
			driver=new InternetExplorerDriver();
			driver.manage().window().maximize();
		}
		else if(browserName.equalsIgnoreCase("FF"))
		{
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"\\Resources\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();				
			driver.manage().window().maximize();
		}
		else if(browserName.equalsIgnoreCase("ChromeEmulator"))
		{
			  System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Resources\\Drivers\\chromedriver.exe");
			  Map<String, String> mobileEmulation = new HashMap<String, String>();
			  mobileEmulation.put("deviceName", GenericMethods.getProperties("chromeEmulator").toString());
			  ChromeOptions chromeOptions = new ChromeOptions();
			  chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
			  chromeOptions.setExperimentalOption("useAutomationExtension", false);
			  driver =new ChromeDriver(chromeOptions);
		}
		else if(browserName.equalsIgnoreCase("Chrome"))
		{
			  System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Resources\\Drivers\\chromedriver.exe");
			  ChromeOptions chromeOptions = new ChromeOptions();
			  chromeOptions.setExperimentalOption("useAutomationExtension", false);
			  chromeOptions.addArguments("disable-infobars");
			  driver =new ChromeDriver(chromeOptions);		 
			  driver.manage().window().maximize();
		}

		else if (browserName.equalsIgnoreCase("SL_Chrome"))
		{					
/*			System.getProperties().put("https.proxyHost", GenericMethods.getProperties("proxyHost"));
			System.getProperties().put("https.proxyPort", GenericMethods.getProperties("proxyPort"));
			System.getProperties().put("https.proxyUser", GenericMethods.getProperties("proxyUser"));
			System.getProperties().put("https.proxyPassword", GenericMethods.getProperties("proxyPassword"));
			System.getProperties().put("https.proxyHost", "dalladcusrproxy.gdn.syfbank.com");
			System.getProperties().put("https.proxyPort", "8080");
			System.getProperties().put("https.proxyUser", "502484280");//user "SSO id
			System.getProperties().put("https.proxyPassword","A@44@word");*/
			System.getProperties().put("https.proxyHost", "dalladcusrproxy.gdn.syfbank.com");
			System.getProperties().put("https.proxyPort", "8080");
			System.getProperties().put("https.proxyUser", "ShivakumarO");
			System.getProperties().put("https.proxyPassword","P@55word");
			
//			DesiredCapabilities caps = DesiredCapabilities.chrome();
//			caps.setCapability("platform", "Windows 7");
//			caps.setCapability("version", "68.0");
//			driver = new RemoteWebDriver(new URL(URL), caps);
/*			DesiredCapabilities caps = DesiredCapabilities.safari();
	        caps.setCapability("platform", "macOS 10.13");
	        caps.setCapability("version", "11.1");
			caps.setCapability("testobject_suite_name", "DigitalBuy");
			caps.setCapability("testobject_test_name", "DigitalBuy");
			//caps.setCapability("tunnelIdentifier", "Tunnel1");
			driver = new RemoteWebDriver(new URL("https://" + "ShivakumarO" + ":" +
			"def695da-97dc-406e-9db1-caa986a08b60" + "@ondemand.saucelabs.com:443/wd/hub"), caps); */
			
			/*DesiredCapabilities caps = DesiredCapabilities.iphone();
			caps.setCapability("appiumVersion", "1.9.1");
			caps.setCapability("deviceName","iPhone 8 Plus Simulator");
			caps.setCapability("deviceOrientation", "portrait");
			caps.setCapability("platformVersion","11.3");
			caps.setCapability("platformName", "iOS");
			caps.setCapability("browserName", "Safari");
			driver = new RemoteWebDriver(new URL("https://" + "ShivakumarO" + ":" + "def695da-97dc-406e-9db1-caa986a08b60" + "@ondemand.saucelabs.com:443/wd/hub"), caps);
		    */
/*			DesiredCapabilities caps = DesiredCapabilities.iphone();
			DesiredCapabilities caps = new DesiredCapabilities(); 
			caps.setCapability("testobject_api_key", "64C0A40A6CA94801947EDC6F5D3D18C7");
			caps.setCapability("appiumVersion", "1.9.1");
			caps.setCapability("deviceName","iPhone 7");
			caps.setCapability("deviceOrientation", "portrait");
			caps.setCapability("platformVersion","10.3.2");
			caps.setCapability("platformName", "iOS");
			caps.setCapability("browserName", "Safari"); 
			caps.setCapability("privateDevicesOnly",false);
	        caps.setCapability("testobject_app_id", "1");
	        caps.setCapability("testobject_suite_name","cmlb2b");
			driver = new RemoteWebDriver(new URL(RealDevice_URL), caps); */
	          }
		else if(browserName.equalsIgnoreCase("BS"))
		{
			System.out.println("Browserstack");
			System.getProperties().put("https.proxyHost", GenericMethods.getProperties("proxyHost"));
			System.getProperties().put("https.proxyPort", GenericMethods.getProperties("proxyPort"));
			System.getProperties().put("https.proxyUser", GenericMethods.getProperties("proxyUser"));
			System.getProperties().put("https.proxyPassword", GenericMethods.getProperties("proxyPassword"));
			DesiredCapabilities caps = new DesiredCapabilities();
			caps.setCapability("os_version", "7.0");
			caps.setCapability("device", "Samsung Galaxy S8");
			caps.setCapability("real_mobile", "true");
			caps.setCapability("browserstack.local", "false");
		    driver = new RemoteWebDriver(new URL(URL), caps); 		    
		}
		else if(browserName.equalsIgnoreCase("SauceLabs"))
		{		
			System.getProperties().put("https.proxyHost", GenericMethods.getProperties("proxyHost"));
			System.getProperties().put("https.proxyPort", GenericMethods.getProperties("proxyPort"));
			System.getProperties().put("https.proxyUser", GenericMethods.getProperties("proxyUser"));
			System.getProperties().put("https.proxyPassword", GenericMethods.getProperties("proxyPassword"));
	        System.out.println("SauceLabs");
	        
	      /*  DesiredCapabilities caps = DesiredCapabilities.safari();
	        caps.setCapability("platform", "macOS 10.13");
	        caps.setCapability("version", "11.1");
			caps.setCapability("testobject_suite_name", "DigitalBuy");
			caps.setCapability("testobject_test_name", "DigitalBuy");
			//caps.setCapability("tunnelIdentifier", "Tunnel1");
			driver = new RemoteWebDriver(new URL("https://" + "ShivakumarO" + ":" +
			"def695da-97dc-406e-9db1-caa986a08b60" + "@ondemand.saucelabs.com:443/wd/hub"), caps);*/
			
/*			DesiredCapabilities caps = DesiredCapabilities.iphone();
			caps.setCapability("appiumVersion", "1.9.1");
			caps.setCapability("deviceName","iPhone 8 Plus Simulator");
			caps.setCapability("deviceOrientation", "portrait");
			caps.setCapability("platformVersion","11.3");
			caps.setCapability("platformName", "iOS");
			caps.setCapability("browserName", "Safari");
			driver = new RemoteWebDriver(new URL("https://" + "ShivakumarO" + ":" + "def695da-97dc-406e-9db1-caa986a08b60" + "@ondemand.saucelabs.com:443/wd/hub"), caps);*/
        }
		else if(browserName.equalsIgnoreCase("TO"))
		{			
        	System.getProperties().put("https.proxyHost", GenericMethods.getProperties("proxyHost"));
			System.getProperties().put("https.proxyPort", GenericMethods.getProperties("proxyPort"));
			System.getProperties().put("https.proxyUser", GenericMethods.getProperties("proxyUser"));
			System.getProperties().put("https.proxyPassword", GenericMethods.getProperties("proxyPassword"));
	        System.out.println("TestObject");
            System.out.println(TestObject);
            DesiredCapabilities caps = new DesiredCapabilities();
            caps.setCapability("testobject_api_key", "715ACA89B27E43C9AE21B71E8634D5B6");
            caps.setCapability("platformName", GenericMethods.getProperties("platformName"));
            caps.setCapability("platformVersion", GenericMethods.getProperties("platformVersion"));
            caps.setCapability("deviceName", GenericMethods.getProperties("deviceName"));
            caps.setCapability("privateDevicesOnly", GenericMethods.getProperties("privateDevicesOnly"));
            caps.setCapability("testobject_app_id", GenericMethods.getProperties("testobject_app_id"));
            caps.setCapability("appiumVersion", GenericMethods.getProperties("appiumVersion"));
            caps.setCapability("name",BaseClass.methodName+"_"+ dateF);
            driver = new RemoteWebDriver(new URL(TestObject),caps);           
        }
		else if(browserName.equalsIgnoreCase("Android")){
			System.getProperties().put("https.proxyHost", GenericMethods.getProperties("proxyHost"));
			System.getProperties().put("https.proxyPort", GenericMethods.getProperties("proxyPort"));
			System.getProperties().put("https.proxyUser", GenericMethods.getProperties("proxyUser"));
			System.getProperties().put("https.proxyPassword", GenericMethods.getProperties("proxyPassword"));
			DesiredCapabilities caps = new DesiredCapabilities();
			
			caps.setCapability("testobject_api_key", "55A27B19DBE94CADB8D66D4BFFB88731");
			caps.setCapability("platformName", "Android");
			caps.setCapability("platformVersion", "9");
			caps.setCapability("deviceName", "Google Pixel 2");
			caps.setCapability("privateDevicesOnly", false);
			caps.setCapability("testobject_app_id", "1");
			caps.setCapability("testobject_suite_name", "DigitalBuy");
			caps.setCapability("testobject_test_name", "DigitalBuy");
			caps.setCapability("appiumVersion", "1.8.1");
			driver = new RemoteWebDriver(new URL(TestObject), caps);
			//System.out.println(DBuyShippingPage.methodName);
	       }	          
		System.out.println(driver);
		return driver;
	}
	
	public static String getScreenshot(WebDriver driver,String TestCaseName,int status,int stepNo) 
	{
		File src;
		String state;
		String ssPath="";
		try{
			if(status==1){
				state="PassScreenshots";
			}else if(status==0){
				state="FailedScreenshots";
			}else{
				state="SkippedScreenshots";
			}			
			ssPath="C:\\TMSScreenshots\\"+TestCaseName+"\\"+state+"\\"+System.currentTimeMillis()+"_step_" + stepNo +".png";
			src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(ssPath));  
			return ssPath;
		  } 
		
	   catch (IOException e)
		{
		   	System.out.println(e.getMessage());
   		  	return ssPath;
		 }
	}
	
	/*public static void moveToElement(WebDriver driver)
	{
		Actions act=new Actions(driver);
		act.moveByOffset(120, 150);
		act.click();
	}*/
	
	public static void alertAccept(WebDriver driver) 
	{
		try {
			Alert alert=driver.switchTo().alert();
			alert.accept();
			} 
		catch (Exception e) {
			e.printStackTrace();
			}	
	}
	
	public static void alertDismiss(WebDriver driver) 
	{
		try {
		Alert alert=driver.switchTo().alert();
		alert.dismiss();
			} 
		catch (Exception e) 
		{
		e.printStackTrace();
		}
	}
	
	public static String alertGetText(WebDriver driver) 
	{
	String text=null;
		try {
			Alert alert=driver.switchTo().alert();
			text=alert.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
	return text;
	
	}
	
	public static void elementToBeClickable(WebDriver driver, WebElement element) {
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.elementToBeClickable(element));	
	}
	
	public static void presenceOfEleLocated(WebDriver driver, By element) {
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.presenceOfElementLocated(element));	
	}
	
	public static void frameToBeAvailableLocator(WebDriver driver, By locator) {
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(locator));	
	}
	
	public static void frameToBeAvailableElement(WebDriver driver, WebElement element) {
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(element));	
	}
	
	public static boolean isDisplayed(WebElement ele){
		return ele.isDisplayed();
	}
	
	public static void click(WebElement ele){
		ele.click();
	}
	
	public static void submit(WebElement ele){
		ele.submit();
	}
	
	public static void sendkeys(WebElement ele, String str){
		ele.sendKeys(str);
	}
	
	public static void selecDropDown(WebElement element, int ind)
	{
		Select select=new Select(element);
		select.selectByIndex(ind);
	}
	
	public static void selecDropDown(WebElement element, String visibleText)
	{
		Select select=new Select(element);
		select.deselectByValue(visibleText);;
	}
	
	public static void selecDropDown(WebElement element, String val,String visibleText)
	{
		if(visibleText.equalsIgnoreCase("value")){
			Select select=new Select(element);
			select.selectByValue(val);
		}else{
			Select select=new Select(element);
			select.selectByVisibleText(val);
		}
	}
	
	public static String getText(WebElement ele)
	{
		String eleText=ele.getText();
		return eleText;
	}
	
	public static void implicitWait(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	public static void scrollDown(WebDriver driver, String value){
		((JavascriptExecutor)driver).executeScript(value);
	}
	
	public static void navigateUrl(WebDriver driver, String url)
	{
		driver.get(url);
	}
	
	public static void sendkeysByJs(WebDriver driver,String Id, String value1){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("document.getElementById(\'"+Id+"\').value=\'"+value1+"\'");
	}
		
	public static void pageScroll(WebDriver driver, WebElement Element){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();",Element );
	}
	
	public static   String getToken(WebDriver driver, WebElement Element)
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;		
		js.executeScript("return document.getElementById('tokenId').value");
		return  js.executeScript("return document.getElementById('tokenId').value").toString();
		
		//String TokenID = .toString();
	
		//return (String) js.executeScript("return document.getElementById('tokenID').value;");
	}
	
	public static void clickByJs(WebDriver driver,String Id){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("document.getElementById(\'"+Id+"\')"+".click()");
	}
	
	public static void clickByXPath(WebDriver driver,String xPath){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		System.out.println("document.querySelector(\'" + xPath + "\').click()");
		js.executeScript("document.querySelector(\'" + xPath + "\').click()");
	}
}
