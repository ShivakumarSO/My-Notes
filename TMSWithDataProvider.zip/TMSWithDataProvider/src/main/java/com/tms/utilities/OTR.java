package com.tms.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.Borders;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;
import com.tms.baseclass.BaseClass;

public class OTR extends BaseClass{
	static XWPFDocument document;
	GenericMethods genericmethods = new GenericMethods();
	static FileInputStream fis = null;
	static String workingpath = System.getProperty("user.dir");
	/*static SimpleDateFormat df = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
	static Date today = Calendar.getInstance().getTime();
	static String  reportDate = df.format(today);*/
	

	public static void createOTR(String testcasenumber) {
		try {
			document = new XWPFDocument();
			XWPFParagraph paragraph=null;
			//document=null;		
			paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.DOUBLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.DOUBLE);
			paragraph.setBorderLeft(Borders.DOUBLE);
			XWPFRun run = paragraph.createRun();
			run.setBold(true);
			run.setFontSize(14);
			run.setText("Testcase Name: " + testcasenumber);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

/*	public static void captureupdateOTR(WebDriver driver, String scenariodescription, String status, int stepNo,String filepath) {
		try {
			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.SINGLE);
			paragraph.setBorderTop(Borders.SINGLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);
			XWPFRun run = paragraph.createRun();
			run.setBold(true);
			run.setFontSize(14);
			run.setText(scenariodescription);
			run.setText(status);
			paragraph = document.createParagraph();
			paragraph.setBorderBottom(Borders.SINGLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);
			paragraph.setAlignment(ParagraphAlignment.LEFT);
			run = paragraph.createRun();

			File src;
			String state;
			String ssPath = "";
			if (status == " Pass") {
				state = "PassScreenshots";
			} else if (status == " Fail") {
				state = "FailedScreenshots";
			} else {
				state = "SkippedScreenshots";
			}
			ssPath = "C:\\DBuyScreenshots\\" +filepath+ "\\" + state + "\\" + System.currentTimeMillis()+ "_step_" + stepNo + ".png";
			src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(ssPath));

			FileInputStream fis = new FileInputStream(src);
			run.addBreak();
			run.addPicture(fis, Document.PICTURE_TYPE_JPEG, "test", Units.toEMU(465), Units.toEMU(250)); // 200x200
			fis.close();
			//run.addBreak(BreakType.PAGE);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}*/
	
	public static void updatestatusOTR(String Status) {
		try {
			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.SINGLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);
			XWPFRun run = paragraph.createRun();
			if (Status.equalsIgnoreCase("passed")) {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("008000");
			} else if (Status.equalsIgnoreCase("failed")) {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("ff0000");
			} else {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("87CEFA");
			}
			run.setText("Execution Status : " + Status);

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

/*	public static void saveOTR1(String screenshotFolder, String methodName) throws IOException 
	{
		String writefileOTRpath = "C:\\DBuyScreenshots\\" + screenshotFolder + "\\" + methodName + ".docx";
		System.out.println(writefileOTRpath);
		FileOutputStream out;
		try {
			out = new FileOutputStream(new File(writefileOTRpath));
			System.out.println("doc write " + writefileOTRpath);
			document.write(out);
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/
		
	public static void saveOTR(String testcaseName) throws IOException {
        FileOutputStream out=null;
        String writefileOTRpath = workingpath +"/test-output/OTR/OTR_"+reportDate+"/" + testcaseName + ".docx";
        try {
               out = new FileOutputStream(new File(writefileOTRpath));
               System.out.println("doc write " + writefileOTRpath);
               document.write(out);              
               document.close();
               out.flush();
               out.close();              
	        } catch (IOException e) {
	               e.printStackTrace();
	        }
	}
	
	public static void addscreenlogupdateOTR(WebDriver driver, String teststep, String status ) {

        File src;
        String state;
        String ssPath = "";
        
        try {
               if (status == "Pass") {
                     state = "PassedScreenshots";
               } else if (status == "Fail") {
                     state = "FailedScreenshots";
               } else {
                     state = "SkippedScreenshots";
               }
               ssPath = workingpath + screenshotFolder + "\\" + state + "\\" + System.currentTimeMillis() + "_step_" + stepNum++ + ".png";
               //System.out.println(ssPath);
               src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
               //System.out.println(ssPath);
              // System.out.println(src);
             FileUtils.copyFile(src, new File(ssPath));
               
               XWPFParagraph paragraph = document.createParagraph();
               paragraph.setAlignment(ParagraphAlignment.CENTER);
               paragraph.setBorderBottom(Borders.SINGLE);
               paragraph.setBorderTop(Borders.DOUBLE);
               paragraph.setBorderRight(Borders.SINGLE);
               paragraph.setBorderLeft(Borders.SINGLE);
               XWPFRun run = paragraph.createRun();
               run.setBold(true);
               run.setFontSize(14);
               run.setText(teststep);
               paragraph = document.createParagraph();
               paragraph.setAlignment(ParagraphAlignment.CENTER);
               paragraph.setBorderBottom(Borders.DOUBLE);
               paragraph.setBorderTop(Borders.DOUBLE);
               paragraph.setBorderRight(Borders.DOUBLE);
               paragraph.setBorderLeft(Borders.DOUBLE);
               // paragraph.setAlignment(ParagraphAlignment.LEFT);
               run = paragraph.createRun();
               run.setBold(true);
               run.setFontSize(14);
               if (status == "Fail") {
                     run.setColor("ff0000");
               }
               run.setText(status);

               paragraph = document.createParagraph();
               paragraph.setBorderBottom(Borders.DOUBLE);
               paragraph.setBorderTop(Borders.DOUBLE);
               paragraph.setBorderRight(Borders.DOUBLE);
               paragraph.setBorderLeft(Borders.DOUBLE);
               paragraph.setAlignment(ParagraphAlignment.LEFT);
               run = paragraph.createRun();
               fis = new FileInputStream(ssPath);
               run.addBreak();
               run.addPicture(fis, Document.PICTURE_TYPE_JPEG, "test", Units.toEMU(470), Units.toEMU(250));
               // pixels
               fis.close();
               run.addBreak(BreakType.PAGE);
               if (status == "Pass") {
                    logger.log(LogStatus.PASS, teststep + logger.addScreenCapture(ssPath));
               } else if (status == "Fail") {
                     logger.log(LogStatus.FAIL, teststep + logger.addScreenCapture(ssPath));
               }
               // OTR.captureupdateOTR(driver, teststep, status);

        } catch (IOException e) {
               System.out.println(e.getMessage());
        } catch (Exception e) {
               e.printStackTrace();
        }
 }	
			
	public static void sendEmail() throws IOException 
	{
		Runtime.getRuntime().exec("wscript H:\\Workspace\\DBuyConsumer\\Resources\\Drivers\\SendMail.vbs");
	}
}

