package com.tms.baseclass;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
//import org.openqa.selenium.remote.Augmenter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.tms.pages.TMSApplyPage;
import com.tms.pages.TMSHomePage;
import com.tms.pages.TMSLookupPage;
import com.tms.pages.TMSPurchasePage;
import com.tms.pages.TMSQuickScreenPage;
import com.tms.pages.TMSRefundPage;
import com.tms.pages.TMSSimulatorPage;
import com.tms.utilities.GenericMethods;
import com.tms.utilities.OTR;
import com.tms.utilities.Log;
import com.tms.utilities.WebDriverReusableMethods;
import com.google.common.collect.LinkedHashMultimap;
import com.tms.utilities.ExcelUtility;
import com.tms.utilities.HtmlReport;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.javafx.collections.MappingChange.Map;

public class BaseClass {
//	WebDriver augmentedDriver = new Augmenter().augment(driver);
	public static WebDriver driver;
	public static WebDriver backupDriver;
   // public static XWPFDocument document;
	public ExtentReports extentReport;
	public static ExtentTest logger;
	public  GenericMethods gen;
	public  TMSSimulatorPage simulatorPage;
	public  TMSApplyPage applyPage;
	public  TMSHomePage homePage;
	public  TMSLookupPage lookupPage;
	public  TMSPurchasePage purchasePage;
	public  TMSQuickScreenPage qsPage;
	public  WebDriverReusableMethods reusableMethods;
	public  TMSRefundPage refundPage;
	public  TMSSimulatorPage tmsSimulator;
	public static int stepNum;
	public static  String browser;
	public static String methodName;
	public static String screenshotFolder;
	public  GenericMethods genMethods;
	public Robot robot;
	String PropFilePath;
	String excFilepath;
	public static String screenshotPath;
	public  static HashMap<String, String> testdataHashMap;
	public static String OTRpath;
	public static String LogFilepath;
	public static File Logpath;
	Log log;
	public static XWPFDocument document;
    public String sStatus; 
    public static void setDocument(XWPFDocument document) {
        BaseClass.document = new XWPFDocument();
    }
    public static String ExcelLocation;
    public static String OTRLocation;
    public static String TestCaseName;
    public static String TestMethodName;
    public static String TestNGReportspath;
    public static String FailedReason;
    public static int TestCaseNumber=1;
    public static String TCName;
    static SimpleDateFormat df = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
    static Date today;
    protected static String reportDate;
	
	@BeforeClass
	public static void setup() throws InvalidFormatException, IOException,Exception {
		try {
		 String workingpath = System.getProperty("user.dir");
	     
	     String excelpath = workingpath + "/test-output/ExcelOutput/Detailed_Execution_status.xlsx";

	     today = Calendar.getInstance().getTime();
	     reportDate = df.format(today);
	     File dir = new File(workingpath+"/test-output/ExcelOutput/Detailed_Execution_"+reportDate+"/");
	     dir.mkdir();
	     dir = new File(workingpath+ "/test-output/Logs/Logs_"+ reportDate + "/");
	     dir.mkdir();
	     dir = new File(workingpath+"/test-output/OTR/OTR_"+reportDate+"/");
	     dir.mkdir();
	     OTRLocation =workingpath+"/test-output/OTR/OTR_"+reportDate+"/";
	     ExcelLocation = workingpath+"/test-output/ExcelOutput/Detailed_Execution_"+reportDate+"//Detailed_Execution_status.xlsx";
	     TestNGReportspath = workingpath+"/test-output/ExcelOutput/Detailed_Execution_Testng_"+reportDate+"/";
	     LogFilepath =workingpath+"/test-output/Logs/Logs_"+reportDate+"/logfile.log";
	     Logpath = new File(LogFilepath);
	     System.out.println(Logpath);
	     System.setProperty("Logpath", LogFilepath);
	     File srcexcelFile = new File(excelpath);
	     File oexeclFile= new File(ExcelLocation);
	     FileUtils.copyFile(srcexcelFile,oexeclFile);
	    	 }
	  catch (IOException e) {

	        e.printStackTrace();
	        Log.info("Initial file setup failed.");
			Assert.fail("Failed to intiate Driver.");
	     }
	}
	@BeforeTest
	public void beforeSuite() throws MalformedURLException, IOException 
	{
		System.getProperties().put("https.proxyHost", "dalladcusrproxy.gdn.syfbank.com");
		System.getProperties().put("https.proxyPort", "8080");
	  	System.getProperties().put("https.proxyUser", "502487808");
	  	System.getProperties().put("https.proxyPassword","S@17word");
	  	PropFilePath = System.getProperty("user.dir") + "\\Resources\\TestData\\property.properties";
	  	Log.info("Got property file...");
	}
	@BeforeMethod
	public void instantiate(Method method) throws MalformedURLException, IOException 
	{		
		try {
			browser="";
			stepNum=1;
			methodName="";
			screenshotPath="";
			screenshotFolder="";
			OTRpath="";
			genMethods =new GenericMethods();
			String dateF = GenericMethods.CurrentDateAndTime();
			extentReport = new ExtentReports(System.getProperty("user.dir") + "\\Reports\\"+ method.getName()+"_"+dateF+".html", false);
			System.out.println(extentReport);
			extentReport.loadConfig(new File(System.getProperty("user.dir") + "\\extent-config.xml"));
			logger = extentReport.startTest(method.getName());
			System.out.println(logger);
			TestCaseName=method.getName();
		} catch(Exception e) {
			e.printStackTrace();
			Log.info("Failed to instantiate.");
		}
	}
	protected void StartPage(String testcaseName, String client, String browser, String url) {
		
		reusableMethods=new WebDriverReusableMethods();
		try 
		{
		driver = WebDriverReusableMethods.launchBrowser(browser, driver);
		} catch (IOException e) {
		e.printStackTrace();
		Assert.fail("Failed to intiate Driver.");
		//Log.error("Initial file setup failed.");
		}
		logger.log(LogStatus.PASS, browser + " Browser Lanuched");
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		WebDriverReusableMethods.implicitWait(driver); 
		//OTR.createOTR(testdataHashMap.get("TestCaseName"));
		methodName = testcaseName;
		//System.out.println("methodName : "+methodName);
		OTR.createOTR(methodName);
		screenshotFolder = client + "\\" + methodName + "_" + GenericMethods.CurrentDateAndTime();
		System.out.println("screenshotFolder: "+screenshotFolder);
		OTRpath = screenshotFolder;
		System.out.println("OTRpath: "+OTRpath);
		System.out.println("Started executing---->" + methodName); 
	    Log.info("Started executing---->" + methodName);
		driver.navigate().to(url);
		}
	
	@AfterMethod
	public void afterMethod(ITestResult result){
		//System.out.println("Testing");
		report(result);
		try{
			extentReport.endTest(logger);
			extentReport.flush();
			extentReport.close();
			driver.quit();	
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Log.info("Failed to quit driver.");
			Assert.fail("Failed toquit driver.");
		}
	}
	
	@AfterClass	
	public void tearDown() throws IOException {		
		//OTR.sendEmail();
		try
		{
			/*extentReport.endTest(logger);
			extentReport.flush();
			extentReport.close();*/
			driver.quit();
		}
		catch (Exception e) {
			
			e.printStackTrace();
			Log.info("Failed to quit driver.");
			Assert.fail("Failed to quit driver.");
		}
	}
	
	
	
	public void report(ITestResult result){
		String workingpath = System.getProperty("user.dir");
	     SimpleDateFormat df = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
	     Date today;
	     String reportDate;
	     HtmlReport hr = new HtmlReport(); 
	     String sStatChk = "";
	     //String OTRPath = "C:\\TMSScreenshots\\"+ OTRpath + "\\" + TestCaseName + ".docx";
		try{
	     String excelpath = workingpath + "/test-output/ExcelOutput/Detailed_Execution_status.xlsx";
	     genMethods = new GenericMethods();
	     // write a logic to implement error screenshot to otr file
	     today = Calendar.getInstance().getTime();
	     String reportdate;
	     reportdate = df.format(today);
	         if(result.getStatus() == ITestResult.SUCCESS) {
	        	 //GenericUtilities.captureupdateOTR(driver, document, "Passed Screen capture");
	        	 sStatChk = "Passed";
	        	 
	        	 Log.endTestCase(TestCaseName);
	         }else if(result.getStatus() == ITestResult.FAILURE){
	        	 //GenericMethods.captureupdateOTR(driver, document, "Failed Screen capture");
	        	 sStatChk = "Failed";
	        	 FailedReason = result.getThrowable().getMessage();
	        	 Log.endTestCase(TestCaseName);
	         }else {
	             sStatChk = "Skipped";
	             Log.endTestCase(TestCaseName);
	         }
	     
	   /*  gu.updatestatusOTR(document,sStatChk);
	     OTRPath = OTRLocation+TestCaseName+reportdate+".docx";
	     gu.saveOTR(OTRPath,document);*/
		 }catch(Exception e){
			e.printStackTrace();
			Log.info("Failed to create report.");
			Assert.fail("Failed to create report.");
			 
		 }
	     int Count;
	     try{
	         Count = ExcelUtility.getRowCount(ExcelLocation,"Detailed");
	     }catch(Exception e){
	         Count = 0;
	     }
	     try{
	        // ExcelUtility.writeStringValueIntoExcel_CreateRow(ExcelLocation,"Detailed",Count,0,TCName);
	         ExcelUtility.writeStringValueIntoExcel_getRow(ExcelLocation,"Detailed",Count,0,TestCaseName);
	         ExcelUtility.writeStringValueIntoExcel_getRow(ExcelLocation,"Detailed",Count,1,OTRpath);
	         ExcelUtility.writeStringValueIntoExcel_getRow(ExcelLocation,"Detailed",Count,2,sStatChk);
	         ExcelUtility.writeStringValueIntoExcel_getRow(ExcelLocation,"Detailed",Count,3,FailedReason);
	         FailedReason="";
	         TCName="";
	     }catch (Exception e){
	    	Log.info("Failed to create excel report.");
	    	e.printStackTrace();
			Assert.fail("Failed to create execel report.");
			
	     }
	     String sheetname = "Detailed";
	     String htmlpath = ExcelLocation;
	     hr.converttohtml(htmlpath,sheetname);
	}
	
}



