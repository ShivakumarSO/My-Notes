package com.tms.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.tms.baseclass.BaseClass;
import com.tms.pages.TMSApplyPage;
import com.tms.pages.TMSHomePage;
import com.tms.pages.TMSLookupPage;
import com.tms.pages.TMSPurchasePage;
import com.tms.pages.TMSRefundPage;
import com.tms.pages.TMSSimulatorPage;
import com.tms.utilities.GenericMethods;
import com.tms.utilities.Log;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;
import com.relevantcodes.extentreports.LogStatus;

public class TMSPurchaseTest extends BaseClass{

	@Test(enabled=true, groups = {"Regression"}, dataProvider="PurchaseDataProvider")
	public void TMSApprovedPurchaseTransactionForPLCCCard_TC001(Map<Object,Object> map) throws IOException {		
		try
		{	
			String statusFlag=map.get("StatusFlag").toString();
			String testcaseName=map.get("TestCaseName").toString();
			String client=map.get("Client").toString();
			String browser=map.get("Browser").toString();
			String url=map.get("URL").toString();
			String purchaseAmount=map.get("PurchaseAmount").toString();
			String ssn=map.get("SSN").toString();
			String zipCode=map.get("ZipCode").toString();
			String issuingState=map.get("IssuingState").toString();
			String expiryDate=map.get("ExpiryDate").toString();
			String practiceMemo=map.get("PracticeMemo").toString();
		
			
			if (statusFlag.equalsIgnoreCase("Y")) 	
			{
				StartPage(testcaseName, client, browser, url);	
				simulatorPage= new TMSSimulatorPage(driver);
				homePage = new TMSHomePage(driver);
				purchasePage = new TMSPurchasePage(driver);
				Log.startTestCase(testcaseName);
				
				simulatorPage.tMSSimulatorForm1(testcaseName);
				simulatorPage.prefillServiceRequestDefaultData(testcaseName);
				homePage.homePagePurchase(testcaseName);
				purchasePage.purchaseLookupAccountBySSNandZip(testcaseName, purchaseAmount, ssn, zipCode);
				purchasePage.purchaseIdAndFinancing(testcaseName, issuingState, expiryDate, practiceMemo);
				purchasePage.purchaseComplete(testcaseName);
				
			}			
			OTR.saveOTR(testcaseName);
			} 
		catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				e.printStackTrace();
				driver.quit();
			}
	}
	
	@Test(enabled=true, groups = {"Regression"}, dataProvider="PurchaseDataProvider")
	public void TMSApprovedPurchaseTransactionForDCCard_TC002(Map<Object,Object> map) throws IOException {		
		try
		{	
			String statusFlag=map.get("StatusFlag").toString();
			String testcaseName=map.get("TestCaseName").toString();
			String client=map.get("Client").toString();
			String browser=map.get("Browser").toString();
			String url=map.get("URL").toString();
			String purchaseAmount=map.get("PurchaseAmount").toString();
			String ssn=map.get("SSN").toString();
			String zipCode=map.get("ZipCode").toString();
			String issuingState=map.get("IssuingState").toString();
			String expiryDate=map.get("ExpiryDate").toString();
			String practiceMemo=map.get("PracticeMemo").toString();
	
			
			if (statusFlag.equalsIgnoreCase("Y")) 	
			{
				StartPage(testcaseName, client, browser, url);	
				simulatorPage= new TMSSimulatorPage(driver);
				homePage = new TMSHomePage(driver);
				purchasePage = new TMSPurchasePage(driver);
				Log.startTestCase(testcaseName);
				
				simulatorPage.tMSSimulatorForm1(testcaseName);
				simulatorPage.prefillServiceRequestDefaultData(testcaseName);
				homePage.homePagePurchase(testcaseName);
				purchasePage.purchaseLookupAccountBySSNandZip(testcaseName, purchaseAmount, ssn, zipCode);
				purchasePage.purchaseIdAndFinancing(testcaseName, issuingState, expiryDate, practiceMemo);
				purchasePage.purchaseComplete(testcaseName);
				
			}			
			OTR.saveOTR(testcaseName);
			} 
		catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				driver.quit();
			}
	}
	
	@DataProvider(name="PurchaseDataProvider")
    public static Object[][] ApplyDataProvider(Method m) {
        Object[][] Data = null;
        String testCase=m.getName();
        try {
            FileInputStream file = new FileInputStream(GenericMethods.getProperties("ExcelDataPath"));

            //Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook = new XSSFWorkbook(file);

            //Get first/desired sheet from the workbook
            XSSFSheet sheet = workbook.getSheet("Purchase");

            int lastRowNum = sheet.getLastRowNum();
            int lastCellNum = sheet.getRow(0).getLastCellNum();
            ArrayList<Object> executableDataRows = new ArrayList<Object>();

            for (int i = 0; i < lastRowNum; i++) {
                if(sheet.getRow(i + 1).getCell(1).toString().equals(testCase)&&sheet.getRow(i + 1).getCell(2).toString().equals("Y") ) {
                    Map<Object, Object> datamap = new HashMap<>();
                    for (int j = 0; j < lastCellNum; j++) {
                        datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i + 1).getCell(j).toString());
                    }
                    executableDataRows.add(datamap);
                }
            }

            Data = new Object[executableDataRows.size()][1];
          //  Iterator iterable = executableDataRows.iterator();

            for(int i=0; i<executableDataRows.size();i++){
				Data[i][0]=executableDataRows.get(i);
                //Data[i][0] = iterable.next();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Data;
    }
	
}
