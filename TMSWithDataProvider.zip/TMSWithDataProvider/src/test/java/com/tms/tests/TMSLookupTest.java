package com.tms.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.tms.baseclass.BaseClass;
import com.tms.pages.TMSApplyPage;
import com.tms.pages.TMSHomePage;
import com.tms.pages.TMSLookupPage;
import com.tms.pages.TMSPurchasePage;
import com.tms.pages.TMSRefundPage;
import com.tms.pages.TMSSimulatorPage;
import com.tms.utilities.GenericMethods;
import com.tms.utilities.Log;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;
import com.relevantcodes.extentreports.LogStatus;

public class TMSLookupTest extends BaseClass{

	
	@Test(enabled=false, groups = {"Regression"}, dataProvider="LookupDataProvider")
	public void TMSLookupByPLCCAccountNumber_TC001(Map<Object,Object> map) throws IOException {		
		try
		{	
			String statusFlag=map.get("StatusFlag").toString();
			String testcaseName=map.get("TestCaseName").toString();
			String client=map.get("Client").toString();
			String browser=map.get("Browser").toString();
			String url=map.get("URL").toString();
			String accountNumber=map.get("AccountNumber").toString();
			/*String refundAmount=map.get("RefundAmount").toString();
			String clientFirstName=map.get("ClientFirstName").toString();
			String clientLastName=map.get("ClientLastName").toString();
			String clientHomePhone=map.get("ClientHomePhone").toString();
			String ssn=map.get("SSN").toString();
			String zipCode=map.get("ZipCode").toString();
			String issuingState=map.get("IssuingState").toString();
			String expiryDate=map.get("ExpiryDate").toString();
			String practiceMemo=map.get("PracticeMemo").toString();*/
			Log.startTestCase(testcaseName);					
							
			if (statusFlag.equalsIgnoreCase("Y")) 	
			{
				StartPage(testcaseName, client, browser, url);	
				simulatorPage= new TMSSimulatorPage(driver);
				homePage = new TMSHomePage(driver);
				lookupPage = new TMSLookupPage(driver);
					
				simulatorPage.tMSSimulatorForm1(testcaseName);
				simulatorPage.prefillServiceRequestDefaultData(testcaseName);
				homePage.homePageLookup(testcaseName);
				lookupPage.lookupAccountByAccountNumber(testcaseName, accountNumber);
				lookupPage.lookupAccount(testcaseName);
							
			}			
			OTR.saveOTR(testcaseName);
			} 
		catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				driver.quit();
			}
	}
	
	@Test(enabled=false, groups = {"Regression"}, dataProvider="LookupDataProvider")
	public void TMSLookupBySSNAndZipForPLCCAccountNumber_TC002(Map<Object,Object> map) throws IOException {		
		try
		{	
			String statusFlag=map.get("StatusFlag").toString();
			String testcaseName=map.get("TestCaseName").toString();
			String client=map.get("Client").toString();
			String browser=map.get("Browser").toString();
			String url=map.get("URL").toString();
			String ssn=map.get("SSN").toString();
			String zipCode=map.get("ZipCode").toString();
			String issuingState=map.get("IssuingState").toString();
			String expiryDate=map.get("ExpiryDate").toString();
			String practiceMemo=map.get("PracticeMemo").toString();								
			
			
			if (statusFlag.equalsIgnoreCase("Y")) 	
			{
				StartPage(testcaseName, client, browser, url);	
				simulatorPage= new TMSSimulatorPage(driver);
				homePage = new TMSHomePage(driver);
				lookupPage = new TMSLookupPage(driver);
				purchasePage = new TMSPurchasePage(driver);
				Log.startTestCase(testcaseName);
				
				simulatorPage.tMSSimulatorForm1(testcaseName);
				simulatorPage.prefillServiceRequestDefaultData(testcaseName);
				homePage.homePageLookup(testcaseName);
				lookupPage.lookupAccountBySSNandZip(testcaseName, ssn, zipCode);
				lookupPage.lookupSubmitPurchase(testcaseName);
				purchasePage.purchaseIdAndFinancing(testcaseName, issuingState, expiryDate, practiceMemo);
				purchasePage.purchaseComplete(testcaseName);
							
			}			
			OTR.saveOTR(testcaseName);
			} 
		catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				driver.quit();
			}
	}
	
	@Test(enabled=true, groups = {"Regression"}, dataProvider="LookupDataProvider")
	public void TMSLookupByNameAndPhoneForDCAccountNumber_TC003(Map<Object,Object> map) throws IOException {		
		try
		{	
			String statusFlag=map.get("StatusFlag").toString();
			String testcaseName=map.get("TestCaseName").toString();
			String client=map.get("Client").toString();
			String browser=map.get("Browser").toString();
			String url=map.get("URL").toString();
			String clientFirstName=map.get("ClientFirstName").toString();
			String clientLastName=map.get("ClientLastName").toString();
			String clientHomePhone=map.get("ClientHomePhone").toString();
			String practiceMemo=map.get("PracticeMemo").toString();
			String refundAmount=map.get("RefundAmount").toString();					
			
			
			if (statusFlag.equalsIgnoreCase("Y")) 	
			{
				StartPage(testcaseName, client, browser, url);	
				simulatorPage= new TMSSimulatorPage(driver);
				homePage = new TMSHomePage(driver);
				lookupPage = new TMSLookupPage(driver);
				refundPage = new TMSRefundPage(driver);
				Log.startTestCase(testcaseName);
					
				simulatorPage.tMSSimulatorForm1(testcaseName);
				simulatorPage.prefillServiceRequestDefaultData(testcaseName);
				homePage.homePageLookup(testcaseName);
				lookupPage.lookupAccountByNameandPhone(testcaseName, clientFirstName,clientLastName, clientHomePhone);
				lookupPage.lookupProcessRefund(testcaseName);
				refundPage.refundAmountAndFinancing(testcaseName, refundAmount, practiceMemo);
				refundPage.refundComplete(testcaseName);
							
			}			
			OTR.saveOTR(testcaseName);
			} 
		catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				driver.quit();
			}
	}
	
	@DataProvider(name="LookupDataProvider")
    public static Object[][] ApplyDataProvider(Method m) {
        Object[][] Data = null;
        String testCase=m.getName();
        try {
            FileInputStream file = new FileInputStream(GenericMethods.getProperties("ExcelDataPath"));

            //Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook = new XSSFWorkbook(file);

            //Get first/desired sheet from the workbook
            XSSFSheet sheet = workbook.getSheet("LookUp");

            int lastRowNum = sheet.getLastRowNum();
            int lastCellNum = sheet.getRow(0).getLastCellNum();
            ArrayList<Object> executableDataRows = new ArrayList<Object>();

            for (int i = 0; i < lastRowNum; i++) {
                if(sheet.getRow(i + 1).getCell(1).toString().equals(testCase)&&sheet.getRow(i + 1).getCell(2).toString().equals("Y") ) {
                    Map<Object, Object> datamap = new HashMap<>();
                    for (int j = 0; j < lastCellNum; j++) {
                        datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i + 1).getCell(j).toString());
                    }
                    executableDataRows.add(datamap);
                }
            }

            Data = new Object[executableDataRows.size()][1];
          //  Iterator iterable = executableDataRows.iterator();

            for(int i=0; i<executableDataRows.size();i++){
				Data[i][0]=executableDataRows.get(i);
                //Data[i][0] = iterable.next();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Data;
    }
 
}
