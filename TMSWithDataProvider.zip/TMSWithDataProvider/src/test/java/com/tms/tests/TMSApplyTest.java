package com.tms.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.tms.baseclass.BaseClass;
import com.tms.pages.TMSApplyPage;
import com.tms.pages.TMSHomePage;
import com.tms.pages.TMSPurchasePage;
import com.tms.pages.TMSRefundPage;
import com.tms.pages.TMSSimulatorPage;
import com.tms.utilities.GenericMethods;
import com.tms.utilities.Log;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;
import com.relevantcodes.extentreports.LogStatus;

public class TMSApplyTest extends BaseClass{

	
	@Test(enabled=false, groups = {"Regression"}, dataProvider="ApplyDataProvider")
	public void TMSApplyApprovedApplicationWithCoApplicant_TC001(Map<Object, Object> map) throws IOException {		
		
			
				String statusFlag=map.get("StatusFlag").toString();
				String testcaseName=map.get("TestCaseName").toString();
				String client=map.get("Client").toString();
				String browser=map.get("Browser").toString();
				String url=map.get("URL").toString();
				String applyFirstName=map.get("ApplyFirstName").toString();
				String applyLastName=map.get("ApplyLastName").toString();
				String applyZipCode=map.get("ApplyZipCode").toString();
				String estimatedFee=map.get("EstimatedFee").toString();
				String dob=map.get("DOB").toString();
				String ssn=map.get("SSN").toString();
				String mailingAddress=map.get("MailingAddress").toString();
				String homePhone=map.get("HomePhone").toString();
				String zipCode=map.get("ZipCode").toString();
				String city=map.get("City").toString();
				String state=map.get("State").toString();
				String monthlyIncome=map.get("MonthlyIncome").toString();
				String coApplicantFirstName=map.get("CoApplicantFirstName").toString();
				String coApplicantLastName=map.get("CoApplicantLastName").toString();
				String coApplicantDOB=map.get("CoApplicantDOB").toString();
				String coApplicantSSN=map.get("CoApplicantSSN").toString();
				String coApplicantHomePhone=map.get("CoApplicantHomePhone").toString();
				String coApplicantEmail=map.get("CoApplicantEmail").toString();
				String coApplicantMonthlyIncome=map.get("CoApplicantMonthlyIncome").toString();
				
				
				try {
								
				if (statusFlag.equalsIgnoreCase("Y")) 	
				{
				StartPage(testcaseName, client, browser, url);	
				simulatorPage= new TMSSimulatorPage(driver);
				homePage = new TMSHomePage(driver);
				applyPage = new TMSApplyPage(driver);
				Log.startTestCase(testcaseName);
								
				simulatorPage.tMSSimulatorForm1(testcaseName);
				simulatorPage.prefillServiceRequestDefaultData(testcaseName);
				homePage.homePageApply(testcaseName);
				applyPage.applySubmitNewApplication(testcaseName,applyFirstName,applyLastName,applyZipCode);
				applyPage.applyApplicantInformationWithCoApplicant(testcaseName,estimatedFee,dob, ssn,homePhone,
						mailingAddress, zipCode, city,state, monthlyIncome,
						coApplicantFirstName, coApplicantLastName, coApplicantDOB,coApplicantSSN,
						coApplicantHomePhone,coApplicantEmail, coApplicantMonthlyIncome);
				applyPage.applyReviewAndSubmit(testcaseName);
				applyPage.applyResult(testcaseName);
				
				}			
			OTR.saveOTR(testcaseName);
			
		}
		catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				e.printStackTrace();
				driver.quit();
			}
	}
	
	
	@Test(enabled=true, groups = {"Regression"},dataProvider="ApplyDataProvider")
	public void TMSApplyUniversalApprovedApplicationWithCoApplicant_TC002(Map<Object, Object> map) throws IOException {		
		
			String statusFlag=map.get("StatusFlag").toString();
			String testcaseName=map.get("TestCaseName").toString();
			String client=map.get("Client").toString();
			String browser=map.get("Browser").toString();
			String url=map.get("URL").toString();
			String estimatedFee=map.get("EstimatedFee").toString();
			String dob=map.get("DOB").toString();
			String ssn=map.get("SSN").toString();
			String mailingAddress=map.get("MailingAddress").toString();
			String homePhone=map.get("HomePhone").toString();
			String zipCode=map.get("ZipCode").toString();
			String city=map.get("City").toString();
			String state=map.get("State").toString();
			String monthlyIncome=map.get("MonthlyIncome").toString();
			String coApplicantFirstName=map.get("CoApplicantFirstName").toString();
			String coApplicantLastName=map.get("CoApplicantLastName").toString();
			String coApplicantDOB=map.get("CoApplicantDOB").toString();
			String coApplicantSSN=map.get("CoApplicantSSN").toString();
			String coApplicantHomePhone=map.get("CoApplicantHomePhone").toString();
			String coApplicantEmail=map.get("CoApplicantEmail").toString();
			String coApplicantMonthlyIncome=map.get("CoApplicantMonthlyIncome").toString();
			String clientFirstName=map.get("ClientFirstName").toString();
			String clientLastName=map.get("ClientLastName").toString();
			String merchantNumber=map.get("MerchantNumber").toString();
			String partnerCode=map.get("PartnerCode").toString();
			String recordId=map.get("RecordId").toString();
			String invoiceNumber=map.get("InvoiceNumber").toString();
			
			try {
							
			if (statusFlag.equalsIgnoreCase("Y")) 	
			{
			StartPage(testcaseName, client, browser, url);	
			simulatorPage= new TMSSimulatorPage(driver);
			homePage = new TMSHomePage(driver);
			applyPage = new TMSApplyPage(driver);
			Log.startTestCase(testcaseName);
				
			simulatorPage.tMSSimulatorForm1(testcaseName);
			simulatorPage.prefillServiceRequestEditData(testcaseName, merchantNumber,partnerCode,
					recordId, invoiceNumber,clientFirstName, clientLastName, homePhone,
					mailingAddress, zipCode,city, state);;
			homePage.homePageApply(testcaseName);
			applyPage.validateApplySubmitNewApplication(testcaseName);
			applyPage.applyApplicantInformationWithCoApplicant(testcaseName, estimatedFee,dob, ssn,homePhone,
					mailingAddress, zipCode, city,state, monthlyIncome,
					coApplicantFirstName, coApplicantLastName, coApplicantDOB,coApplicantSSN,
					coApplicantHomePhone,coApplicantEmail, coApplicantMonthlyIncome);
			applyPage.applyUniversalReviewAndSubmit(testcaseName);
			applyPage.applyUniversalApprovedResult(testcaseName);
				
				
			}			
			OTR.saveOTR(testcaseName);
			} 
		catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				driver.quit();
			}
	}
	
	@Test(enabled=true, groups = {"Regression"}, dataProvider="ApplyDataProvider")
	public void TMSApplyApprovedApplicationFromCheckApplicationStatus_TC003(Map<Object, Object> map) throws IOException, Exception {		
		
		String statusFlag=map.get("StatusFlag").toString();
		String testcaseName=map.get("TestCaseName").toString();
		String client=map.get("Client").toString();
		String browser=map.get("Browser").toString();
		String url=map.get("URL").toString();
		String issuingState=map.get("IssuingState").toString();
		String expiryDate=map.get("ExpiryDate").toString();
		String practiceMemo=map.get("PracticeMemo").toString();	
		String clientFirstName=map.get("ClientFirstName").toString();
		String clientLastName=map.get("ClientLastName").toString();
		String zipCode=map.get("ZipCode").toString();
		String merchantNumber=map.get("MerchantNumber").toString();
		String partnerCode=map.get("PartnerCode").toString();
		String recordId=map.get("RecordId").toString();
		String invoiceNumber=map.get("InvoiceNumber").toString();
		String homePhone=map.get("HomePhone").toString();
		String mailingAddress=map.get("MailingAddress").toString();
		String city=map.get("City").toString();
		String state=map.get("State").toString();
		
		try {
							
			if (statusFlag.equalsIgnoreCase("Y")) 	
			{
			StartPage(testcaseName, client, browser, url);	
			simulatorPage= new TMSSimulatorPage(driver);
			homePage = new TMSHomePage(driver);
			applyPage = new TMSApplyPage(driver);
			purchasePage = new TMSPurchasePage(driver);
			Log.startTestCase(testcaseName);
				
				simulatorPage.tMSSimulatorForm1(testcaseName);
				simulatorPage.prefillServiceRequestEditData(testcaseName, merchantNumber,partnerCode,
						recordId, invoiceNumber,clientFirstName, clientLastName, homePhone,
						mailingAddress, zipCode,city, state);
				homePage.homePageApply(testcaseName);
				Assert.assertTrue(applyPage.input_applyFname.isDisplayed(),"FirstName textbox is not present.");
				Assert.assertTrue(applyPage.input_applyLname.isDisplayed(),"LastName textbox is not present.");
				Assert.assertTrue(applyPage.input_applyZip.isDisplayed(),"ZipCode textbox is not present.");
				Assert.assertTrue(applyPage.button_next.isDisplayed(),"FirstName textbox is not present.");
				applyPage.applyCheckApplicationStatus(testcaseName);
				Assert.assertTrue(applyPage.text_applicantDetails.isDisplayed(),"Applicant Details webelement is not present.");
				Assert.assertTrue(applyPage.text_appNameLabel.isDisplayed(),"ApplicantName label is not present.");
				Assert.assertTrue(applyPage.text_appName.isDisplayed(),"ApplicantName is not present.");
				Assert.assertTrue(applyPage.text_accNumLabel.isDisplayed(),"AccountNumber label is not present.");
				Assert.assertTrue(applyPage.text_accNum.isDisplayed(),"AccountNumber is not present.");
				Assert.assertTrue(applyPage.text_appDateLabel.isDisplayed(),"ApplicationDate label is not present.");
				Assert.assertTrue(applyPage.text_appDate.isDisplayed(),"ApplicationDate is not present.");
				Assert.assertTrue(applyPage.text_creditLimitLabel.isDisplayed(),"CreditLimit label is not present.");
				Assert.assertTrue(applyPage.text_creditLimit.isDisplayed(),"CreditLimit is not present.");
				Assert.assertTrue(applyPage.text_appKeyLabel.isDisplayed(),"ApplicationKey label is not present.");
				Assert.assertTrue(applyPage.text_appKey.isDisplayed(),"ApplicationKey is not present.");
				Assert.assertTrue(applyPage.text_merchantNoLabel.isDisplayed(),"MerchantNo label is not present.");
				Assert.assertTrue(applyPage.text_merchantNo.isDisplayed(),"MerchantNo is not present.");
				Assert.assertTrue(applyPage.text_originLabel.isDisplayed(),"Origin label is not present.");
				Assert.assertTrue(applyPage.text_origin.isDisplayed(),"Origin is not present.");
				Assert.assertTrue(applyPage.button_applyApproveSubmit.isDisplayed(),"Proceed with transaction button is not present.");
				Assert.assertTrue(applyPage.button_applyApproveReturnToList.isDisplayed(),"ReturnToList button is not present.");
				Assert.assertTrue(applyPage.text_disclaimerVerbiage.isDisplayed(),"Footer Verbiage is not present.");
				applyPage.applyResult(testcaseName);
				Assert.assertTrue(applyPage.button_applyApproveSubmit.isDisplayed(),"Proceed with transaction button is not present.");
				applyPage.button_applyApproveSubmit.click();
				purchasePage.purchaseIdAndFinancing(testcaseName, issuingState, expiryDate, practiceMemo);
				purchasePage.purchaseComplete(testcaseName);
				
			}			
			OTR.saveOTR(testcaseName);
			} 
		catch (Throwable e) 
		{
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			driver.quit();
		}
		
	}
	
	 @DataProvider(name="ApplyDataProvider")
	    public static Object[][] ApplyDataProvider(Method m) {
	        Object[][] Data = null;
	        String testCase=m.getName();
	        try {
	            FileInputStream file = new FileInputStream(GenericMethods.getProperties("ExcelDataPath"));

	            //Create Workbook instance holding reference to .xlsx file
	            XSSFWorkbook workbook = new XSSFWorkbook(file);

	            //Get first/desired sheet from the workbook
	            XSSFSheet sheet = workbook.getSheet("Apply");

	            int lastRowNum = sheet.getLastRowNum();
	            int lastCellNum = sheet.getRow(0).getLastCellNum();
	            ArrayList<Object> executableDataRows = new ArrayList<Object>();

	            for (int i = 0; i < lastRowNum; i++) {
	                if(sheet.getRow(i + 1).getCell(1).toString().equals(testCase)&&sheet.getRow(i + 1).getCell(2).toString().equals("Y") ) {
	                    Map<Object, Object> datamap = new HashMap<>();
	                    for (int j = 0; j < lastCellNum; j++) {
	                        datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i + 1).getCell(j).toString());
	                    }
	                    executableDataRows.add(datamap);
	                }
	            }

	            Data = new Object[executableDataRows.size()][1];
	          //  Iterator iterable = executableDataRows.iterator();

	            for(int i=0; i<executableDataRows.size();i++){
					Data[i][0]=executableDataRows.get(i);
	                //obj[i][0] = iterable.next();
	            }
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	        return Data;
	    }
	 
}
