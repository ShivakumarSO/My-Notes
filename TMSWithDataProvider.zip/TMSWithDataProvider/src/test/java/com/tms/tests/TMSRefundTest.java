package com.tms.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.lang.reflect.Method;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.String;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDataFormatter;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.tms.baseclass.BaseClass;
import com.tms.pages.TMSHomePage;
import com.tms.pages.TMSRefundPage;
import com.tms.pages.TMSSimulatorPage;
import com.tms.utilities.GenericMethods;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;
import com.tms.utilities.Log;

import junit.framework.Assert;


import com.relevantcodes.extentreports.LogStatus;

public class TMSRefundTest extends BaseClass{
	private static int indexFrom;
    private static int indexTo;
	
	@Test(enabled=true, groups = {"Regression"}, dataProvider="RefundDataProvider")
	public void TMSApprovedRefundTransactionForPLCCCard_TC001(Map<Object, Object> map)
	/*String testcaseId, String testcaseName, String statusFlag,
			String client, String browser, String url, String accountNumber, String refundAmount, String practiceMemo)*/
		{
			
			try 
			{
				String statusFlag=map.get("StatusFlag").toString();
				String testcaseName=map.get("TestCaseName").toString();
				String client=map.get("Client").toString();
				String browser=map.get("Browser").toString();
				String url=map.get("URL").toString();
				String accountNumber=map.get("AccountNumber").toString();
				String refundAmount=map.get("RefundAmount").toString();
				String practiceMemo=map.get("PracticeMemo").toString();
				
				
				if (statusFlag.equalsIgnoreCase("Y")) 	
				{
				StartPage(testcaseName, client, browser, url);	
				simulatorPage= new TMSSimulatorPage(driver);
				homePage = new TMSHomePage(driver);
				refundPage = new TMSRefundPage(driver);
				Log.startTestCase(testcaseName);
				
				simulatorPage.tMSSimulatorForm1(testcaseName);
				simulatorPage.prefillServiceRequestDefaultData(testcaseName);
				homePage.homePageRefund(testcaseName);
				refundPage.refundEnterAccountNumber(testcaseName, accountNumber);
				refundPage.refundAmountAndFinancing(testcaseName, refundAmount, practiceMemo);
				refundPage.refundComplete(testcaseName);
				
				
			}			
			OTR.saveOTR(testcaseName);
			} 
		catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				driver.quit();
			}
	}
	
	@Test(enabled=false,groups = {"Regression"}, dataProvider="RefundDataProvider")
	public void TMSApprovedRefundTransactionForDCCard_TC002(Map<Object, Object> map) throws IOException {		
			try
			{
				String statusFlag=map.get("StatusFlag").toString();
				String testcaseName=map.get("TestCaseName").toString();
				String client=map.get("Client").toString();
				String browser=map.get("Browser").toString();
				String url=map.get("URL").toString();
				String accountNumber=map.get("AccountNumber").toString();
				String refundAmount=map.get("RefundAmount").toString();
				String practiceMemo=map.get("PracticeMemo").toString();
				
				
				if (statusFlag.equalsIgnoreCase("Y")) 	
				{
					StartPage(testcaseName, client, browser, url);	
					simulatorPage= new TMSSimulatorPage(driver);
					homePage = new TMSHomePage(driver);
					refundPage = new TMSRefundPage(driver);
					Log.startTestCase(testcaseName);
					
					simulatorPage.tMSSimulatorForm1(testcaseName);
					simulatorPage.prefillServiceRequestDefaultData(testcaseName);
					homePage.homePageRefund(testcaseName);
					refundPage.refundEnterAccountNumber(testcaseName,accountNumber);
					refundPage.refundAmountAndFinancing(testcaseName,refundAmount, practiceMemo);
					refundPage.refundComplete(testcaseName);
				
				}			
				OTR.saveOTR(testcaseName);
			} 
			catch (Exception e) 
			{
				screenshotPath = WebDriverReusableMethods.getScreenshot(driver, screenshotFolder, 0, stepNum++);
				logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath) + e.getMessage());
				driver.quit();
			}
	}
	
	 @DataProvider(name="RefundDataProvider")
	    public static Object[][] RefundDataProvider(Method m) {
	        Object[][] Data = null;
	        String testCase=m.getName();
	        try {
	            FileInputStream file = new FileInputStream(GenericMethods.getProperties("ExcelDataPath"));

	            //Create Workbook instance holding reference to .xlsx file
	            XSSFWorkbook workbook = new XSSFWorkbook(file);

	            //Get first/desired sheet from the workbook
	            XSSFSheet sheet = workbook.getSheet("Refund");

	            int lastRowNum = sheet.getLastRowNum();
	            int lastCellNum = sheet.getRow(0).getLastCellNum();
	            ArrayList<Object> executableDataRows = new ArrayList<Object>();

	            for (int i = 0; i < lastRowNum; i++) {
	                if(sheet.getRow(i + 1).getCell(1).toString().equals(testCase)&&sheet.getRow(i + 1).getCell(2).toString().equals("Y") ) {
	                    Map<Object, Object> datamap = new HashMap<>();
	                    for (int j = 0; j < lastCellNum; j++) {
	                        datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i + 1).getCell(j).toString());
	                    }
	                    executableDataRows.add(datamap);
	                }
	            }

	            Data = new Object[executableDataRows.size()][1];
	          //  Iterator iterable = executableDataRows.iterator();

	            for(int i=0; i<executableDataRows.size();i++){
					Data[i][0]=executableDataRows.get(i);
	                //obj[i][0] = iterable.next();
	            }
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	        return Data;
	    }
	 
	
		/*String testName=m.getName();
		 FileInputStream fileInputStream= new FileInputStream(".\\Resources\\TestData\\TMSTestData.xlsx"); //Excel sheet file location get mentioned here
		 XSSFWorkbook workbook = new XSSFWorkbook (fileInputStream); 
		 XSSFSheet  worksheet = workbook.getSheet("Refund");
	     XSSFRow Row=worksheet.getRow(0);    
	    
	        int RowNum = worksheet.getPhysicalNumberOfRows();
	        int ColNum= Row.getPhysicalNumberOfCells();
	         
	        Object Data[][]= new Object[RowNum-1][ColNum]; 
	         
	            for(int i=0; i<RowNum-1; i++) 
	            {  
	            	XSSFRow row= worksheet.getRow(i+1);
	            	HSSFDataFormatter formatter = new HSSFDataFormatter();
                	String testCaseName=formatter.formatCellValue(row.getCell(1));
	            	         	
	            	if(testCaseName.equals(testName))
	            	{
	                 
		                for (int j=0; j<ColNum; j++) 
		                {
		                     XSSFCell cell= row.getCell(j);
		                     String value=formatter.formatCellValue(cell);
		                     Data[i][j]=value; 
		                }
	
	            	}
	            }
				return Data;
	 }*/
}
