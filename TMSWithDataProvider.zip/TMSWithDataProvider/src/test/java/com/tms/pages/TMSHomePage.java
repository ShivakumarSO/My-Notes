package com.tms.pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.tms.baseclass.BaseClass;
import com.tms.utilities.Log;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;
import com.relevantcodes.extentreports.LogStatus;

public class TMSHomePage extends BaseClass{


	public TMSHomePage(WebDriver driver) 
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div/ul[@class='main-links']/li[1]/a")
	private WebElement text_applyHeader;
	
	@FindBy(xpath="//div/ul[@class='main-links']/li[2]/a")
	private WebElement text_purchaseHeader;
	
	@FindBy(xpath="//div/ul[@class='main-links']/li[3]/a")
	private WebElement text_refundHeader;
	
	@FindBy(xpath="//div/ul[@class='main-links']/li[4]/a")
	private WebElement text_lookupHeader;
	
	@FindBy(xpath="//img[@alt='Apply']")
	private WebElement image_applyImage;
	
	@FindBy(xpath="//img[@alt='Purchase']")
	private WebElement image_purchaseImage;
	
	@FindBy(xpath="//img[@alt='Refund']")
	private WebElement image_refundImage;
	
	@FindBy(xpath="//img[@alt='Lookup']")
	private WebElement image_lookupImage;
	
	@FindBy(linkText="Quickscreen")
	private WebElement link_quickScreen;

	public  void homePageApply(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
					
			Assert.assertTrue(text_applyHeader.isDisplayed(),"Apply webelement is not displayed.");
			Assert.assertTrue(text_purchaseHeader.isDisplayed(),"Purchase webelement is not displayed.");
			Assert.assertTrue(text_refundHeader.isDisplayed(),"Refund webelement is not displayed.");
			Assert.assertTrue(text_lookupHeader.isDisplayed(),"Lookup webelement is not displayed.");
			Assert.assertTrue(image_applyImage.isDisplayed(),"Apply image is not displayed.");
			OTR.addscreenlogupdateOTR(driver,"Page Headers are displayed.", "Pass");
			image_applyImage.click();
			Log.info("Clicked on Apply image");
			logger.log(LogStatus.PASS,"Clicked on Apply image");
				Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Apply Image.", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");
			
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to validate Home Page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in Home Page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in Home Page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not redirected properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not redirected properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not redirected properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public void homePagePurchase(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
			
			Assert.assertTrue(text_applyHeader.isDisplayed(),"Apply webelement is not displayed.");
			Assert.assertTrue(text_purchaseHeader.isDisplayed(),"Purchase webelement is not displayed.");
			Assert.assertTrue(text_refundHeader.isDisplayed(),"Refund webelement is not displayed.");
			Assert.assertTrue(text_lookupHeader.isDisplayed(),"Lookup webelement is not displayed.");
			Assert.assertTrue(image_applyImage.isDisplayed(),"Apply image is not displayed.");
			Assert.assertTrue(image_purchaseImage.isDisplayed(),"Purchase image is not displayed.");
			OTR.addscreenlogupdateOTR(driver,"Page Headers are displayed.", "Pass");
			image_purchaseImage.click();
			Log.info("Clicked on Purchase image");
			logger.log(LogStatus.PASS,"Clicked on Purchase image");
				Thread.sleep(1000);
				OTR.addscreenlogupdateOTR(driver,"Clicked on Purchase Image.", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.")
		
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to validate Home Page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in Home Page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in Home Page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not redirected properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Application is not redirected properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not redirected properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public  void homePageRefund(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(text_applyHeader.isDisplayed(),"Apply webelement is not displayed.");
			Assert.assertTrue(text_purchaseHeader.isDisplayed(),"Purchase webelement is not displayed.");
			Assert.assertTrue(text_refundHeader.isDisplayed(),"Refund webelement is not displayed.");
			Assert.assertTrue(text_lookupHeader.isDisplayed(),"Lookup webelement is not displayed.");
			Assert.assertTrue(image_refundImage.isDisplayed(),"Apply image is not displayed.");
			OTR.addscreenlogupdateOTR(driver,"Page Headers are displayed.", "Pass");
			image_refundImage.click();
			Log.info("Clicked on Refund image");
			logger.log(LogStatus.PASS,"Clicked on Refund image");
			Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Refund Image.", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to validate Home Page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in Home Page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in Home Page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not redirected properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not redirected properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not redirected properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public  void homePageLookup(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
			homePage  = new TMSHomePage(driver);
			
			Assert.assertTrue(text_applyHeader.isDisplayed(),"Apply webelement is not displayed.");
			Assert.assertTrue(text_purchaseHeader.isDisplayed(),"Purchase webelement is not displayed.");
			Assert.assertTrue(text_refundHeader.isDisplayed(),"Refund webelement is not displayed.");
			Assert.assertTrue(text_lookupHeader.isDisplayed(),"Lookup webelement is not displayed.");
			Assert.assertTrue(image_lookupImage.isDisplayed(),"Lookup image is not displayed.");
			OTR.addscreenlogupdateOTR(driver,"Page Headers are displayed.", "Pass");
			image_lookupImage.click();
			Log.info("Clicked on Lookup image");
			logger.log(LogStatus.PASS,"Clicked on Lookup image");
			Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Lookup Image.", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to validate Home Page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in Home Page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in Home Page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not redirected properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not redirected properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not redirected properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	
}
