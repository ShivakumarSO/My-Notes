package com.tms.pages;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.tms.baseclass.BaseClass;
import com.tms.utilities.GenericMethods;
import com.tms.utilities.Log;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;

public class TMSSimulatorPage extends BaseClass{

	public TMSSimulatorPage(WebDriver driver) 
	{
		//this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="client_id")
	private WebElement input_username;
	
	@FindBy(name="client_secret")
	private WebElement input_password;
	
	@FindBy(name="selectedEnvironment")
	private WebElement dropDown_selectedEnv;
	
	@FindBy(id="goToTms")
	private WebElement button_goToTMS;		
		
	@FindBy(name="merchantNumber")
	private WebElement input_merchantNumber;	
	
	@FindBy(name="partnerCode")
	private WebElement input_partnerCode;	
	
	@FindBy(name="recordID")
	private WebElement input_recordID;
	
	@FindBy(name="invoiceNumber")
	private WebElement input_invoiceNumber;
	
	@FindBy(name="refundAmt")
	private WebElement input_refundAmount;

	@FindBy(name="clientFName")
	private WebElement input_clientFName;
	
	@FindBy(name="clientLName")
	private WebElement input_clientLName;
	
	@FindBy(name="clientMName")
	private WebElement input_clientMName;
	
	@FindBy(name="mailingAddress1")
	private WebElement input_mailingAddress;
	
	@FindBy(name="aptNumber")
	private WebElement input_aptNumber;
	
	@FindBy(name="zipcode")
	private WebElement input_zipCode;
	
	@FindBy(name="city")
	private WebElement input_city;
	
	@FindBy(name="state")
	private WebElement input_state;
	
	@FindBy(name="homePhone")
	private WebElement input_homePhone;
	
	@FindBy(id="submit")
	private WebElement button_submitQuery;
	
	@FindBy(id="openTms")
	private WebElement button_openTmsButton;

	public void tMSSimulatorForm1(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
			
			Assert.assertTrue(button_goToTMS.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			/*tmsSimulator.getUsername().clear();
			tmsSimulator.getUsername().sendKeys(testdataHashMap.get("Username"));	
			tmsSimulator.getPassword().clear();
			tmsSimulator.getPassword().sendKeys(testdataHashMap.get("Password"));
			WebDriverReusableMethods.selecDropDown(tmsSimulator.getSelectedEnv(), testdataHashMap.get("SelectedEnv"));
			OTR.addscreenlogupdateOTR("The username, password and selected env has been entered. ", "Pass");*/
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");	
			OTR.addscreenlogupdateOTR(driver,"Proceeded with default values on Simulator page ", "Pass");
			button_goToTMS.click();
			Log.info("Clicked on GoTo TMS button");
			logger.log(LogStatus.PASS,"Clicked on GoTo TMS button");	
			OTR.addscreenlogupdateOTR(driver,"Clicked on GoToTMS button. ", "Pass");
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());	
			Log.info("Failed to enter data on TMS Simulator page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Simulator page", "Fail");
			Assert.fail("Error occured in entering data on TMS Simulator page.");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}

	public  void prefillServiceRequestEditData(String testcaseName, String merchantNumber,String partnerCode,
			String recordId, String invoiceNumber,String clientFirstName, String clientLastName, String homePhone,
			String mailingAddress, String zipCode,String city, String state ) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(input_merchantNumber.isDisplayed(),"Application is not redirected properly or Downtime or Internet Connection.");
			
			input_merchantNumber.clear();
			input_merchantNumber.sendKeys(merchantNumber);
			Log.info("MerchantNumber is set");
			logger.log(LogStatus.PASS,merchantNumber+" value set to MerchantNumber");	
			input_partnerCode.clear();
			input_partnerCode.sendKeys(partnerCode);
			Log.info("PartnerCode is set");
			logger.log(LogStatus.PASS,partnerCode+" value set to PartnerCode");	
			input_recordID.clear();
			input_recordID.sendKeys(recordId);
			Log.info("RecordId is set");
			logger.log(LogStatus.PASS,recordId+" value set to RecordId");	
			input_invoiceNumber.clear();
			input_invoiceNumber.sendKeys(invoiceNumber);
			Log.info("InvoiceNumber is set");
			logger.log(LogStatus.PASS,invoiceNumber+" value set to InvoiceNumber");	
			input_refundAmount.clear();
			//tmsSimulator.getRefundAmount().sendKeys(testdataHashMap.get("RefundAmount"));
			input_clientFName.clear();
			input_clientFName.sendKeys(clientFirstName);
			Log.info("FirstName is set");
			logger.log(LogStatus.PASS,clientFirstName+" value set to FirstName");	
			input_clientLName.clear();
			input_clientLName.sendKeys(clientLastName);
			Log.info("LastName is set");
			logger.log(LogStatus.PASS,clientLastName+" value set to LastName");	
			input_homePhone.clear();
			input_homePhone.sendKeys(homePhone);
			Log.info("HomePhone is set");
			logger.log(LogStatus.PASS,homePhone+" value set to HomePhone");	
			input_mailingAddress.clear();
			input_mailingAddress.sendKeys(mailingAddress);
			Log.info("MailingAddress is set");
			logger.log(LogStatus.PASS,mailingAddress+" value set to MailingAddress");	
			input_zipCode.clear();
			input_zipCode.sendKeys(zipCode);
			Log.info("ZipCode is set");
			logger.log(LogStatus.PASS,zipCode+" value set to ZipCode");	
			input_city.clear();
			input_city.sendKeys(city);
			Log.info("City is set");
			logger.log(LogStatus.PASS,city+" value set to City");	
			input_state.clear();
			input_state.sendKeys(state);
			Log.info("State is set");
			logger.log(LogStatus.PASS,state+" value set to State");	
						
			OTR.addscreenlogupdateOTR(driver,"All the mandatory fields have been entered.", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_submitQuery.click();
			Log.info("Clicked on Submit Query");
			logger.log(LogStatus.PASS,"Clicked on Submit Query");	
			Thread.sleep(1000);
			
			button_openTmsButton.click();
			Log.info("Clicked on Open TMS button");
			logger.log(LogStatus.PASS,"Clicked on Open TMS button");	
			Thread.sleep(1000);
			ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs.get(1));
		    
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on Prefill Service Request page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on Prefill Service Request page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on Prefill Service Request page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not redirected properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not redirected properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not redirected properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public void prefillServiceRequestDefaultData(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(input_merchantNumber.isDisplayed(),"Application is not redirected properly or Downtime or Internet Connection.");
			button_submitQuery.click();
			Log.info("Clicked on Submit Query");
			logger.log(LogStatus.PASS,"Clicked on Submit Query");	
			Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Submit Query button.", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");
			button_openTmsButton.click();
			Log.info("Clicked on Open TMS button");
			logger.log(LogStatus.PASS,"Clicked on Open TMS button");	
			Thread.sleep(1000);
			ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs.get(1));
		    
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Error occured in Prefill Service Request page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in Prefill Service Request page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on Prefill Service Request page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not redirected properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not redirected properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not redirected properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	
}
