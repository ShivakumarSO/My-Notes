package com.tms.pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.tms.baseclass.BaseClass;
import com.tms.utilities.Log;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;

public class TMSPurchasePage extends BaseClass{

	
	public TMSPurchasePage(WebDriver driver) 
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="estimatedFee")
	private WebElement input_estimatedFee;
	
	@FindBy(partialLinkText="Look Up Account by SSN")
	private WebElement link_lookupAccountBySsnAndZip;
	
	@FindBy(id="ssnNbr")
	private WebElement input_ssnNumber;
	
	@FindBy(id="zipCode")
	private WebElement input_zipCode;
	
	@FindBy(id="validateBtn")
	private WebElement button_next;
	
	@FindBy(partialLinkText=" Look Up Account by Name")
	private WebElement link_lookupAccountByNameAndPhone;
	
	@FindBy(id="chFname")
	private WebElement input_clientFirstName;
	
	@FindBy(id="chLname")
	private WebElement input_clientLastName;
	
	@FindBy(id="chPhone")
	private WebElement input_clientHomePhone;
	
	@FindBy(id="idTypes")
	private WebElement input_cardholderID;
	
	@FindBy(id="selectStates")
	private WebElement dropDown_issuingState;
	
	@FindBy(id="expDateInput")
	private WebElement input_expDate;
	
	@FindBy(xpath="//*[@href='#CareCredit']")
	private WebElement link_careCreditLink;
	
	@FindBy(xpath="//div/input[@class='months']/following-sibling::label/span[contains(text(),'6 month')]")
	private WebElement dropDown_promoMonth;
	
	@FindBy(id="practiceMemo")
	private WebElement input_practiceMemo;
	
	@FindBy(id="submit")
	private WebElement button_submitTransaction;
	
	@FindBy(partialLinkText="Enter Account Number")
	private WebElement link_lookupByAccountNumber;
	
	@FindBy(id="accountNumber")
	private WebElement input_accountNumber;
	
	@FindBy(xpath="//div[@class='main-container purchase']/div/div[2]/div[2]/strong")
	private WebElement text_purchaseComplete;
	
	@FindBy(xpath="//button[contains(text(), 'Print Receipt')]")
	private WebElement  text_printReceipt;

	@FindBy(xpath="//div[@class='pdf-div']")
	private WebElement pdf_pdfWindow;

	public void purchaseLookupAccountBySSNandZip(String testcaseName, String purchaseAmount, String ssn, String zipCode) throws IOException
	{
	try {		
			Thread.sleep(2000);
					
			Assert.assertTrue(input_estimatedFee.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			input_estimatedFee.clear();
			input_estimatedFee.sendKeys(purchaseAmount);	
			Log.info("PurchaseAmount is set");
			logger.log(LogStatus.PASS,purchaseAmount+" value set to PurchaseAmount");		
			link_lookupAccountBySsnAndZip.click();
			Log.info("Clicked on Lookup Account by SSN and Zip");
			logger.log(LogStatus.PASS,"Clicked on Lookup Account by SSN and Zip");
			input_ssnNumber.sendKeys(ssn);
			Log.info("SSN is set");
			logger.log(LogStatus.PASS,ssn+" value set to SSN");	
			input_zipCode.clear();
			input_zipCode.sendKeys(zipCode);
			Log.info("ZipCode is set");
			logger.log(LogStatus.PASS,zipCode+" value set to ZipCode");	
			
			
			OTR.addscreenlogupdateOTR(driver,"SSN and ZipCode has been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_next.click();
			Log.info("Clicked on Next");
			logger.log(LogStatus.PASS,"Clicked on Next");	
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Purchase page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Purchase page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Purchase page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	public void purchaseLookupAccountByNameandPhone(String testcaseName, String purchaseAmount,String clientFirstName,
			String clientLastName, String clientHomePhone) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(input_estimatedFee.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			input_estimatedFee.clear();
			input_estimatedFee.sendKeys(purchaseAmount);
			Log.info("PurchaseAmount is set");
			logger.log(LogStatus.PASS,purchaseAmount+" value set to PurchaseAmount");	
			link_lookupAccountByNameAndPhone.click();
			Log.info("Clicked on LookupAccount By Name and Phone");
			logger.log(LogStatus.PASS,"Clicked on LookupAccount By Name and Phone");	
			input_clientFirstName.sendKeys(clientFirstName);
			Log.info("FirstName is set");
			logger.log(LogStatus.PASS,clientFirstName+" value set to FirstName");	
			input_clientLastName.sendKeys(clientLastName);
			Log.info("LastName is set");
			logger.log(LogStatus.PASS,clientLastName+" value set to LastName");	
			input_clientHomePhone.sendKeys(clientHomePhone);
			Log.info("HomePhone is set");
			logger.log(LogStatus.PASS,clientHomePhone+" value set to HomePhone");	
			OTR.addscreenlogupdateOTR(driver,"FName, Lname and PhoneNo has been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_next.click();
			Log.info("Clicked on Next");
			logger.log(LogStatus.PASS,"Clicked on Next");	
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Purchase page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Purchase page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Purchase page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public void purchaseEnterAccountNumber(String testcaseName, String accountNumber) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(link_lookupAccountBySsnAndZip.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			link_lookupByAccountNumber.click();
			Log.info("Clicked on Lookup by AccountNumber");
			logger.log(LogStatus.PASS,"Clicked on Lookup by AccountNumber");	
			input_accountNumber.click();
			input_accountNumber.sendKeys(accountNumber);
			Log.info("AccountNumber is set");
			logger.log(LogStatus.PASS,accountNumber+" value set to AccountNumber");	
			OTR.addscreenlogupdateOTR(driver,"Account Number has been entered", "Pass");
			button_next.click();
			Log.info("Clicked on Next button");
			logger.log(LogStatus.PASS,"Clicked on Next button");	
			Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Next button", "Pass");
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Purchase page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Purchase page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Purchase page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}

	public void purchaseIdAndFinancing(String testcaseName, String issuingState, String expiryDate, String practiceMemo ) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(input_cardholderID.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			WebDriverReusableMethods.selecDropDown(input_cardholderID, 1);
			Log.info("CardHolderID is selected");
			logger.log(LogStatus.PASS,"CardHolderID is selected");	
			WebDriverReusableMethods.selecDropDown(dropDown_issuingState, issuingState,"text");
			Log.info("Issuing State is selected");
			logger.log(LogStatus.PASS,"Issuing State is selected");	
			input_expDate.sendKeys(expiryDate);
			Log.info("ExpiryDate is set");
			logger.log(LogStatus.PASS,expiryDate+" value set to ExpiryDate");	
			link_careCreditLink.click();
			Log.info("Clicked on CareCredit link");
			logger.log(LogStatus.PASS,"Clicked on CareCredit link");	
			dropDown_promoMonth.click();
			Log.info("Promo Month is selected");
			logger.log(LogStatus.PASS,"Promo Month is selected");	
			input_practiceMemo.clear();
			input_practiceMemo.sendKeys(practiceMemo);
			Log.info("PracticeMemo is set");
			logger.log(LogStatus.PASS,practiceMemo+" value set to PracticeMemo");	
			OTR.addscreenlogupdateOTR(driver,"All required fields have been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_submitTransaction.click();
			Log.info("Clicked on Submit Transaction");
			logger.log(LogStatus.PASS,"Clicked on Submit Transaction");	
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Purchase page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Purchase page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Purchase page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}


	public void purchaseComplete(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(4000);
			purchasePage  = new TMSPurchasePage(driver);
			
			Assert.assertTrue(text_purchaseComplete.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			Assert.assertTrue(text_printReceipt.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			Assert.assertTrue(pdf_pdfWindow.isDisplayed(), "PDF Window is not displayed.");
			
			OTR.addscreenlogupdateOTR(driver,"Purchase Complete Receipt Page web elements are validated. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
					
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Purchase page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Purchase page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Purchase page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			org.testng.Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	
}
