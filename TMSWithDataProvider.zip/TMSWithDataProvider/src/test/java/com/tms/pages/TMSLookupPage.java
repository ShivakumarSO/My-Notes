package com.tms.pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.tms.baseclass.BaseClass;
import com.tms.utilities.Log;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;

public class TMSLookupPage extends BaseClass {

	
	public TMSLookupPage(WebDriver driver) 
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(partialLinkText="Look Up Account by SSN")
	private WebElement link_lookupAccountBySsnAndZip;

	@FindBy(id="ssnNbr")
	private WebElement input_ssnNumber;
	
	@FindBy(id="zipCode")
	private WebElement input_zipCode;
	
	@FindBy(id="lkpSubmit")
	private WebElement button_lookUpAccount;
	
	@FindBy(partialLinkText="Look Up Account by Name")
	private WebElement link_lookupAccountByNameAndPhone;
	
	@FindBy(id="lkpfname")
	private WebElement input_lookupFname;
	
	@FindBy(id="lkplname")
	private WebElement input_lookupLname;
	
	@FindBy(id="lkpPhone")
	private WebElement input_lookupPhone;
	
	@FindBy(id="purchbtn")
	private WebElement button_submitPurchase;
	
	@FindBy(id="refndbtn")
	private WebElement button_processRefund;
	
	@FindBy(partialLinkText="Enter Account Number")
	private WebElement link_lookupByAccountNumber;
	
	@FindBy(id="accountNumber")
	private WebElement input_accountNumber;
	
	@FindBy(xpath="//label[contains(text(),'Account')]")
	private WebElement text_accountDetails;	

	@FindBy(xpath="//strong[@id='respfname']")
	private WebElement text_prefillFName;
	
	@FindBy(xpath="//strong[@id='resplname']")
	private WebElement text_prefillLName;
	
	@FindBy(xpath="//p[@id='actnmbr']")
	private WebElement text_prefillAccountNumber;
	
	@FindBy(xpath="//p[@class='pre-fill-data pre-fill-sm']")
	private WebElement text_availableCredit;
	
	@FindBy(xpath="//table[@id='resntrns']/tbody/tr[1]/td[1]")
	private WebElement text_recentTransAmount;
	
	@FindBy(xpath="//table[@id='resntrns']/tbody/tr[1]/td[2]")
	private WebElement text_recentTransCareCredit;
	
	@FindBy(xpath="//table[@id='resntrns']/tbody/tr[1]/td[3]")
	private WebElement text_recentTransDate;
	
	@FindBy(xpath="//table[@id='resntrns']/tbody/tr[1]/td[4]")
	private WebElement text_recentTransPromoCode;
	
	@FindBy(xpath="//table[@id='resntrns']/tbody/tr[1]/td[5]/span/a")
	private WebElement text_recentTransReceipt;
	
	@FindBy(linkText="TOP")
	private WebElement link_gotoTop;
	
	@FindBy(id="printContent")
	private WebElement text_printContent;
	
	@FindBy(xpath="//embed[@class='lookupRecepit']")
	private WebElement pdf_lookUpReciept;
	
	@FindBy(xpath="//strong[contains(text(),'PURCHASE')]")
	private WebElement text_purchaseComplete;
	
	@FindBy(xpath="//div[@class='pdf-div']")
	private WebElement window_pdfWindow;

		
	public void lookupAccountByAccountNumber(String testcaseName,String accountNumber) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(link_lookupAccountBySsnAndZip.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			link_lookupByAccountNumber.click();
			Log.info("Clicked on Lookup Account By SSN and Zip");
			logger.log(LogStatus.PASS,"Clicked on Lookup Account By SSN and Zip");
			input_accountNumber.click();
			input_accountNumber.sendKeys(accountNumber);
			Log.info("AccountNumber is set");
			logger.log(LogStatus.PASS,accountNumber+" value set to AccountNumber");
			OTR.addscreenlogupdateOTR(driver,"Account Number has been entered", "Pass");
			button_lookUpAccount.click();
			Log.info("Clicked on Lookup Account");
			logger.log(LogStatus.PASS,"Clicked on Lookup Account");
			Thread.sleep(2000);
			Assert.assertTrue(text_accountDetails.isDisplayed(),"Account Details webelement doesnot exists on Lookup Page");
			button_lookUpAccount.click();
			Log.info("Clicked on Lookup Account");
			logger.log(LogStatus.PASS,"Clicked on Lookup Account");
			Thread.sleep(2000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Lookup Account", "Pass");
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Lookup page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Lookup page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Lookup page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public  void lookupAccountByNameandPhone(String testcaseName, String clientFirstName,String clientLastName, String clientHomePhone) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(link_lookupAccountByNameAndPhone.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			link_lookupAccountByNameAndPhone.click();
			Log.info("Clicked on Lookup Account By Name and Phone");
			logger.log(LogStatus.PASS,"Clicked on Lookup Account By Name and Phone");
			input_lookupFname.clear();
			input_lookupFname.sendKeys(clientFirstName);
			Log.info("FirstName is set");
			logger.log(LogStatus.PASS,clientFirstName+" value set to FirstName");
			input_lookupLname.clear();
			input_lookupLname.sendKeys(clientLastName);
			Log.info("LastName is set");
			logger.log(LogStatus.PASS,clientLastName+" value set to LastName");
			input_lookupPhone.clear();
			input_lookupPhone.sendKeys(clientHomePhone);
			Log.info("HomePhone is set");
			logger.log(LogStatus.PASS,clientHomePhone+" value set to HomePhone");
			
			OTR.addscreenlogupdateOTR(driver,"FName, Lname and PhoneNo has been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_lookUpAccount.click();
			Log.info("Clicked on Lookup Account");
			logger.log(LogStatus.PASS,"Clicked on Lookup Account");
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Purchase page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Purchase page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}

	public void lookupAccount(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
			
			Assert.assertTrue(text_accountDetails.isDisplayed(),"Account Details webelement doesnot exists on Lookup Page");
			Assert.assertTrue(text_prefillFName.isDisplayed(),"Prefilled FirstName is not displayed");
			Assert.assertTrue(text_prefillLName.isDisplayed(),"Prefilled LastName is not displayed");
			Assert.assertTrue(text_prefillAccountNumber.isDisplayed(),"Prefilled Account Number is not displayed");
			Assert.assertTrue(text_availableCredit.isDisplayed(),"Available Credit Limit is not displayed");
			Assert.assertTrue(text_recentTransAmount.isDisplayed(),"Recent Transaction Amount is not displayed");
			Assert.assertTrue(text_recentTransCareCredit.isDisplayed(),"Recent Transaction CareCredit is not displayed");
			Assert.assertTrue(text_recentTransDate.isDisplayed(),"Recent Transaction Date is not displayed");
			Assert.assertTrue(text_recentTransPromoCode.isDisplayed(),"Recent Transaction Promo Code is not displayed");
			Assert.assertTrue(text_recentTransReceipt.isDisplayed(),"Recent Transaction Receipt Link is not displayed");
			OTR.addscreenlogupdateOTR(driver,"Given Web Elements are validated on Lookup Page", "Pass");
			
			text_recentTransReceipt.click();
			Log.info("Clicked on Recent Transaction Receipt");
			logger.log(LogStatus.PASS,"Clicked on Recent Transaction Receipt");
			Assert.assertTrue(text_printContent.isDisplayed(),"Print Content is not displayed");
			Assert.assertTrue(pdf_lookUpReciept.isDisplayed(),"PDF is not displayed");
			OTR.addscreenlogupdateOTR(driver,"Print Content and PDF is displayed", "Pass");
			link_gotoTop.click();
			Log.info("Clicked on TOP link");
			logger.log(LogStatus.PASS,"Clicked on TOP link");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			OTR.addscreenlogupdateOTR(driver,"Clicked on TOP link", "Pass");
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to validate TMS Lookup page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in validating TMS Lookup page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in validating TMS Lookup page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}

	public void lookupAccountBySSNandZip(String testcaseName, String ssn, String zipCode) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(link_lookupAccountBySsnAndZip.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			//lookupPage.getLookupAccountBySsnAndZip().click();
			input_ssnNumber.sendKeys(ssn);
			Log.info("ssn is set");
			logger.log(LogStatus.PASS,ssn+" value set to SSN");
			input_zipCode.clear();
			input_zipCode.sendKeys(zipCode);
			Log.info("zipCode is set");
			logger.log(LogStatus.PASS,zipCode+" value set to ZipCode");			
			
			OTR.addscreenlogupdateOTR(driver,"SSN and ZipCode has been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_lookUpAccount.click();
			Log.info("Clicked on Lookup Account");
			logger.log(LogStatus.PASS,"Clicked on Lookup Account");		
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Lookup page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Lookup page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Lookup page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}	
	
	public void lookupSubmitPurchase(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(button_submitPurchase.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			button_submitPurchase.click();
			Log.info("Clicked on Submit Purchase");
			logger.log(LogStatus.PASS,"Clicked on Submit Purchase");	
			Thread.sleep(10000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on SubmitPurchase button", "Pass");
			} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Lookup page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Lookup page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Lookup page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}	
	
	public void lookupProcessRefund(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(button_processRefund.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			button_processRefund.click();
			Log.info("Clicked on Process Refund");
			logger.log(LogStatus.PASS,"Clicked on Process Refund");	
			Thread.sleep(10000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Process Refund button", "Pass");
			} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Lookup page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Lookup page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Lookup page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}	
	
	
}
