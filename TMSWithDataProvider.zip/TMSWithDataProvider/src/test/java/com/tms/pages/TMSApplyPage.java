package com.tms.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.relevantcodes.extentreports.LogStatus;
import com.tms.baseclass.BaseClass;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;
import com.tms.utilities.Log;

public class TMSApplyPage extends BaseClass{

	public TMSApplyPage(WebDriver driver) 
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="applyFname")
	public WebElement input_applyFname;
	
	@FindBy(id="applyLname")
	public WebElement input_applyLname;
	
	@FindBy(id="applyZip")
	public WebElement input_applyZip;
	
	@FindBy(id="next")
	public WebElement button_next;
	
	@FindBy(xpath="//*[contains(text(),'Applicant Information')]")
	private WebElement text_applicantInformation;
	
	@FindBy(id="estimatedFee")
	private WebElement input_estimatedFee;
	
	@FindBy(id="fName")
	private WebElement input_firstName;
	
	@FindBy(id="miName")
	private WebElement input_miName;
	
	@FindBy(id="lName")
	private WebElement input_lName;
	
	@FindBy(id="selectedSuffix")
	private WebElement dropDown_selectedSuffix;
	
	@FindBy(id="dateOfBirth")
	private WebElement input_dateOfBirth;
	
	@FindBy(id="ssn")
	private WebElement input_ssn;
	
	@FindBy(id="homePhone")
	private WebElement input_homePhone;
	
	@FindBy(id="mobilePhone")
	private WebElement input_mobilePhone;
	
	@FindBy(id="mailingAddr")
	private WebElement  input_mailingAddr;
	
	@FindBy(id="apartment")
	private WebElement input_apartment;
	
	@FindBy(id="zipCode")
	private WebElement input_zipCode;
	
	@FindBy(id="city")
	private WebElement input_city;
	
	@FindBy(id="selectStates")
	private WebElement dropDown_selectStates;
	
	@FindBy(id="emailAddress")
	private WebElement input_emailAddress;
	
	@FindBy(xpath="//input[@name='Housingtype']/following-sibling::label[contains(text(),'Own')]")
	private WebElement dropDown_housingType;
	
	@FindBy(id="monthlyNetIncome")
	private WebElement input_monthlyNetIncome;
	
	@FindBy(id="apply2next")
	private WebElement button_applyToNext;
	
	@FindBy(id="backToApply")
	private WebElement button_backtoApply;
	
	@FindBy(xpath="//input[@id='coApplyCheckBox']/following-sibling::span[1]")
	private WebElement dropDown_coApplyCheckBox;
	
	@FindBy(id="homeTab")
	private WebElement button_submitNewApp;
	
	@FindBy(id="checkAppTab")
	private WebElement button_checkAppStatus;
	
	@FindBy(id="coapplicantFName")
	private WebElement input_coApplicantFName;
	
	@FindBy(id="coapplicantLName")
	private WebElement input_coApplicantLName;
	
	@FindBy(id="coapplicantDob")
	private WebElement input_coApplicantDOB;
	
	@FindBy(id="coapplicantSsn")
	private WebElement input_coApplicantSSN;
	
	@FindBy(id="coapplicantHomePhone")
	private WebElement input_coApplicantHomePhone;
	
	@FindBy(id="emilCoApply")
	private WebElement input_coApplicantEmail;
	
	@FindBy(id="coapplicantMonthlyNetIncome")
	private WebElement input_coApplicantMontlyIncome;
	
	@FindBy(xpath="//input[@name='HousingCotype']/following-sibling::label[contains(text(),'Own')]")
	private WebElement dropDown_coApplicantHousingType;
	
	@FindBy(xpath="//*[contains(text(),'Continue')]")
	private WebElement button_continueApplication;
	
	@FindBy(xpath="//*[contains(text(),'Use Existing Account')]")
	private WebElement button_useExistingAccount;
	
	@FindBy(xpath="//*[text()='Applicant Details']")
	public WebElement text_applicantDetails;
	
	@FindBy(id="printSignaturePages")
	private WebElement link_printSignaturePages;
	
	@FindBy(id="printfulSignaturePages")
	private WebElement link_printfullApplication;
	
	@FindBy(xpath="//input[@id='checkbox']/following-sibling::span[1]")
	private WebElement select_iCertifyCheckBox;
	
	@FindBy(id="normalNext")
	private WebElement button_normalNext;
	
	@FindBy(id="universalNext")
	private WebElement button_universalNext;
	
	@FindBy(xpath="//div[@id='sigFullPdfDiv']/div")
	private WebElement window_fullAppPdfWindow;
	
	@FindBy(xpath="//div[@id='sigPdfDiv']/div")
	private WebElement window_sigPagesPdfWindow;
	
	@FindBy(xpath="//*[contains(text(),'APPROVED')]")
	private WebElement text_approveheader;
	
	@FindBy(id="printContent")
	private WebElement text_printContent;
	
	@FindBy(id="reCheckBtnValidation")
	private WebElement button_search;
	
	@FindBy(id="myTable")
	private WebElement table_integratedAppsTable;

	@FindBy(id="status")
	private WebElement text_status;
	
	@FindBy(xpath="//table[@id='myTable']/tbody/tr[1]/td[2]/span")
	private WebElement text_applicationKey;
	
	@FindBy(xpath="//*[@id='appNameDiv']/label")
	public WebElement text_appNameLabel;
	
	@FindBy(xpath="//*[@id='appNameDiv']/div")
	public WebElement text_appName;
	
	@FindBy(xpath="//*/div[1]/div[@id='AccNumbrDiv']/label")
	public WebElement text_accNumLabel;
	
	@FindBy(xpath="//*/div[1]/div[@id='AccNumbrDiv']/div")
	public WebElement text_accNum;
	
	@FindBy(xpath="//*[@id='AppDateDiv']/label")
	public WebElement text_appDateLabel;
	
	@FindBy(xpath="//*[@id='AppDateDiv']/div")
	public WebElement text_appDate;
	
	@FindBy(xpath="//*/div[2]/div[@id='AccNumbrDiv']/label")
	public WebElement text_creditLimitLabel;
	
	@FindBy(xpath="//*/div[2]/div[@id='AccNumbrDiv']/div")
	public WebElement text_creditLimit;
	
	@FindBy(xpath="//*/div[@id='applicantKeyDiv']/label")
	public WebElement text_appKeyLabel;
	
	@FindBy(xpath="//*/div[@id='applicantKeyDiv']/div")
	public WebElement text_appKey;
	
	@FindBy(xpath="//*/div[@id='merchantNbrDiv']/label")
	public WebElement text_merchantNoLabel;
	
	@FindBy(xpath="//*/div[@id='merchantNbrDiv']/div")
	public WebElement text_merchantNo;
	
	@FindBy(xpath="//div[@class='row']/div[7]/label")
	public WebElement text_originLabel;
	
	@FindBy(xpath="//div[@class='row']/div[7]/div")
	public WebElement text_origin;
	
	@FindBy(id="applyApproveSubmit")
	public WebElement button_applyApproveSubmit;
	
	@FindBy(id="applyApproveReturnToList")
	public WebElement button_applyApproveReturnToList;
	
	@FindBy(xpath="//*/span[contains(text(),'signed')]")
	public WebElement text_disclaimerVerbiage;
	
		public void  applySubmitNewApplication(String testcaseName, String applyFirstName,String applyLastName,String applyZipCode ) throws IOException
	{
	try {		
			//String[] testdat=data.split(";");
			Thread.sleep(2000);
			Assert.assertTrue(button_submitNewApp.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			input_applyFname.clear();
			input_applyFname.sendKeys(applyFirstName);	
			Log.info("FirstName entered successfully.");
			input_applyLname.clear();
			input_applyLname.sendKeys(applyLastName);	
			Log.info("LastName entered successfully.");
			input_applyZip.clear();
			input_applyZip.sendKeys(applyZipCode);	
			Log.info("ZipCode entered successfully.");
			OTR.addscreenlogupdateOTR(driver,"FName, Lname and Zipcode has been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_next.click();
			Log.info("Clicked on Next button successfully.");
			Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Next button", "Pass");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Reporter.log("Issue in entering data on TMS Apply page");
			Log.info("Failed to enter data on TMS Apply Page");
			Assert.fail("Error occured in entering data on TMS Apply page.");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			driver.quit();
		}
		catch (Throwable e) 
		{
			e.printStackTrace();
			Reporter.log("Issue in entering data on TMS Apply page");
			Log.info("Failed to enter data on TMS Apply Page");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	
	public void validateApplySubmitNewApplication(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(button_submitNewApp.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			Assert.assertTrue(input_applyFname.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			Assert.assertTrue(input_applyLname.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			Assert.assertTrue(input_applyZip.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			OTR.addscreenlogupdateOTR(driver,"FName, Lname and Zipcode fields are displayed ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_next.click();
			Log.info("Clicked on Next button successfully.");
			Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Next button", "Pass");
		} 
		catch (Exception e) 
		{
			Reporter.log("Issue in entering data on TMS Apply page");
			Log.info("Failed to validate TMS Apply Page");
			Assert.fail("Error occured in entering data on TMS Apply page.");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			driver.quit();
		}
		catch (Throwable e) 
		{
			Reporter.log("Issue in entering data on TMS Apply page");
			Log.info("Failed to validate TMS Apply Page");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	public void applyApplicantInformation(String testcaseName, String estimatedFee, String dob, String ssn, String monthlyIncome) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(text_applicantInformation.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			input_estimatedFee.clear();
			input_estimatedFee.sendKeys(estimatedFee);
			logger.log(LogStatus.PASS,estimatedFee+" value set to EstimatedFee");
			Log.info("EstimatedFee is set");
			input_dateOfBirth.clear();
			input_dateOfBirth.sendKeys(dob);	
			Log.info("DOB is set");
			logger.log(LogStatus.PASS,dob+" value set to DOB");
			input_ssn.sendKeys(ssn);	
			logger.log(LogStatus.PASS,ssn+" value set to SSN");
			Log.info("SSN is set");
			dropDown_housingType.click();
			logger.log(LogStatus.PASS,"Housing Type is selected");
			Log.info("Housing Type is selected");
			input_monthlyNetIncome.sendKeys(monthlyIncome);
			Log.info("monthlyIncome is set");
			logger.log(LogStatus.PASS,monthlyIncome+" value set to MonthlyIncome");
			OTR.addscreenlogupdateOTR(driver,"All Required fields has been entered for Primary Applicant.", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");
			button_applyToNext.click();
			Log.info("Clikcked on Next Button");
			logger.log(LogStatus.PASS,"Clikcked on Next Button");
			Thread.sleep(1000);
			
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on Apply page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Apply page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on Apply page");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public  void applyApplicantInformationWithCoApplicant(String testcaseName, String estimatedFee,String dob, String ssn,String homePhone,
			String mailingAddress, String zipCode, String city,String state, String monthlyIncome,
			String coApplicantFirstName, String coApplicantLastName, String coApplicantDOB,String coApplicantSSN,
			String coApplicantHomePhone,String coApplicantEmail, String coApplicantMonthlyIncome) throws IOException
	{
	try {		
			Thread.sleep(2000);
			
			Assert.assertTrue(text_applicantInformation.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			input_estimatedFee.clear();
			input_estimatedFee.click();
			input_estimatedFee.sendKeys(estimatedFee);
			Log.info("EstimatedFee is set");
			logger.log(LogStatus.PASS,estimatedFee+" value set to EstimatedFee");
			input_dateOfBirth.clear();
			input_dateOfBirth.sendKeys(dob);
			Log.info("DOB is set");
			logger.log(LogStatus.PASS,dob+" value set to DOB");
			input_ssn.clear();
			input_ssn.sendKeys(ssn);
			logger.log(LogStatus.PASS,ssn+" value set to SSN");
			Log.info("SSN is set");
			input_homePhone.clear();
			input_homePhone.sendKeys(homePhone);
			logger.log(LogStatus.PASS,homePhone+" value set to HomePhone");
			Log.info("HomePhone is set");
			input_mailingAddr.clear();
			input_mailingAddr.sendKeys(mailingAddress);
			Log.info("mailingAddress is set");
			logger.log(LogStatus.PASS,mailingAddress+" value set to MailingAddress");
			input_zipCode.clear();
			input_zipCode.sendKeys(zipCode);
			Log.info("zipCode is set");
			logger.log(LogStatus.PASS,zipCode+" value set to ZipCode");
			input_city.clear();
			input_city.sendKeys(city);
			Log.info("City is set");
			logger.log(LogStatus.PASS,city+" value set to City");
			//applyPage.getSelectStates().clear();
			WebDriverReusableMethods.selecDropDown(dropDown_selectStates, state, "text");
			logger.log(LogStatus.PASS,state +" value set to State");
			Log.info("State is set");
			dropDown_housingType.click();
			logger.log(LogStatus.PASS,"Clicked on Housing Type");
			Log.info("Housing Type is selected");
			input_monthlyNetIncome.sendKeys(monthlyIncome);
			Log.info("monthlyIncome is set");
			logger.log(LogStatus.PASS,monthlyIncome+" value set to MonthlyIncome");
			OTR.addscreenlogupdateOTR(driver,"All Required fields has been entered for Primary Applicant. ", "Pass");
			dropDown_coApplyCheckBox.click();
			logger.log(LogStatus.PASS,"Co-Applicant Checkbox is selected");
			input_coApplicantFName.sendKeys(coApplicantFirstName);
			Log.info("coApplicantFirstName is set");
			logger.log(LogStatus.PASS,coApplicantFirstName+" value set to CoApplicantFirstName");
			input_coApplicantLName.sendKeys(coApplicantLastName);
			Log.info("CoApplicantLastName is set");
			logger.log(LogStatus.PASS,coApplicantLastName+" value set to CoApplicantLastName");
			input_coApplicantDOB.sendKeys(coApplicantDOB);
			Log.info("CoApplicantDOB is set");
			logger.log(LogStatus.PASS,coApplicantDOB+" value set to CoApplicantDOB");
			input_coApplicantSSN.sendKeys(coApplicantSSN);
			Log.info("CoApplicantSSN is set");
			logger.log(LogStatus.PASS,coApplicantSSN+" value set to CoApplicantSSN");
			input_coApplicantHomePhone.sendKeys(coApplicantHomePhone);
			Log.info("CoApplicantHomePhone is set");
			logger.log(LogStatus.PASS,coApplicantHomePhone+" value set to CoApplicantHomePhone");
			
			input_coApplicantEmail.sendKeys(coApplicantEmail);
			Log.info("CoApplicantEmail is set");
			logger.log(LogStatus.PASS,coApplicantEmail+" value set to CoApplicantEmail");
			dropDown_coApplicantHousingType.click();
			Log.info("CoApplicant Housing Type is selected");
			logger.log(LogStatus.PASS,"Housing Type is selected");
			input_coApplicantMontlyIncome.sendKeys(coApplicantMonthlyIncome);
			Log.info("CoApplicantMonthlyIncome is set");
			logger.log(LogStatus.PASS,coApplicantMonthlyIncome+" value set to CoApplicantMonthlyIncome");
			OTR.addscreenlogupdateOTR(driver,"All Required fields has been entered for Co Applicant. ", "Pass");
			button_applyToNext.click();
			Log.info("Clicked on Next Button");
			logger.log(LogStatus.PASS,"Clicked on Next Button");
			Thread.sleep(1000);		
			button_continueApplication.click();
			Log.info("Clicked on Continue Application Button");
			logger.log(LogStatus.PASS,"Clicked on Continue Application Button");	
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on Apply page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Apply page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on Apply page");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public void applyReviewAndSubmit(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(text_applicantDetails.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Applicant Details are displayed for reviewing", "Pass");
			WebDriverReusableMethods.pageScroll(driver, link_printfullApplication);
			link_printfullApplication.click();
			Log.info("Clicked on Print Full Application Link");
			logger.log(LogStatus.PASS,"Clicked on Print Full Application Link");
			Thread.sleep(1000);
			Assert.assertTrue(text_printContent.isDisplayed(),"Print content is not displayed.");
			Assert.assertTrue(window_fullAppPdfWindow.isDisplayed(),"PDF window is not displayed.");
			OTR.addscreenlogupdateOTR(driver,"Clicked on Print Full Application link", "Pass");
			WebDriverReusableMethods.pageScroll(driver, select_iCertifyCheckBox);
			select_iCertifyCheckBox.click();
			Log.info("I Certify checkbox is selected");
			logger.log(LogStatus.PASS,"I Certify checkbox is selected");
			OTR.addscreenlogupdateOTR(driver,"Reviewed Account Details", "Pass");
			button_normalNext.click();
			Log.info("Clicked on Next Button");
			logger.log(LogStatus.PASS,"Clicked on Next Button");
			Thread.sleep(1000);		
			
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());	
			Log.info("Failed to enter data on TMS Apply page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Apply page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public  void applyUniversalReviewAndSubmit(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(text_applicantDetails.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Applicant Details are displayed for reviewing", "Pass");
			WebDriverReusableMethods.pageScroll(driver, link_printfullApplication);
			link_printfullApplication.click();
			Log.info("Clicked on Print Full Application Link");
			logger.log(LogStatus.PASS,"Clicked on Print Full Application Link");
			Thread.sleep(1000);
			Assert.assertTrue(text_printContent.isDisplayed(),"Print content is not displayed.");
			Assert.assertTrue(window_fullAppPdfWindow.isDisplayed(),"PDF window is not displayed.");
			OTR.addscreenlogupdateOTR(driver,"Clicked on Print Full Application link", "Pass");
			WebDriverReusableMethods.pageScroll(driver, select_iCertifyCheckBox);
			select_iCertifyCheckBox.click();
			Log.info("I Certify Checkbox is selected");
			logger.log(LogStatus.PASS,"I Certify Checkbox is selected");
			OTR.addscreenlogupdateOTR(driver,"Reviewed Account Details", "Pass");
			button_universalNext.click();
			Log.info("Clicked on Universal Next Button");
			logger.log(LogStatus.PASS,"Clicked on Universal Next Button");
			Thread.sleep(1000);		
			
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Apply page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Apply page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	public void applyResult(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
				
			Assert.assertTrue(text_approveheader.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Apply Approved Result page is displayed", "Pass");
			WebDriverReusableMethods.pageScroll(driver, link_printSignaturePages);
			//WebDriverWait wait=new WebDriverWait(driver,20);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("printSignaturePages")));
			link_printSignaturePages.click();
			Log.info("Clicked on Print Signature Pages link");
			logger.log(LogStatus.PASS,"Clicked on Print Signature Pages link");
			Thread.sleep(3000);
			Assert.assertTrue(text_printContent.isDisplayed(),"Print Content is not displayed");
			OTR.addscreenlogupdateOTR(driver,"Clicked on Print Signature Pages link", "Pass");
			Assert.assertTrue(window_sigPagesPdfWindow.isDisplayed(),"Print Signature Pages PDF is not displayed");
			OTR.addscreenlogupdateOTR(driver,"Print Signature Pages PDF is displayed", "Pass");
			link_printfullApplication.click();	
			Log.info("Clicked on Print Full Application link");
			logger.log(LogStatus.PASS,"Clicked on Print Full Application link");
			Thread.sleep(2000);
			Assert.assertTrue(text_printContent.isDisplayed(),"Print Content is not displayed");
			OTR.addscreenlogupdateOTR(driver,"Clicked on Print Full Application link", "Pass");
			Assert.assertTrue(window_fullAppPdfWindow.isDisplayed(),"Print Full Application PDF is not displayed");
			OTR.addscreenlogupdateOTR(driver,"Print Full Application PDF is displayed", "Pass");
						
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Apply page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Apply page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public void applyUniversalApprovedResult(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
			
			Assert.assertTrue(text_approveheader.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Apply Universal Approved Result page is displayed", "Pass");
			//WebDriverReusableMethods.pageScroll(driver, applyPage.link_printfullApplication);
			Assert.assertFalse(link_printSignaturePages.isDisplayed(),"Print Signature Pages link is displayed");
			link_printfullApplication.click();
			Log.info("Clicked on Print Full Application link");
			logger.log(LogStatus.PASS,"Clicked on Print Full Application link");
			Thread.sleep(2000);
			Assert.assertTrue(text_printContent.isDisplayed(),"Print Content is not displayed");
			OTR.addscreenlogupdateOTR(driver,"Clicked on Print Full Application link", "Pass");
			Assert.assertTrue(window_fullAppPdfWindow.isDisplayed(),"Print Full Application PDF is not displayed");
			OTR.addscreenlogupdateOTR(driver,"Print Full Application Pages PDF is displayed", "Pass");
						
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Apply page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Apply page.");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public void applyCheckApplicationStatus(String testcaseName) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(button_checkAppStatus.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			OTR.addscreenlogupdateOTR(driver,"Redirected to Apply Page", "Pass");
			button_checkAppStatus.click();
			Log.info("Clicked on Check App Status");
			logger.log(LogStatus.PASS,"Clicked on Check App Status");
			Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Check Application Status", "Pass");
			button_search.click();
			Log.info("Clicked on Search Button");
			logger.log(LogStatus.PASS,"Clicked on Search Button");
			WebDriverReusableMethods.pageScroll(driver,table_integratedAppsTable);
			Assert.assertTrue(table_integratedAppsTable.isDisplayed(),"Integrated applications table is not displayed.");
			OTR.addscreenlogupdateOTR(driver,"Integrated applications table is displayed.", "Pass");
			int rowSize=driver.findElements(By.xpath("//*[@id='resntrns']/tr")).size();
			for(int rowIeration=1;rowIeration<=rowSize;rowIeration++)
			{
				String status=driver.findElement(By.xpath("//*[@id='resntrns']/tr/td[4]/span")).getText();
				if(status.equalsIgnoreCase("Approved"))
				{
					text_applicationKey.click();
					Log.info("Clicked on ApplicationKey link");
					logger.log(LogStatus.PASS,"Clicked on ApplicationKey link");
					Thread.sleep(1000);
					break;
				}
				
			}
			
			OTR.addscreenlogupdateOTR(driver,"Clicked on Application Key to Navigate to Decision Page", "Pass");
		} 
		catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on Apply page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Apply page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Apply page.");
			driver.quit();
		}
		catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or check the internet connection.");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}

}
