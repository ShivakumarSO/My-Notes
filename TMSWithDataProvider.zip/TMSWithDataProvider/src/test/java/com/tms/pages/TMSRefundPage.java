package com.tms.pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.tms.baseclass.BaseClass;
import com.tms.utilities.Log;
import com.tms.utilities.OTR;
import com.tms.utilities.WebDriverReusableMethods;

public class TMSRefundPage extends BaseClass {


	public TMSRefundPage(WebDriver driver) 
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
		
	@FindBy(partialLinkText="Look Up Account by SSN")
	private WebElement link_lookupAccountBySsnAndZip;

	@FindBy(id="ssnNbr")
	private WebElement input_ssnNumber;
	
	@FindBy(id="zipCode")
	private WebElement input_zipCode;	
	
	@FindBy(partialLinkText="Look Up Account by Name")
	private WebElement link_lookupAccountByNameAndPhone;
	
	@FindBy(id="chFname")
	private WebElement input_clientFirstName;
	
	@FindBy(id="chLname")
	private WebElement input_clientLastName;
	
	@FindBy(id="chPhone")
	private WebElement input_clientHomePhone;
	
	@FindBy(id="refndbtn")
	private WebElement button_processRefund;
	
	@FindBy(partialLinkText="Enter Account Number")
	private WebElement link_lookupByAccountNumber;
	
	@FindBy(id="accountNumber")
	private WebElement input_accountNumber;
	
	@FindBy(id="validateBtn")
	private WebElement button_next;
	
	@FindBy(id="estimatedFee")
	private WebElement input_refundAmount;
	
	@FindBy(xpath="//*[@href='#CareCredit']")
	private WebElement link_careCredit;
	
	@FindBy(xpath="//div/input[@class='months']/following-sibling::label/span[contains(text(),'6 month')]")
	private WebElement dropDown_promoMonth;
	
	@FindBy(id="practiceMemo")
	private WebElement input_practiceMemo;
	
	@FindBy(id="submitRefund")
	private WebElement button_submitTransaction;
	
	@FindBy(xpath="//div[@class='main-container refund']/div/div[2]/div[2]/strong")
	private WebElement text_refundComplete;
	
	@FindBy(xpath="//div[@class='pdf-div']")
	private WebElement pdf_pdfWindow;
	
	@FindBy(xpath="//button[contains(text(), 'Print Receipt')]")
	private WebElement  button_printReceipt;

	public void refundLookupAccountBySSNandZip(String testcaseName, String purchaseAmount, String ssn, String zipCode) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(input_refundAmount.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			input_refundAmount.clear();
			input_refundAmount.sendKeys(purchaseAmount);	
			Log.info("PurchaseAmount is set");
			logger.log(LogStatus.PASS,purchaseAmount+" value set to PurchaseAmount");	
			link_lookupAccountBySsnAndZip.click();
			Log.info("Clicked on LookupAccount By SSN and Zip");
			logger.log(LogStatus.PASS,"Clicked on LookupAccount By SSN and Zip");	
			input_ssnNumber.sendKeys(ssn);
			Log.info("SSN is set");
			logger.log(LogStatus.PASS,ssn+" value set to SSN");	
			input_zipCode.clear();
			input_zipCode.sendKeys(zipCode);
			Log.info("ZipCode is set");
			logger.log(LogStatus.PASS,zipCode+" value set to ZipCode");	
			
			OTR.addscreenlogupdateOTR(driver,"SSN and ZipCode has been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_next.click();
			Log.info("Clicked on Next");
			logger.log(LogStatus.PASS,"Clicked on Next");	
			OTR.addscreenlogupdateOTR(driver,"Clicked on Next button. ", "Pass");
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Refund page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Refund page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Refund page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	public void refundLookupAccountByNameandPhone(String testcaseName, String refundAmount, String clientFirstName, String clientLastName
			, String clientHomePhone) throws IOException
	{
	try {		
			Thread.sleep(2000);
			
			Assert.assertTrue(input_refundAmount.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			input_refundAmount.clear();
			input_refundAmount.sendKeys(refundAmount);
			Log.info("RefundAmount is set");
			logger.log(LogStatus.PASS,refundAmount+" value set to RefundAmount");	
			link_lookupAccountByNameAndPhone.click();
			Log.info("Clicked on LookupAccount by Name and Phone");
			logger.log(LogStatus.PASS,"Clicked on LookupAccount by Name and Phone");	
			input_clientFirstName.clear();
			input_clientFirstName.sendKeys(clientFirstName);
			Log.info("clientFirstName is set");
			logger.log(LogStatus.PASS,clientFirstName+" value set to FirstName");	
			input_clientLastName.clear();
			input_clientLastName.sendKeys(clientLastName);
			Log.info("clientLastName is set");
			logger.log(LogStatus.PASS,clientLastName+" value set to LastName");	
			input_clientHomePhone.clear();
			input_clientHomePhone.sendKeys(clientHomePhone);	
			Log.info("clientHomePhone is set");
			logger.log(LogStatus.PASS,clientHomePhone+" value set to HomePhone");	
			
			OTR.addscreenlogupdateOTR(driver,"FName, Lname and PhoneNo has been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_next.click();
			Log.info("RefundAmount is set");
			logger.log(LogStatus.PASS,"Clicked on Next");
			OTR.addscreenlogupdateOTR(driver,"Clicked on Next button. ", "Pass");
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Refund page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Refund page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Refund page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	public void refundEnterAccountNumber(String testcaseName, String accountNumber) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(link_lookupByAccountNumber.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			input_accountNumber.click();
			input_accountNumber.sendKeys(accountNumber);
			Log.info("AccountNumber is set");
			logger.log(LogStatus.PASS,accountNumber+" value set to AccountNumber");	
			OTR.addscreenlogupdateOTR(driver,"Account Number has been entered", "Pass");
			button_next.click();
			Log.info("Clicked on Next button");
			logger.log(LogStatus.PASS,"Clicked on Next button");	
			Thread.sleep(1000);
			OTR.addscreenlogupdateOTR(driver,"Clicked on Next button", "Pass");
			
					} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Refund page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Refund page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Refund page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}

	public void refundAmountAndFinancing(String testcaseName, String refundAmount,String practiceMemo) throws IOException
	{
	try {		
			Thread.sleep(2000);
						
			Assert.assertTrue(input_refundAmount.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			
			input_refundAmount.clear();
			input_refundAmount.sendKeys(refundAmount);
			Log.info("RefundAmount is set");
			logger.log(LogStatus.PASS,refundAmount+" value set to RefundAmount");	
			link_careCredit.click();
			Log.info("Clicked on careCredit link");
			logger.log(LogStatus.PASS,"Clicked on careCredit link");	
			dropDown_promoMonth.click();
			Log.info("Promo Month is selected");
			logger.log(LogStatus.PASS,"Promo Month is selected");	
			input_practiceMemo.clear();
			input_practiceMemo.sendKeys(practiceMemo);
			Log.info("PracticeMemo is set");
			logger.log(LogStatus.PASS,practiceMemo+" value set to PracticeMemo");	
			OTR.addscreenlogupdateOTR(driver,"All required fields have been entered. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
			button_submitTransaction.click();
			Log.info("Clicked on Subumit Transaction button");
			logger.log(LogStatus.PASS,"Clicked on Sbumit Transaction button");	
			OTR.addscreenlogupdateOTR(driver,"Clicked on Submit Transaction button. ", "Pass");
			Thread.sleep(1000);
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Refund page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Refund page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Refund page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
	public void refundComplete(String testcaseName) throws IOException
	{
	try {		
			
			Thread.sleep(4000);
									
			Assert.assertTrue(text_refundComplete.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			Assert.assertTrue(button_printReceipt.isDisplayed(),"Application is not launched properly or Downtime or Internet Connection.");
			Assert.assertTrue(pdf_pdfWindow.isDisplayed(), "PDF Window is not displayed.");
			
			OTR.addscreenlogupdateOTR(driver,"Refund Complete Page web elements are validated. ", "Pass");
			//OTR.captureupdateOTR(driver, "The username and password has been entered."," Pass",stepNum++,screenshotFolder);	
			//logger.log(LogStatus.PASS, "The username and password has been entered.");		
					
		} 
	catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Failed to enter data on TMS Purchase page");
			OTR.addscreenlogupdateOTR(driver,"Error occured in entering data on TMS Purchase page", "Fail");
			OTR.saveOTR(testcaseName);
			e.printStackTrace();
			Assert.fail("Error occured in entering data on TMS Refund page");
			driver.quit();
		}
	catch (Throwable e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
			Log.info("Application is not launched properly or Downtime or Internet Connection");
			OTR.addscreenlogupdateOTR(driver,"Application is not launched properly or Downtime or Internet Connection.", "Fail");
			OTR.saveOTR(testcaseName);
			Assert.fail("Application is not launched properly or Downtime or Internet Connection.");
			driver.quit();
		}
	}
	
		
}
