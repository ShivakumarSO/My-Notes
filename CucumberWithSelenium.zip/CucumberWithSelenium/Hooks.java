package com.cucumber.step;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import com.cucumber.runner.RunnerTest;
import com.cucumber.utility.ExcelUtility;
import com.cucumber.utility.GenericUtilities;
import com.cucumber.utility.HtmlSummaryReport;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks extends RunnerTest {	 
	//Executes Before Test Execution
	@Before
	public void cucumberBefore(Scenario scenario){
		 System.out.println("This will run before the Scenario");
		 gu =new GenericUtilities();
		 document=new XWPFDocument();
		 StartTime_TestExecution=System.currentTimeMillis();
		 String ScenarioName = scenario.getName();
		 String[] ScenarioNameArr = ScenarioName.split("_");
		 String TCName = ScenarioNameArr[0];
		 String[] scenarionamearr = ScenarioName.split(":");
		 TC_Name = scenarionamearr[0];
		 gu.createOTR(document, TCName, ScenarioName);
		 logger.info("--------------------------------------------------------------------------");
		 logger.info(ScenarioName);
    }	
	//Executes After Test Execution
	@After
	public void cucumberAfter(Scenario scenario) throws IOException, InvalidFormatException, InterruptedException{
		if (!(Boolean.parseBoolean(System.getProperty("headless")))) {
		System.out.println(scenario.getStatus());
		System.out.println("This will run after the Scenario");
         ex=new ExcelUtility();
		 SimpleDateFormat df = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		 Date today;
         String reportDate;
		 today = Calendar.getInstance().getTime();
		 reportDate = df.format(today);
		 String ScenarioName = scenario.getName();
		 String[] ScenarioNameArr1 = ScenarioName.split(":");
	     String TC_Name = ScenarioNameArr1[0];
	     String[] Storyids = TC_Name.split("-");
	     String TCName=Storyids[1];
	     String Story_ids=Storyids[0];
	     String[] scenarioname =ScenarioName.split("\\*");
	     ScenarioName=scenarioname[0];

		 TestCounter=TestCounter+1;
		 String testendtime=HtmlSummaryReport.EndTimer(StartTime_TestExecution);
		 if(CloudExecution.equalsIgnoreCase("yes")) {
			 Executedin="Saucelab Link";
			 Saucelablink="https://app.saucelabs.com/tests/"+sessionId;
		 }
		 else { Executedin="Local Exection";Saucelablink="";}
		 if (scenario.isFailed()) {
		     byte[] screenshot =  ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		     File destinationPath = new File(failScreenPrints+"\\"+ScreenshotCounter+ ".png");
		     Thread.sleep(5000);
			 FileUtils.writeByteArrayToFile(destinationPath,screenshot);	
			 Thread.sleep(5000);
		     HtmlSummaryReport.ReportGen_Status(ScreenshotCounter,"",FailedAt,ExceptionName,ExceptionMessage,"FAIL");//hs.ReportGen_Status(ScreenshotCounter,exceptionName,"FAIL");		     
		     HtmlSummaryReport.updateSummary(TestCounter,Story_ids,Platform_login,BrowserType+" "+BrowserVersion,ScenarioName,Executedin,Saucelablink,"Fail",testendtime);
		     FailTestCounter=FailTestCounter+1;
		 }
		 else {
			 byte[] screenshot =  ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		     File destinationPath = new File(passScreenPrints+"\\"+ScreenshotCounter+ ".png");
		     Thread.sleep(5000);
			 FileUtils.writeByteArrayToFile(destinationPath,screenshot);
			 Thread.sleep(5000);
			 HtmlSummaryReport.ReportGen_Status(ScreenshotCounter,ScenarioDescription,FailedAt,ExceptionName,ExceptionMessage,"PASS");
			 HtmlSummaryReport.updateSummary(TestCounter,Story_ids,Platform_login,BrowserType+" "+BrowserVersion,ScenarioName,Executedin,Saucelablink,"Pass",testendtime);
			 PassTestCounter=PassTestCounter+1;
		 }
		 ScreenshotCounter=1;
		 FailedAt=ExceptionName=ExceptionMessage="";
		 driver.quit();
		 //gu.killdriverprocess(BrowserType);
		 try {
				if(BrowserType.equalsIgnoreCase("Chrome") && CloudExecution.equalsIgnoreCase("no")) {
					 Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
				 }
				 else if(BrowserType.equalsIgnoreCase("Firefox") && CloudExecution.equalsIgnoreCase("no")) {
					 Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe"); 
				 }
				 else if(BrowserType.equalsIgnoreCase("IE") && CloudExecution.equalsIgnoreCase("no"))  {
					 Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe"); 
				 }
				}
			catch(Exception e) {
				System.out.println("Unabel to kill driver process");
				//gu.Parseexception(e);
				logger.info(e.getMessage());
			}
		 
		 gu =new GenericUtilities();
		 scenario.getStatus().toString().equalsIgnoreCase("failed");
		 if(scenario.getStatus().toString().equalsIgnoreCase("failed")){
		 gu.captureupdateOTR(driver, document,FailedAt );
		 Thread.sleep(2000);
		 }
		 gu.updatestatusOTR(document, scenario.getStatus().toString());
		 
		 String[] Name=scenario.getName().split(":");
		 String os = System.getProperty("os.name").toLowerCase();
		 if(os.contains("mac")) {
			 gu.saveOTR(OTRLocationMac+Name[0]+"_"+reportDate+".docx", document);
		 }else {
		 gu.saveOTR(OTRLocation+Name[0]+"_"+reportDate+".docx", document);
		 }
		 
		 int Count=ex.getRowCount(ExcelLocation, "Detailed");
		 ex.writeStringValueIntoExcel_CreateRow(ExcelLocation, "Detailed", Count, 0, Name[0]);
		 ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 1,Name[1]); //scenario.getName()
		 
		 if(os.contains("mac")) {
			 ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 2, OTRLocationMac+Name[0]+"_"+reportDate+".docx");
		 }else {
			 ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 2, OTRLocation+Name[0]+"_"+reportDate+".docx");
		 }
		 ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 3, scenario.getStatus().toString());
		 if(scenario.getStatus().toString().equalsIgnoreCase("failed")){
			 ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 4, ScenarioDescription); 
		 }
		 else
		 {
			ex.writeStringValueIntoExcel_getRow(ExcelLocation, "Detailed", Count, 4, "N/A");
		 }
	}
		
		if(CloudExecution.equalsIgnoreCase("yes")) {
			String jobName = scenario.getName();
			RunnerTest.UpdateResults(USERNAME, ACCESS_KEY, !scenario.isFailed(), sessionId, jobName);
			System.out.println("SauceOnDemandSessionID="+ sessionId + "job-name="+ jobName);
			scenario.write("SauceOnDemandSessionID="+ sessionId + "job-name="+ jobName);
			}
	}	 
}
