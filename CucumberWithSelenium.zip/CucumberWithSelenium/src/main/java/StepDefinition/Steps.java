package StepDefinition;	

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;		
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		

public class Steps {				

    WebDriver driver;	
    public static HashMap<String, String> testdataHashMap;
    public static FileInputStream fi=null;
	public static Workbook wb = null;
	public static FileOutputStream fo=null;
    		
    @Given("^Open the chrome and launch the application and fetch data from excel (\\d+)$")				
    public void open_the_Firefox_and_launch_the_application(int rowcount) throws Throwable							
    {		
    	testdataHashMap = getDataFromExcel(System.getProperty("user.dir")+"\\Resources\\testdata\\TestDataSheet.xlsx",
				"Sheet1", 0, rowcount);	
       System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Resources\\Drivers\\chromedriver.exe");
	   ChromeOptions chromeOptions = new ChromeOptions();
	   chromeOptions.setExperimentalOption("useAutomationExtension", false);
	   driver =new ChromeDriver(chromeOptions);			
       driver.manage().window().maximize();			
       driver.get("https://rqconsumercenter.mysynchrony.com/consumercenter/");					
    }		
    @Given("^Enter username and password$")
    public void enter_the_Username_and_Password() throws Throwable 							
    {		
    	WebElement Username = driver.findElement(By.xpath("//*[contains(@id,'LoginusernameId')]"));
		Username.sendKeys(testdataHashMap.get("username"));	
		WebElement Password = driver.findElement(By.xpath("//*[contains(@id,'LoginpasswordId')]"));
		Password.sendKeys(testdataHashMap.get("password"));	
		Thread.sleep(1000);
		WebElement Login = driver.findElement(By.xpath("//*[contains(@id,'loginSubmit')]"));
		Login.click();	
		Thread.sleep(10000);
		WebElement SecQWE = driver.findElement(By.xpath("//*[contains(@class,'algn-lft')]"));
		WebElement SecQA = driver.findElement(By.id("securityAns"));
		String SecQ = SecQWE.getText();
		String AnswerQ;
		if(SecQ.contains("mother")) {
			AnswerQ = "mother";
        }
        else if(SecQ.contains("teacher")) {
        	AnswerQ = "teacher";

        }
        else {
        	AnswerQ = "wedding";
        }
		SecQA.sendKeys(AnswerQ);

		WebElement SecContinue  = driver.findElement(By.id("remindme"));
		SecContinue.click();
    }			
    @And("^Verify home page is displayed")
    public void verity_homepage() {
    	WebElement WelcomeMsg = driver.findElement(By.xpath("//*[text() = 'Welcome,']"));
    	if(WelcomeMsg.isDisplayed()){
			Assert.assertTrue(WelcomeMsg.isDisplayed());
		}else {
			Assert.fail("Error Page is Displayed");
		}
    }
    @And("^Goto Payment Page")
    public void Goto_Payment_Page() throws InterruptedException {
    	WebElement Paymentbutton = driver.findElement(By.xpath("//*[contains(text(),'Make Payment')]"));
    	Paymentbutton.click();
    	Thread.sleep(1000);
    
    	WebElement PaymentHeader = driver.findElement(By.xpath("//*[contains(text(),'Make a Single Payment')]"));
    	WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOf(PaymentHeader));
    	if(PaymentHeader.isDisplayed()){
			Assert.assertTrue(PaymentHeader.isDisplayed());
		}else {
			Assert.fail("Error Page is Displayed");
		}
    }
    @Then("^Logout from the application$")					
    public void Reset_the_credential() throws Throwable 							
    {		
       	WebElement Logout = driver.findElement(By.xpath("//*[text() = 'Logout']"));
       	Logout.click();
       	Thread.sleep(1000);
       	WebElement Loginnow = driver.findElement(By.xpath("//*[contains(text(),'LOG IN NOW')]"));
       	WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOf(Loginnow));
       	Loginnow.click();
       	Thread.sleep(1000);
       	driver.quit();
    }	
    
    public  static HashMap<String, String> getDataFromExcel(String path,String sheetname, int startRow, int endRow)
	{
		HashMap< String, String> hashMap=new HashMap<String, String>();
		int cellCount;
		try {
			fi=new FileInputStream(path);
			wb = WorkbookFactory.create(fi);
			Sheet sh=wb.getSheet(sheetname);
			cellCount =sh.getRow(startRow).getLastCellNum();
			for (int j = 0; j < cellCount; j++) 
			{
				hashMap.put(sh.getRow(0).getCell(j).getStringCellValue().toString(), sh.getRow(endRow).getCell(j).getStringCellValue().toString());
			}
			
		} 
		catch(NullPointerException exception)
		{
			System.out.println(exception.getMessage());
		}
		catch (EncryptedDocumentException e) {
	
			System.out.println(e.getMessage());	
		} catch (InvalidFormatException e) {

			System.out.println(e.getMessage());	
		}  catch (FileNotFoundException e1) {
			
			System.out.println(e1.getMessage());
		}
		catch (IOException e) {
			System.out.println(e.getMessage());	
		}
		catch (Exception e) {
		System.out.println(e.getMessage());	
		}
		return hashMap;

	}
}		