package restassured.utilities;

import runner.Baseclass;

public class PropertyFileInitializer extends Baseclass {
	
	public void PathAndVariableInitializer(){

		
		//Application Variables
		trans_id=grefGlobalProperties.getProperty("trans_id");
		password1=grefGlobalProperties.getProperty("password1");
		black_box=grefGlobalProperties.getProperty("black_box");
			
		
	}
	
	

}
