package runner;

import java.io.IOException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
features = "src/test/java/com/cmlb2bServices/features"
,plugin = {"pretty", "html:target/cucumber-reports","json:target/cucumber-reports/cucumber.json","junit:target/cucumber-reports/cucumber.xml"}
,glue= {"hooks","com.syf.brcServices.stepdefinition"},
tags = {"@fincenflowDryRuncvxg"},
dryRun=false

)

public class RunCukesTest extends AbstractTestNGCucumberTests {
	
	static String reportType;
	@BeforeSuite
	public void TestNGBeforeSuite() throws Exception {
	Baseclass refBaseclass= new Baseclass();
	refBaseclass.globalInitialization();	
		
	}
	
	@Test(enabled = false)
	public void sample(){
		System.out.println("@Test");
	}
	
	@AfterSuite
	public void TestNGAfterSuite() throws IOException {
		
		
	}

}

