package runner;

import java.io.IOException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
features = //"src/test/java/com/syf/ignite/features"
"src/test/java/com/cmlb2bServices/features"

,plugin = {"html:target/site/cucumber-pretty","json:target/cucumber.json"}
,glue= {"hooks","com.syf.brcServices.stepdefinition"},
tags = {"@gjhfgjsgfkjdhgjhgj"}
//dryRun=false
)

public class RunCukesTest extends AbstractTestNGCucumberTests {
	
	static String reportType;
	@BeforeSuite
	public void TestNGBeforeSuite() {
	Baseclass refBaseclass= new Baseclass();
	refBaseclass.globalInitialization();	
		
	}
	
	@Test(enabled = false)
	public void sample(){
		System.out.println("@Test");
	}
	
	@AfterSuite
	public void TestNGAfterSuite() throws IOException {
		
	}

}

