package runner;

import java.text.SimpleDateFormat;
import java.util.Properties;
import org.testng.Assert;
import org.testng.Reporter;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Baseclass{
	
	//TimeStamp Initialization
	public static String gstrTimeStamp = new SimpleDateFormat("dd.MM.yyyy.HH.mm.ss").format(new java.util.Date());
			
			//Variable declaration's
			public static String gstrScenarioName;
			public static String gstrFramework_Path;
			//Object reference declaration's 
			public static Properties grefGlobalProperties;
			//Application Variables
			public static RequestSpecification gRequest;
			public static Response gResponse;
			public static String trans_id="c7d2a769-e1be-4148-be4f-ef8e5b90b7ed";
			public static String password1="S2aNDbAZzuHLJXBb9PDbbmrkc65Esbv8SXEghHsO7xKTYj+kVnPyHaT4xSo41BJDzkhhzfzLAN6dKNOBeVBuYfuYt52k7PCncT+RoFHdYlvuMYJe7kgJcu37dHie4npcEkJNqB/I2vNu77hEIhsz1LzA2xokIkoR1OjOt7dXpRWBEQXimI6JMMdZyI/JgBSA1ZhVXRc+MHTw3unEvmCNopK2IMbYC3iN1Xc+GX9I1IcXoZ3vJlwvbMpStX0nwP/J6f0Wac5amkyvuvAHudKBWqsVEZcKDc0uXwCv3/l5fn/VairQLnJhY5Uz/2GTcvFRk5nFbpe+IAmfGguHC5RCYw==";
			public static String black_box="0400HGCofuTTPwCVebKatfMjIMStSZN8bI4HYeM8cQJEI+wB7QFiDTktIk+TFy8Ptb/TWwhVXZYE70WzD1ixDLYo+pRvFCMSbl5x2njsd/l5YML0qLQS3a7zXCIWlMOpciAq95FDImR1yfFQZoFskMPi7avOi6ixuuNrlU99UoH2xklJ7J+YOq9sqfvWrm0OWGLeM/XiCiUTw7Y01KeCI/PX9XRo9tbbJBrFUBX7X6pCyS5O1Tp84e7/t/vODAiHcdOFA2ZJy8wd9z/+frQZ4NHkwomhM/l1awvJViGZ1G6owNJhFkiX39qq0PUJiL5MGqveq47UkZ7Y9+N4k+cQmG8XdktEBXEf9YkC65E4Wa8JGhV7Eu3ynnT8ts+jOwBMi/2oguKfpvYxa/FkLkBg2eXATZ0yIqAVgHi3QVLAxcmeo9Y5b+Jvw3ft+4OfhOOGBlZceD8eDcbGcRa7ZaCKYVDis2IRAfOORm5N9M5j623T/uBU8xxkp8zCs0KPAx/uKFjNMkZykwtq2krizPPVEe1uhjXdD7+KmOXp1Vys5IrmurcANfcCam4WsZtj08GLEb9WActViz5sbIcd+7udpetUEQdwKLI4UXFQ7DhmG+4WzsebGYUA7IR0r66pV303bu/Phu1dz1MZCnCHKVUDUMv4ug1uS8RVHD+ZWuMAI8SneUWFWed/y0XCmvX7TIJsqEVTs+A9qF/MXXSGQH+RwHcENQiAtkBfbf+007uM+mlMucUAVb+/xu7YUHAGyIcPoBlecKUHXX6J9kF7HVMsBHJtSq/AVGrJ6lBbiy08fE5mIlV0sOz7UkLVEd6rPtO0ffdT/jkV34k/ReoWZBamlGXoG/imnjwHY9HQtQzpGfcm0cR8X2Fd1ngNFGLDGZlWOX0jOQI0sqDutOf4pGcK05lGjruvNvEfRkJupBy3Z8hSEMHnVb7uHgXQGaoIyE60FXMq/sX1KMaXchAMgog1WtCs0kntMwDARHuVzdfxLylYBibsEVBWO8XQIqpa9NvP9z6vQUif7vGFwmKtvx1tsepzjTntEcVmW1kM3pv3lBngSakZMHwqr5fdmAob0ORrrTls2Sve5CQS7UVEMFa/sWUj2dwTidneZ5Wedvp3EOKiSx6OC0ceqoTbyG/m3Zqxt3w1Bn6LxoWOnZu64rr07LwRGXZpyc7oQIV63xadNE2jqb6o3IAEdbB+xCVNS65m83pQ+qMTRH6GRVfktuLbTBhurJZgFe1mEPo/xKZFk5ZzIuYOJpmCsVW0a79MOnRTMthLOye0as6uM6GJKSIdwO9O5fblFJ4+6NJ1s4gQZFW2ajR9j4C1IfnRrglMT+ccdoi96rpHQWJZlNFjISa+EGXhlzi93mZDBih6k3mUYdXAC+h4UOoAU575WCoX624YkZLs+wX65pHdFbAda8L6P2+mMHEOBvWXwFRHlhfvMvqj2VIuCKlqikzRYodXro5G6ZgBNYBu/nSSujC42Wc0awfXBt64xBQcCmRmHNq7cyfyesHsTU9/joi9e1h0TIw5qQXOmssqTe7WzQg67PDmZdnwAkw3A/tk8HiZsBx6w1tx0mMZz7HtmSQrKuHt39bvxE86eVaYJEF00M2dmwpFJMf4g1ead3DELWp2ig6rb+tDAzIDq4Zc/9mjbFSAFu7g0I1zyeSmTmPvDtmeZWysG5GNVi4ixCeMzU559dGxFoZVjnY6x7o612Lmxo1znntcmg8XcPnDShbowwrz6D+YNUMLEewTRhqhcaO/3E4x9btnpiwSjY7VHtzU+AGCQaJkXU7Gx9ZgVecLmZjf7F299GIR12G/cdkIMFbmjofZbR2X0CIID6FY6p00ehQugOFx8rWegR9JAaPaCBRJSkYJNTlGEHFfyZPykuFb5yk2+AuTMG7U6Jwg61/mV9hpHcb+rl9zh+Gt3qyHN5v2fO6rSYTR3sC8q3YMNkoEpnNzvdX4/Q39KX1Xn2Q9dfTPnMXx8W5JbtjVJWj8VpvagNlEDYykzrV0s0g0NkMPPNS1V2NZN3w39k6ii5pXIiW7G0pwJbyysfjniQke3xPa+f8pqRU+t+yhUc+7XhBpUjRy17eWPRi5+Xac8LmyPfODH+4a+6TBNFHre5dUzkyIulHt/EkV+GXfWgjjoM7LEgJGc5zoxLZrI6+/DV3rzuNLB/EoDbuuj3Q5EXdSDuOUA/Mwo3G+0rzfiQanp7K34TzwtUC6wFj4VNrekORK+CRPJAESoKPfa7sn6tLlYuN6/7hqsLguic1h0+9biIgxx4EnhmDqJ7AOS+kA0JZnzkgH774MkzCjHmsOmgVABxpxJr9b8OB+MlmyLvO9pALJ926OdGHzd/TSAhxNFsI0S14DS2MdnqgkI49BaCyT4Z+o6pOHEbAvEIw8PNpC1p/kEYFoEYZ1/YHfforNYyDtBEsUQZbp9mRxAuIZNKzWLtV9yI0lZsCQIjMoxKZa1CVQZA6Oy6roHkWOZs+Ec2frMhX2fs2NLze98N8sxt/wTLZiJKf8eMh1xSlcps6MxmvaH5fCCGsrmAPX3SrIcl8R3EpfB99r/ZbLUT/K1nViAshW7cCjMyuD+6TEo4wWZiDf2vfOEf40UKzK3gVTwtD820wIYKBoWfFwrsNHzgn0tZlrL6DhvzHqIyAmQrkUmDUb7r7VYT6SALlghH6eubjMzaOEHwRTN1L9ZHqPZtBpwDSppZcdI4qG4A57+tWCopCzXr0KVAVp+Hs5/YKayw+sOGZ8KRDtBedahhhq+3vU5rsjM+ni3euPpPH7Y73tnHwDNUtujuDcSpZAQoLLmmIdOkgyuV9zIsj5vLUxb/Lou9URtpbPB38Dp8jTMmWQaRybke54ZO1alCP9j1YD7j/Twe1H99KZv+V1o9LBMyArS/nAkKF6ruvnaR0ix+1S8rsaUgj7gmzKF1kyt2mt2EkljSR621CrFArqvvgmAvTVuZJSNXPLOzH2eTMFof6Q6XUqKg8Tc4keQ/kglcCmUGUPXmJuVVYHdFhcId+m6Jn/Exsu9UmJ6VQfCnjNpwxb34COIG3tODCV5ageBeAYUDRh54ISbfbkUbT0gzBxi0UO2zRmktL8J8V7qKU9i3wPflP7M6+kyCYv8mddz/UbC9kwFs8o8dPYXMdbVIL73E+FAtlVRTONRY6xT+kG2AAzb3RpV7uMrykYccMsXIR09ty72HdeaKoTgGu98BW0gWTSjnTXUFL2c4SZtPrcCdHWZkElanV6h8TGlhcn4ZedlLIdJfelb+Tdo36nj25lyv0HqQgSiMEzD/PqjjIgprz8kVVHVv6X71jhmRulz39K5LPWvXiM0mukNvDHd8V9NYfWHeb91uinaj076Y3VqN79yLrNwCGlLsCbv5RKUWzbIzBpa32fkARrqVwG2dqgANd8uUgw0FpOc1wmkWKtug1w5c/ZR3Q3oVI6cuPrV8QlxKaH++vf7wS3cZz04GBsAHm06cPKv+AhXE+IV+OCUuhYdG3s5BY4knRfdRjsA4/Bm/WgQZS3UjGPLSx8WHGgmjKzCrVQQdnXbtEqo6bfmw8EnH295A5xt+hcKKnNSSdSh0HVx77GKjxzZ5XBsk8NX8vuxsBLnV/NY+Ftq1J8EXOEqS2LKs2d0kDziD3CG8yK95iEy+vXmkYrwjYF7isgWZ3uOSR4hL4xQf3ULSoo7drl+Jrrj1MxKNzgzNvXbIYo3wYyzLX5W2wXpZfccEw9rhvFN8CobX+/cI40uE7ll3UtLMHWSUMBh7qEkYyNYH/79L6bZOq42IPQS8mzu/m/KshjVSBDCsuu8DfW8VvSwsi4EEX1C31qEhXtziqQll79bJKiw9kCpv/Da3MBf8r5VxhGD4Kn1PJmxeenXd/g9kdoHYfsgCA6MU3AY5/mebZo/M7K06jPmKJQkEeiP5cgjVX08XzHIw/0S10tEGhjQ02bcV8Os+A9qF/MXXTFad7kmCrMjDBr2UxqGdEf+ZdtXBrhXtM=;0400nyhffR+vPCWVebKatfMjIFqnBpgfJEsemeTdhVWz7vplzx6J6N9WyqBoTHtTJOfdka7HZeuaPbYF6UKDbOq+jZRvFCMSbl5x2njsd/l5YML0qLQS3a7zXCIWlMOpciAqyFB0gyXBGHRwXIf+CiFd0NVTVhkb8st5nm72VjmJQxC18erNJZIS6PRIJxwFhRDVHL6ObfY9VtMemmKsd8RiQSBnU8TCn0Q3WUZBsF3ZF25zF8OQSg/C8L6rkIhRM2WOqPA/nTQi00Nt5qc51e5DoSm+cn3vraM1f5kOKwYgC5Cu47w6WGxTFtWiR7A8zcYChiLXM4ViommjhJcH6VSc+5a4pPghTpbf2qfuC8E3WE6HK7ofS/ojWvTvbvXOKP/fvLniuTernvM9L9B/mLXg8hB66Oq1j1Ig++sWtid/JqzYwtOekK2T7LNCb7eqEP2SIl9nEGunnCjOIcDe3iuKI6Si+qSj99KaFqHfv6lgZq8tgpuh2BE2Y4RSvulWFziBCjlU0y9oNd/sTU9/joi9e1h0TIw5qQXOmssqTe7WzQg67PDmZdnwAkw3A/tk8HiZsBx6w1tx0mMZz7HtmSQrKuHt39bvxE86eVaYJEF00M2dmwpFJMf4g1ead3DELWp2ig6rb+tDAzIDq4Zc/9mjbFSAFu7g0I1zLD4mV3TQqnygG88Dq7TiLUxwNpWm2i9tJiDbCfVZTGBk19tyNs7g8wQxSxzPuRtycb0H5IjHkCcKSs4KVYKB4sYRtsxPIW0X+KRnCtOZRo5HDo0vYYDC3xqkbjiKwBZfdLDs+1JC1RHeqz7TtH33U6HB/POiPw6L5ExJlsEDyWeZwhjxiodtYrAtjgzHMGAk58fx3+Rcwz0I4HEJnGOmG0vEoXq/Y8/GXhBBz3OgEm8b/j6Q87qDY9m4JivOPiYRBNe8T77DDBVZl/dKYVxb2l22PjcuhFhUU1tetETJkni+RXQsRKZ98OshaHYP8Oq6k+cVXJiV2yLuhzmHVhuxKPPSloZACh8ATzEBdNLiXsNC09gR/Q8fGcyjpRbxiOKgtqlnK5kTQGQaf2fu5YDpGL2Fn/f6R6Kpd2Unsrr4Uy3f3MsKXcA2K3yn1che5R2NlWTGbVAqkimTkq7HiyKA1cab0CTaYygMn2zHo3AH8KHlGxGtKRvFQOICFQRx9UwR/kpQbT7qv+or/MCLoQJGWtWGCE8s0cL/Ut+AS8NGHzVYBOIn7xyv6bD9av+SeN9VqKVNlMbJNAZc8V1ZIWK++ykzCGBlggcGImwI4pTgqhb8IlmISROrbkxFXRiZcQcAnPGnG3CqgLln+4KLswTyWhDAstLN4US5V97h50/5jKuksZ+gFcc8aWv9+wL9TPT/o0khxZFaqj2g5dRbGWPI8BWlyqreR+Y/s6BJDQXN+VxrVbGJnVrTPX8hhQ2++kPJJmLnt5pkv7FFbZU1JSMe5nxgPVj4eN/NwKr0Mf+ogWbXGwJTIPPVuPCax2tdU/7tDQvVMT+mxp/u2MJCSi12NDDnFZBnAu8EYlA0ges6hzI=";
			
			
			/* ************************************************* 
			Function Name : globalInitialization 
			Description : This function is used to initialize Paths(Framework and Property file), objects, property file and reports.
			Input parameters : ReporterUtility refReporterUtility
			ReturnType : String (Type of Report)
			Author : Chetan N Baligar
			Date of Creation: 29-10-2018
			Modified By :  
			Modified Date :
			************************************************* */
			public void globalInitialization() {
				try{
					Reporter.log("******************** GlobalInitialization: Started ********************", true);
					//FrameworkAndPropertyFilePath
					gstrFramework_Path=System.getProperty("user.dir");
					Reporter.log("******************** GlobalInitialization: Completed ********************", true);
				}catch (Exception e) {
					Reporter.log("ERROR: Exception at globalInitialization", true);
					Reporter.log("ERROR: StackTrace: "+e.toString());	
						e.printStackTrace();
						throw e;
				}
			
			}
			
		
			
			/* ************************************************* 
			Function Name : AssertEquals_String 
			Description : This function is used to implement AssertEquals for string with logs
			Input parameters : String Actual, String Expected, String Phase
			ReturnType : Null
			Author : Chetan N Baligar
			Date of Creation: 29-10-2018
			Modified By :  
			Modified Date :
			************************************************* */
//			public void AssertEquals_String(String Actual, int responsecode, String Phase) {
//				try{
//					Assert.assertEquals(Actual, responsecode);
//					Reporter.log("INFO:"+Phase +": ( Successfull- Expected: "+responsecode+" | Actual: "+Actual+")");
//				}catch(Throwable t) {
//					Reporter.log("ERROR:"+"(Failed - Expected: "+responsecode+" and Actual: "+Actual+")");
//						throw t;
//				}
//			}
	
			/* ************************************************* 
			Function Name : AssertEquals_Int 
			Description : This function is used to implement AssertEquals for int with logs
			Input parameters : String Actual, String Expected, String Phase
			ReturnType : Null
			Author : Chetan N Baligar
			Date of Creation: 29-10-2018
			Modified By :  
			Modified Date :
			************************************************* */
			public void AssertEquals_Int(int Actual, int Expected, String Phase) {
				try{
					Assert.assertEquals(Actual, Expected);
					Reporter.log("INFO:"+Phase+": (Successfull- Expected: "+Expected+" | Actual: "+Actual+")");
				}catch(Throwable t) {
					Reporter.log("ERROR:"+Phase+" - (Failed - Expected: "+Expected+" and Actual: "+Actual+")");
						throw t;
				}
			}
	
	
}
