package runner;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;


import restassured.utilities.ExcelUtility;
import restassured.utilities.GenericMethods;
import restassured.utilities.GenericUtilities;
import restassured.utilities.HtmlReport;
import restassured.utilities.PropertyFileInitializer;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;


import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Baseclass{
	
	//TimeStamp Initialization
	public static String gstrTimeStamp = new SimpleDateFormat("dd.MM.yyyy.HH.mm.ss").format(new java.util.Date());
			
			//Variable declaration's
			public static String gstrScenarioName;
			public static String gstrFramework_Path;
			//Object reference declaration's 
			public static Properties grefGlobalProperties;
			//Application Variables
			public static RequestSpecification gRequest;
			public static Response gResponse;
			public static ExtentReports extent;
			public static String AccesToken;
			public static ExtentTest loggerE;
			public static String screenshotPath;
			public static String PropFilePath;
			public static RequestSpecification TokenIDHeader;
			public static WebDriver driver;
			public static XWPFDocument document;
			public static HtmlReport hr;
			public static GenericUtilities gu;
			public static GenericMethods gm;
			public static ExcelUtility ex;
			public static FileInputStream fis;
			public static String CucumberWrite;
			public static FileInputStream fi=null;
			public static Workbook wb = null;
			public static FileOutputStream fo=null;
			public static int Executer=1;
			public final static Logger logger = Logger.getLogger("Log4j");
			public String OTRLocation=System.getProperty("user.dir")+"\\Test-Output\\OTR\\";
			public static WebDriverWait wait;
			public static String ExcelLocation=System.getProperty("user.dir")+"//Test-Output//ExcelOutput//Detailed_Execution_status.xlsx";
			public static final String ScreenShotLocation =System.getProperty("user.dir")+"//Test-Output//ScreenShots//";
			public static final String reportConfigPath=System.getProperty("user.dir")+"//extent-config.xml//";
			public static JavascriptExecutor js;
			public static String S;
			public static String DecisionCode;
			public static String DecisionDesc;
			public static String ApplicationId;
			public static String DecisionProductCode;
			public static String PlccApplicantionResponse;
			public static String ForeignLanguageIndicator;
			public static String AccountInfo;
			public static String TempClExpDate;
			public static String TemporaryCreditLine;
			public static String AccountNumber;
			public static String CreditLine;
			public static String SecurityCode;
			public static String Code;
			public static String Message;
			public static String TrackingId;
			public static String Errors;
			public static String Transient;
			public static String Field;
			public static String Location;
			public static String Reason;
			public static String DocumentationUrl;
			public static String UserMessage;
			public static String RemediationInfo;
			

			
			
			/* ************************************************* 
			Function Name : globalInitialization 
			Description : This function is used to initialize Paths(Framework and Property file), objects, property file and reports.
			Input parameters : ReporterUtility refReporterUtility
			ReturnType : String (Type of Report)
			Date of Creation: 29-10-2018
			Modified By :  
			Modified Date :
			************************************************* */
			public void globalInitialization() throws Exception {
				try{
					Reporter.log("******************** GlobalInitialization: Started ********************", true);
					//FrameworkAndPropertyFilePath
					gstrFramework_Path=System.getProperty("user.dir");
					PropFilePath = gstrFramework_Path + "\\Setup\\GlobalPropertyFile\\GlobalProperties.properties";
					PropertyFileInitializer.PathAndVariableInitializer();
					Reporter.log("******************** GlobalInitialization: Completed ********************", true);
		
				}catch (Exception e) {
					Reporter.log("ERROR: Exception at globalInitialization", true);
					Reporter.log("ERROR: StackTrace: "+e.toString());	
						e.printStackTrace();
						throw e;
				}
			
			}
			
		
			
			/* ************************************************* 
			Function Name : AssertEquals_String 
			Description : This function is used to implement AssertEquals for string with logs
			Input parameters : String Actual, String Expected, String Phase
			ReturnType : Null
			Date of Creation: 29-10-2018
			Modified By :  
			Modified Date :
			************************************************* */
//			public void AssertEquals_String(String Actual, int responsecode, String Phase) {
//				try{
//					Assert.assertEquals(Actual, responsecode);
//					Reporter.log("INFO:"+Phase +": ( Successfull- Expected: "+responsecode+" | Actual: "+Actual+")");
//				}catch(Throwable t) {
//					Reporter.log("ERROR:"+"(Failed - Expected: "+responsecode+" and Actual: "+Actual+")");
//						throw t;
//				}
//			}
	
			/* ************************************************* 
			Function Name : AssertEquals_Int 
			Description : This function is used to implement AssertEquals for int with logs
			Input parameters : String Actual, String Expected, String Phase
			ReturnType : Null
			Date of Creation: 29-10-2018
			Modified By :  
			Modified Date :
			************************************************* */
			public void AssertEquals_Int(int Actual, int Expected, String Phase) throws Throwable {
				try{
					Assert.assertEquals(Actual, Expected);
					Reporter.log("INFO:"+Phase+": (Successfull- Expected: "+Expected+" | Actual: "+Actual+")");
				}catch(Throwable t) {
					Reporter.log("ERROR:"+Phase+" - (Failed - Expected: "+Expected+" and Actual: "+Actual+")");
						throw t;
				}
			}
	
			public void AssertEquals_String(String Actual, String decisionCode2, String Phase) throws Throwable {
				try{
					Assert.assertEquals(Actual, decisionCode2);
					Reporter.log("INFO:"+Phase+": (Successfull- Expected: "+decisionCode2+" | Actual: "+Actual+")");
				}catch(Throwable t) {
					Reporter.log("ERROR:"+Phase+" - (Failed - Expected: "+decisionCode2+" and Actual: "+Actual+")");
						throw t;
				}
			}
}
