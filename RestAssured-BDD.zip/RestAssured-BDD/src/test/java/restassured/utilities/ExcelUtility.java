package restassured.utilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File; 


public class ExcelUtility {
	int rowCount;

	public String getStringvalueFromExcel(String Path, String SheetName, int Row, int Col) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbr=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbr.getSheet(SheetName);
		XSSFRow row=sheet.getRow(Row);
		XSSFCell cell=row.getCell(Col);
		String value=cell.getStringCellValue();
		return value;
	}


	public double getNumericValueFromExcel(String Path, String SheetName, int Row, int Col) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbr=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbr.getSheet(SheetName);
		XSSFRow row=sheet.getRow(Row);
		XSSFCell cell=row.getCell(Col);
		double value=cell.getNumericCellValue();
		return value;
	}
	public void writeStringValueIntoExcel(String Path, String SheetName, int Row, int Col, String Val) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);
		XSSFRow row=sheet.createRow(Row);
		XSSFCell cell=row.createCell(Col);

		cell.setCellValue(Val);
		FileOutputStream fos=new FileOutputStream(Path);
		wbw.write(fos);
	//	wbw.close();
		fos.close();

	}
	public void writeStringValueIntoExcel_CreateRow(String Path, String SheetName, int Row, int Col, String Val) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);
		XSSFRow row=sheet.createRow(Row);
		XSSFCell cell=row.createCell(Col);

		cell.setCellValue(Val);
		FileOutputStream fos=new FileOutputStream(Path);
		wbw.write(fos);
	//	wbw.close();
		fos.close();

	}
	public void writeStringValueIntoExcel_getRow(String Path, String SheetName, int Row, int Col, String Val) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);
		XSSFRow row=sheet.getRow(Row);
		XSSFCell cell=row.createCell(Col);
		cell.setCellValue(Val);
		FileOutputStream fos=new FileOutputStream(Path);
		wbw.write(fos);
	//	wbw.close();
		fos.close();

	}


	public void writeStringValueIntoExcel_WithBorders(String Path, String SheetName, int Row, int Col, String Val) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);
		XSSFRow row=sheet.getRow(Row);
		XSSFCell cell=row.createCell(Col);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(Val);

		XSSFCellStyle arg0=wbw.createCellStyle();
		arg0.setBorderBottom(CellStyle.BORDER_THIN);
		arg0.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		arg0.setBorderTop(CellStyle.BORDER_THIN);
		arg0.setTopBorderColor(IndexedColors.BLACK.getIndex());
		arg0.setBorderLeft(CellStyle.BORDER_THIN);
		arg0.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		arg0.setBorderRight(CellStyle.BORDER_THIN);
		arg0.setRightBorderColor(IndexedColors.BLACK.getIndex());
		cell.setCellStyle(arg0);

		FileOutputStream fos=new FileOutputStream(Path);
		wbw.write(fos);

		fos.close();

	}
	public void writeStringValueIntoExcel_Red(String Path, String SheetName, int Row, int Col, String Val) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);
		XSSFRow row=sheet.getRow(Row);
		CellStyle style = wbw.createCellStyle(); 
		style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		Font font = wbw.createFont(); 
		font.setColor(IndexedColors.RED.getIndex());
		style.setFont(font);
		XSSFCell cell=row.createCell(Col);
		cell.setCellValue(Val); 
		cell.setCellStyle(style); 
		FileOutputStream fos =new FileOutputStream(new File("D:/xlsx/cp.xlsx"));
		wbw.write(fos);
		fos.close();
		System.out.println("Done"); 

	}

	public void writeNumericValueIntoExcel(String Path, String SheetName, int Row, int Col, int Val) throws IOException{
		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);
		XSSFRow row=sheet.getRow(Row);
		XSSFCell cell=row.createCell(Col);
		cell.setCellType(Cell.CELL_TYPE_NUMERIC);
		cell.setCellValue(Val);
		FileOutputStream fos=new FileOutputStream(Path);
		wbw.write(fos);
		fos.close();
		//System.out.println("Excel File Written.");
	}

	public void SetFormula(String Path, String SheetName,String formula, int Row, int Col) throws IOException{

		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		XSSFSheet sheet=wbw.getSheet(SheetName);

		XSSFRow row=sheet.createRow(Row);
		XSSFCell cell=row.createCell(Col);
		cell.setCellType(Cell.CELL_TYPE_FORMULA);
		cell.setCellFormula(formula);
		FileOutputStream outputStream = new FileOutputStream(Path);
		wbw.write(outputStream);
	//	wbw.close();
		outputStream.close();
	}



	public int getRowCount(String Path, String SheetName) throws InvalidFormatException, IOException{

		FileInputStream ref=new FileInputStream(Path);
		XSSFWorkbook wbw=new XSSFWorkbook(ref);
		try {
			rowCount = wbw.getSheet(SheetName).getLastRowNum();
			rowCount=rowCount+1;

		} catch (Exception e) {

			e.printStackTrace();
		}
		return rowCount;

	} 

}