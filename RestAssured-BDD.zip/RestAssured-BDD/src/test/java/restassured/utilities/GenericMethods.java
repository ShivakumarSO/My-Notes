package restassured.utilities;


import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import runner.Baseclass;


public class GenericMethods extends Baseclass {

	public static String getProperty(String propertyType){
		String data="";
		try{
			FileReader reader = new FileReader(PropFilePath);
			grefGlobalProperties = new Properties();
			grefGlobalProperties.load(reader);
			data = grefGlobalProperties.getProperty(propertyType);
			return data;
		} catch (IOException e) {
			System.out.println(e.getMessage());
			return data;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return data;
		}
	}
	public static void CucumberReportWrite(String WriteInfo) throws IOException{
		try{
			
			CucumberWrite = CucumberWrite +"\n"+WriteInfo;
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
