package restassured.utilities;

import runner.Baseclass;

public class PropertyFileInitializer extends Baseclass {
	
	public static void PathAndVariableInitializer(){

		
		//Application Variables
		/*trans_id=GenericMethods.getProperty("trans_id");
		password1=GenericMethods.getProperty("password1");
		black_box=GenericMethods.getProperty("black_box");*/
			
		
	}
	
	

}
