
package restassured.utilities;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.Borders;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

//import io.restassured.internal.support.FileReader;
import runner.Baseclass;

public class GenericUtilities extends Baseclass {
	
	FileInputStream fis;
	ExcelUtility ex = new ExcelUtility();
	WebDriver driver;

	public GenericUtilities() {
	}

	public String browserCapture(WebDriver driver, String filepath, String filename) throws IOException {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File targetfile = new File(
				(new StringBuilder(String.valueOf(filepath))).append(filename).append(".jpg").toString());
		try {
			FileUtils.copyFile(scrFile, targetfile);

		} catch (Exception exception) {

		}
		String Fullpath = targetfile.getAbsolutePath();
		String custom[] = Fullpath.split("TC");
		return "TC" + custom[1];
	}

	public void closeJscriptpopup(WebDriver driver, Alert alert, String checkFlag) {
		alert = driver.switchTo().alert();
		if (checkFlag.equalsIgnoreCase("ON") || checkFlag.equalsIgnoreCase("TRUE") || checkFlag.equalsIgnoreCase("YES")
				|| checkFlag.equalsIgnoreCase("Y"))
			alert.accept();
		else if (checkFlag.equalsIgnoreCase("OFF") || checkFlag.equalsIgnoreCase("FALSE")
				|| checkFlag.equalsIgnoreCase("NO") || checkFlag.equalsIgnoreCase("N"))
			alert.dismiss();
	}

	public void navigatetoWebpage(WebDriver driver, String url) {
		driver.get(url);
	}
	
	
	public static String getProperties(String propertyType) throws IOException
	{
	FileReader reader=new FileReader(System.getProperty("user.dir")+"testdata\\property.properties"); 
	Properties prop=new Properties();
	prop.load(reader);
	String data=prop.getProperty(propertyType);
	return data;
	}
	
	public void click(WebElement ele) throws Exception {
		try {
			
			ele.click();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
			System.out.println("Issue with clicking "+ ele);
			throw(e);
		}
		
	}
	
	public static HashMap<String, String> getDataFromExcel(String path,String sheetname, int startRow, int endRow)
	{
	HashMap< String, String> hashMap=new HashMap<String, String>();
	int cellCount;
	try {
	fi=new FileInputStream(path);
	wb = WorkbookFactory.create(fi);
	Sheet sh=wb.getSheet(sheetname);
	cellCount =sh.getRow(startRow).getLastCellNum();
	//for (int i = startRow; i <= endRow; i++) 
	{
	for (int j = 0; j < cellCount; j++) 
	{
	/*boolean keyStatus=(sh.getRow(i).getCell(j).getStringCellValue().isEmpty());
	boolean valueStatus=( sh.getRow(0).getCell(j).getStringCellValue().isEmpty());
	if((keyStatus!=true)|| (valueStatus!=true)){
	}*/
	hashMap.put(sh.getRow(0).getCell(j).getStringCellValue().toString(), sh.getRow(endRow).getCell(j).getStringCellValue().toString());
	//list.add(sh.getRow(1).getCell(j).getStringCellValue());
	}
	}
	} 
	catch(NullPointerException exception)
	{
	System.out.println(exception.getMessage());
	}
	catch (EncryptedDocumentException e) {

	System.out.println(e.getMessage());	
	} catch (InvalidFormatException e) {

	System.out.println(e.getMessage());	
	}  catch (FileNotFoundException e1) {

	System.out.println(e1.getMessage());
	}
	catch (IOException e) {
	System.out.println(e.getMessage());	
	}
	catch (Exception e) {
	System.out.println(e.getMessage());	
	}
	return hashMap;
	}
	
	
	
	public  void clickButtonByJSWithIndex1(WebDriver driver,int index){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		try {
		js.executeScript("document.getElementsByTagName('button')["+index+"].click()");
		} catch (Exception e) {
		// TODO Auto-generated catch block
			
			
		e.printStackTrace();
		System.out.println(e.getMessage());
		}
	}

	public void typeinEditbox(WebElement ele, String valuetoType) {
		ele.sendKeys(new CharSequence[] { valuetoType });
	}

	public void selectRadiobutton(WebElement ele) {
		ele.click();
	}

	public void selectCheckbox(WebElement ele, String checkFlag) {
		if (checkFlag.equalsIgnoreCase("ON") || checkFlag.equalsIgnoreCase("TRUE") || checkFlag.equalsIgnoreCase("YES")
				|| checkFlag.equalsIgnoreCase("Y")) {
			if (!ele.isSelected())
				ele.click();
		} else if ((checkFlag.equalsIgnoreCase("OFF") || checkFlag.equalsIgnoreCase("FALSE")
				|| checkFlag.equalsIgnoreCase("NO") || checkFlag.equalsIgnoreCase("N")) && ele.isSelected())
			ele.click();
	}

	public boolean WaitForElePresent(WebElement ele, int timeOut) {
		boolean found = false;
		for (int timer = 0; !found && timer <= timeOut; timer++) {
			waitFor(1);
			try {
				found = ele.isDisplayed();
				
			} catch (Exception e) {
				found = false;

			}
		}

		return found;
	}

	public boolean waitUntilVisibilityOfElementLocated(WebDriver driver, By by) {
		boolean found = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			found = true;

		} catch (Exception e) {
			// TODO: handle exception
			
			found = false;
			System.out.println(e.getMessage());
		}
		return found;
	}

	public void waitUntilElementToBeClickable(WebDriver driver, By by) {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(by));

	}

	public boolean fluientWaitforElementToclick(WebDriver driver, WebElement element) {
		boolean status = false;
		FluentWait<WebDriver> fWait = new FluentWait<WebDriver>(driver).withTimeout(20, TimeUnit.SECONDS)
				.pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		try {
			
			fWait.until(ExpectedConditions.visibilityOf(element));
			fWait.until(ExpectedConditions.elementToBeClickable(element));
			status=true;

		} catch (Exception e) {
			status = false;
			System.out.println("Element Not found trying again - " + element.toString().substring(70));
			e.printStackTrace();

		}

		return status;

	}

	public boolean fluientWaitforElementToVisible(WebDriver driver, WebElement element) {
		boolean status = false;
		FluentWait<WebDriver> fWait = new FluentWait<WebDriver>(driver).withTimeout(40, TimeUnit.SECONDS)
				.pollingEvery(20, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		try {
			
			fWait.until(ExpectedConditions.visibilityOf(element));			
			status=true;
		} catch (Exception e) {
			status=false;
			System.out.println("Element Not found trying again - " + element.toString().substring(70));
			e.printStackTrace();

		}
		return status;
	}
	
	public boolean fluientWaitforFewMinsForElementToVisible(WebDriver driver, WebElement element, int WaitTime) {
		boolean status = false;
		FluentWait<WebDriver> fWait = new FluentWait<WebDriver>(driver).withTimeout(60*WaitTime, TimeUnit.SECONDS)
				.pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		try {
			
			fWait.until(ExpectedConditions.visibilityOf(element));			
			status=true;
		} catch (Exception e) {
			status=false;
			System.out.println("Element Not found trying again - " + element.toString().substring(70));
			e.printStackTrace();

		}
		return status;
	}
	
	
	public  void clickByJs(WebDriver driver,String Id){
		try {
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("document.getElementById(\'"+Id+"\')"+".click()");
			System.out.println("Clicked on  : "+Id);
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			
		}
	}
	

	public  void clickByJswithtype(WebDriver driver,String type){
		try {
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("document.getElementById(\'"+type+"\')"+".click()");
			System.out.println("Clicked on  : "+type);
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			
		}
	}
	public  void clickCheckboxByXpath(WebDriver driver,WebElement ele){
		try {
			JavascriptExecutor js=(JavascriptExecutor)driver;
			
			//js.executeScript("document.getElemetByXpath(\'"+Id+"\')"+".click()");
			js.executeScript("arguments[0].click();", ele);
			//System.out.println("Clicked on  : "+Id);
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			
		}
	}
	
	public void waitUntilZero(WebDriver driver)
	
	{
		try {
			WebElement ele=driver.findElement(By.xpath("//*[text()=' TIME REMAINING:']"));
			while(ele.getText().equalsIgnoreCase("TIME REMAINING:0:00")){
				System.out.println("start over popup dispalyed");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error in waiting");
		}
	}
	
	public void clickButtonbytext(WebDriver driver,String name) {
		
		List<WebElement> list=driver.findElements(By.tagName("button"));
		for (Iterator<WebElement> iterator = list.iterator(); iterator.hasNext();) {
			WebElement webElement = iterator.next();
			if(webElement.getText().contains(name)){
				//webElement.click();
				break;
			}
		}
	}
	public  void clickButtonByJSWithIndex(WebDriver driver,int index){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		try {
			js.executeScript("document.getElementsByTagName('button')["+index+"].click()");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	public  void clickLinkByJSWithIndex(WebDriver driver,int index){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		try {
			js.executeScript("document.getElementsByTagName('a')["+index+"].click()");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	public  void pagescrollDown () throws Exception{
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public  void pageScrollDownWithEle(WebDriver driver, WebElement Element){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();",Element );
	}
	public  void pageScrollDownByPixel(WebDriver driver){
		try {
			JavascriptExecutor js=(JavascriptExecutor)driver;
			// This  will scroll down the page by  1000 pixel vertical		
			js.executeScript("window.scrollBy(0,500)");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("scroll by pixel is not working "+e.getMessage());
		}
	}
	public  void pageScrollUpByPixel(WebDriver driver){
		try {
			JavascriptExecutor js=(JavascriptExecutor)driver;
			// This  will scroll down the page by  1000 pixel vertical		
			js.executeScript("window.scrollBy(1000,0)");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("scroll by pixel is not working "+e.getMessage());
		}
	}
	
	public boolean WaitForElePresentExplicit1(WebDriver driver, WebElement ele, int timeOut) {
		boolean found = false;
		WebElement tempEle = null;

		for (int timer = 0; !found && timer <= timeOut; timer++) {
			try {

				tempEle = (new WebDriverWait(driver, 1)).until(ExpectedConditions.elementToBeClickable(ele));
				// (new WebDriverWait(driver,
				// 1)).until(ExpectedConditions.invisibilityOf(ele));
			} catch (Exception e) {
				found = false;
			} finally {
				if (tempEle != null)
					found = true;
			}
		}
		return found;
	}

	public boolean WaitForElePresentExplicit(WebDriver driver, WebElement ele, long timeOut) {
		boolean found = false;
		WebElement tempEle = null;
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			tempEle = wait.until(ExpectedConditions.elementToBeClickable(ele));

			if (tempEle != null) {
				found = true;
			}
		} catch (Exception e) {
			found = false;
		}

		return found;
	}

	public boolean WaitForEleInVisibility(WebDriver driver, WebElement ele, long timeOut) {
		boolean found = false;

		try {
			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			WebElement tempEl = wait.until(ExpectedConditions.visibilityOf(ele));

			if (tempEl != null) {
				found = true;
			}
		} catch (Exception e) {
			found = false;
		}

		return found;
	}

	public void waitFor(int timeInSeconds) {
		try {
			Thread.sleep(timeInSeconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void selectdropdown(WebElement selectdropdownEle, String selectby, String dropdownValue) {
		try {
			if (selectby.equalsIgnoreCase("value"))
				(new Select(selectdropdownEle)).selectByValue(dropdownValue);
			else if (selectby.equalsIgnoreCase("text"))
				(new Select(selectdropdownEle)).selectByVisibleText(dropdownValue);
			Thread.sleep(1000);
			if (selectby.equalsIgnoreCase("index"))
				(new Select(selectdropdownEle)).selectByVisibleText(dropdownValue);
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println("Unable To select a Element"+e.getMessage());
			
			
		}
	}
	
	
	public  void selecDropDownByInx(WebElement element, String val)
	{
		Select select=new Select(element);
		select.selectByValue(val);
	}
	
	public  String selectDropDownByInx(WebElement element, String val)
	{
		Select select=new Select(element);
		select.selectByValue(val);
		return val;
	}

	public void entertext(WebElement ele ,String val ) throws Exception{
		try {
			/*if(ele.isDisplayed()==true){
				
				//ele.click();
				//Thread.sleep(1000);
				//ele.clear();
				//Thread.sleep(1000);
				if (ele.getAttribute("value").isEmpty()) {
					//ele.sendKeys(Keys.chord(val));
					ele.sendKeys(val);
					//Thread.sleep(1000);
				}else{
					//ele.sendKeys(Keys.chord(Keys.CONTROL, "a"), val);
					ele.sendKeys(Keys.CONTROL + "a");
					ele.sendKeys(Keys.DELETE);
					//ele.sendKeys(Keys.chord(val));
					ele.sendKeys(val);
				}
				
				
				
				
				System.out.println(ele + " value entered :" + val);
			}
			else{
				System.out.println(ele + " value  not entered :" + val);
			}*/
			ele.click();
			ele.clear();
			ele.sendKeys(val);
			
					
		} 
		
		catch (Exception e) {
				e.printStackTrace();
				System.out.println("isTextpresent exception catch block"+ e.getMessage());
				System.out.println("Issue with entering :" +ele);
				
				
				
			}
	}
	public void enterdropdown(WebElement ele  ) throws Exception{
		try {
			
			
			
			ele.click();
		
			//ele.clear();
			//ele.sendKeys(val);
			
					
		} 
		
		catch (Exception e) {
				e.printStackTrace();
				System.out.println("isTextpresent exception catch block"+ e.getMessage());
				System.out.println("Issue with entering :" +ele);
				
				
				
			}
	}
	public void enterTextWithJS(WebDriver driver,String ele ,String p1) throws Exception{
		
		
		try {
			JavascriptExecutor js=(JavascriptExecutor)driver;	
			WebElement elem = driver.findElement(By.id(ele));
			js.executeScript("arguments[0].focus();", elem);
			//js.executeScript("arguments[0].val = '"+p1+"';", elem);
			//js.executeScript("arguments[0].val = '"+p1+"';", elem);
			js.executeScript("document.getElementById(\'"+ele+"\').value = '"+p1+"';");
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error Whiling entering field"+e.getMessage());
		}
	}
	
	public  void tab () throws Exception{
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_TAB);
        robot.keyRelease(KeyEvent.VK_TAB);
        Thread.sleep(2000);
	}

	public boolean selectdropdown(WebElement selectdropdownEle, WebElement list_innergrop, String OptionTagNameORxpath,
			String selectby, String dropdownValue) {
		if (OptionTagNameORxpath.contains("//")) {
			selectdropdownEle.click();
			if (selectby.equalsIgnoreCase("value")) {
				List coll_groupItems = list_innergrop.findElements(By.xpath(OptionTagNameORxpath));
				for (Iterator iterator = coll_groupItems.iterator(); iterator.hasNext();) {
					WebElement item = (WebElement) iterator.next();
					if (item.getAttribute("Value").equalsIgnoreCase(dropdownValue)) {
						item.click();
						return true;
					}
				}

			} else if (selectby.equalsIgnoreCase("text")) {
				List coll_groupItems = list_innergrop.findElements(By.xpath(OptionTagNameORxpath));
				for (Iterator iterator1 = coll_groupItems.iterator(); iterator1.hasNext();) {
					WebElement item = (WebElement) iterator1.next();
					if (item.getText().equalsIgnoreCase(dropdownValue)) {
						item.click();
						return true;
					}
				}

			}
		} else {
			selectdropdownEle.click();
			if (selectby.equalsIgnoreCase("value")) {
				List coll_groupItems = list_innergrop.findElements(By.tagName(OptionTagNameORxpath));
				for (Iterator iterator2 = coll_groupItems.iterator(); iterator2.hasNext();) {
					WebElement item = (WebElement) iterator2.next();
					if (item.getAttribute("Value").equalsIgnoreCase(dropdownValue)) {
						item.click();
						return true;
					}
				}

			} else if (selectby.equalsIgnoreCase("text")) {
				List coll_groupItems = list_innergrop.findElements(By.tagName(OptionTagNameORxpath));
				for (Iterator iterator3 = coll_groupItems.iterator(); iterator3.hasNext();) {
					WebElement item = (WebElement) iterator3.next();
					if (item.getText().equalsIgnoreCase(dropdownValue)) {
						item.click();
						return true;
					}
				}

			}
		}
		return false;
	}

	public boolean isEnabled(WebElement ele) {
		boolean value = false;
		value = ele.isEnabled();
		if (value)
			System.out.println("Element is Enabled");
		else
			System.out.println("Element is Disabled");
		System.out.println(value);
		return value;
	}

	public boolean isSelected(WebElement ele) {
		boolean value = false;
		value = ele.isSelected();
		if (value)
			System.out.println("Check box is selected");
		else
			System.out.println("Check box is notselected");
		System.out.println(value);
		return value;
	}

	public boolean isTextpresentpsource(WebDriver driver, String expectedstring) {
		boolean value;
		value = driver.getPageSource().contains(expectedstring);
		if (value) {
			System.out.println("Pass");
			return value;
		}
		try {
			System.out.println("Fail");
			return value;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	public boolean isTextpresent(WebElement ele, String expectedstring) {
		System.out.println("inside method");
		boolean value = false;
		String actualstring = "";
		try {
			actualstring = ele.getText();
			if (actualstring.equals(expectedstring))
				value = true;
			else
				value = false;
			return value;
		} catch (Exception e) {
			System.out.println("isTextpresent exception catch block");
		}
		value = false;
		return value;
	}

	public String getText(WebElement ele) {
		String actualstring = "";
		try {
			actualstring = ele.getText();
			return actualstring;
		} catch (Exception e) {
			System.out.println("isTextpresent exception catch block");
		}
		return actualstring;
	}
	public String  getMaxLenght(WebElement ele) {
		String actualstring = "" ;
		try {
			actualstring = ele.getAttribute("maxlength");
			return actualstring;
		} catch (Exception e) {
			System.out.println("isTextpresent exception catch block");
		}
		return actualstring;
		
	}
	public String  getFieldNameAndCompare(WebElement ele,String attributeName) {
		String actVal = "" ;
		try {
			 actVal = ele.getAttribute(attributeName);
			
			return actVal;
		} catch (Exception e) {
			System.out.println("isTextpresent exception catch block");
			return actVal;
		}
		
		
	}
	
	public int  countTotalLinksByXpath(WebDriver driver,String xpath){
		
		int totalLinkCount = 0;
		try {
			totalLinkCount = driver.findElements(By.xpath(xpath)).size();
			System.out.println("Total Links count  : " + totalLinkCount);
			return totalLinkCount;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getLocalizedMessage());
		}
		return totalLinkCount;
		
		
	}
	
	public int countTotalLinksByTagName(WebElement ele,String tagName){
		int totalLinkCount =0;
		try {
			List<WebElement> totalLinks = driver.findElements(By.tagName(tagName));
			 totalLinkCount = totalLinks.size();
			System.out.println("Total Links count : " + totalLinkCount);
			return totalLinkCount;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return totalLinkCount;
	}
	

	public boolean checkDropdown(WebElement ele, String Expectedvalues) {
		boolean value = false;
		boolean match = false;
		String exp[] = Expectedvalues.substring(0).split(",");
		int matchcount = 0;
		int explen = exp.length;
		Select select = new Select(ele);
		List options = select.getOptions();
		for (Iterator iterator = options.iterator(); iterator.hasNext();) {
			WebElement we = (WebElement) iterator.next();
			match = false;
			for (int checklen = 0; checklen < explen; checklen++)
				if (we.getText().equals(exp[checklen])) {
					match = true;
					if (match = true)
						matchcount++;
					if (matchcount == explen)
						value = true;
				}

		}

		if (match == value)
			match = value;
		System.out.println(value);
		return value;
	}

	public boolean checkElementpresent(WebElement ele) {
		boolean checkelementpresent = false;
		try {
			checkelementpresent = ele.isDisplayed();
		} catch (Exception e) {
			e.printStackTrace();
			return checkelementpresent;
		}
		return checkelementpresent;
	}

	public boolean checkTitle(WebDriver driver, String expectedtitle) {
		String actualTitle = driver.getTitle();
		if (actualTitle.contentEquals(expectedtitle)) {
			System.out.println("Test Passed!");
			return true;
		} else {
			System.out.println("Test Failed");
			return false;
		}
	}

	public String getTitle(WebDriver driver) {
		String actualTitle = driver.getTitle();
		return actualTitle;
	}
	public String  getlabel(WebElement ele) {
		String actualstring = "" ;
		try {
			actualstring = ele.getAttribute("placeholder");
			return actualstring;
		} catch (Exception e) {
			System.out.println("isTextpresent exception catch block");
		}
		return actualstring;
	}
	public boolean WaitForElePresent1(WebElement ele, int timeOut) {
		boolean found = false;
		for (int timer = 0; !found && timer <= timeOut; timer++) {
		waitFor(1);
		try {
		found = ele.isDisplayed();

		} catch (Exception e) {
		found = false;
		}
		}return found;
	}
	public String  getformatedvalue(WebElement ele) {
		String actualstring = "" ;
		try {
			actualstring = ele.getAttribute("value");
			return actualstring;
		} catch (Exception e) {
			System.out.println("isTextpresent exception catch block");
		}
		return actualstring;
	}
	public String  getmaskvalue(WebElement ele) {
		String actualstring = "" ;
		try {
			actualstring = ele.getAttribute("type");
			return actualstring;
		} catch (Exception e) {
			System.out.println("isTextpresent exception catch block");
		}
		return actualstring;
	}
public boolean getOrder(WebDriver driver,String Header,String order1,String order2,String order3) {
	boolean status =false;
		try {
			Thread.sleep(3000);
		List<WebElement> list=driver.findElements(By.xpath("//*[contains(text(),\'"+Header+"\')]/following::label"));
		if(list.get(2).getAttribute("for").equalsIgnoreCase(order1) && list.get(3).getAttribute("for").equalsIgnoreCase(order2) && list.get(4).getAttribute("for").equalsIgnoreCase(order3)){
			System.out.println("Elements are in order");
			status=true;
		}else{
			status=false;
			System.out.println("Elements are not in order");
		}
		}catch (Exception e) {
			status=false;
			System.out.println("Elements are not in order");
		}
		return status;
	}
public boolean getOrderInBO(WebDriver driver) {
	boolean status =false;
		try {
			Thread.sleep(3000);
			int order1 = driver.findElement(By.xpath("//select[@name='busOwns[0].boDescriptiondocument']")).getLocation().getY();
			int order2 = driver.findElement(By.xpath("//input[@name='busOwns[0].boPassportnumber']")).getLocation().getY();
			int order3 = driver.findElement(By.xpath("//select[@name='busOwns[0].boCountryList']")).getLocation().getY();
			if(order1<order2 && order2<order3){
				
				System.out.println("element are in order");
				status=true;
			}else{
			status=false;
			System.out.println("Elements are not in order");
		}
		}catch (Exception e) {
			status=false;
			System.out.println("Elements are not in order");
		}
		return status;
	}

	public String searchandgetTexttable(WebElement ele, int searchcolumn, String searchdata, int selectcolumn) {
		List completecelldata = null;
		String returnstring = "";
		if (ele != null) {
			boolean flaggetvalue = false;
			List allRows = ele.findElements(By.tagName("tr"));
			for (Iterator iterator = allRows.iterator(); iterator.hasNext();) {
				WebElement row = (WebElement) iterator.next();
				List cells = row.findElements(By.tagName("td"));
				Iterator iterator1 = cells.iterator();
				while (iterator1.hasNext()) {
					WebElement cell = (WebElement) iterator1.next();
					int newsearchcolumn = searchcolumn - 1;
					if (!cell.equals(cells.get(newsearchcolumn)))
						continue;
					String sampletext = cell.getText();
					if (!sampletext.equals(searchdata))
						continue;
					completecelldata = cells;
					flaggetvalue = true;
					break;
				}
				if (flaggetvalue)
					break;
			}

			int newselectcolumn = selectcolumn - 1;
			WebElement element = (WebElement) completecelldata.get(newselectcolumn);
			returnstring = element.getText();
		}
		return returnstring;
	}

	public void searchandSelecttable(WebElement ele, int searchcolumn, String searchdata, int selectcolumn) {
		List completecelldata = null;
		if (ele != null) {
			boolean flaggetvalue = false;
			List allRows = ele.findElements(By.tagName("tr"));
			for (Iterator iterator = allRows.iterator(); iterator.hasNext();) {
				WebElement row = (WebElement) iterator.next();
				List cells = row.findElements(By.tagName("td"));
				Iterator iterator1 = cells.iterator();
				while (iterator1.hasNext()) {
					WebElement cell = (WebElement) iterator1.next();
					int newsearchcolumn = searchcolumn - 1;
					if (!cell.equals(cells.get(newsearchcolumn)))
						continue;
					String sampletext = cell.getText();
					if (!sampletext.equals(searchdata))
						continue;
					System.out.println("string found");
					completecelldata = cells;
					flaggetvalue = true;
					break;
				}
				if (flaggetvalue)
					break;
			}

			int newselectcolumn = selectcolumn - 1;
			WebElement element = (WebElement) completecelldata.get(newselectcolumn);
			element.click();
		}
	}

	public void searchandTypeintable(WebElement ele, int searchcolumn, String searchdata, int selectcolumn,
			String entertext) {
		List completecelldata = null;
		if (ele != null) {
			boolean flaggetvalue = false;
			List allRows = ele.findElements(By.tagName("tr"));
			for (Iterator iterator = allRows.iterator(); iterator.hasNext();) {
				WebElement row = (WebElement) iterator.next();
				List cells = row.findElements(By.tagName("td"));
				Iterator iterator1 = cells.iterator();
				while (iterator1.hasNext()) {
					WebElement cell = (WebElement) iterator1.next();
					int newsearchcolumn = searchcolumn - 1;
					if (!cell.equals(cells.get(newsearchcolumn)))
						continue;
					String sampletext = cell.getText();
					if (!sampletext.equals(searchdata))
						continue;
					System.out.println("string found");
					completecelldata = cells;
					flaggetvalue = true;
					break;
				}
				if (flaggetvalue)
					break;
			}

			int newselectcolumn = selectcolumn - 1;
			WebElement element = (WebElement) completecelldata.get(newselectcolumn);
			element.sendKeys(new CharSequence[] { entertext });
		}
	}

	public void searchandSelectcheckboxtable(WebElement ele, int searchcolumn, String searchdata, int selectcolumn,
			String checkFlag) {
		List completecelldata = null;
		if (ele != null) {
			boolean flaggetvalue = false;
			List allRows = ele.findElements(By.tagName("tr"));
			for (Iterator iterator = allRows.iterator(); iterator.hasNext();) {
				WebElement row = (WebElement) iterator.next();
				List cells = row.findElements(By.tagName("td"));
				Iterator iterator1 = cells.iterator();
				while (iterator1.hasNext()) {
					WebElement cell = (WebElement) iterator1.next();
					int newsearchcolumn = searchcolumn - 1;
					if (!cell.equals(cells.get(newsearchcolumn)))
						continue;
					String sampletext = cell.getText();
					if (!sampletext.equals(searchdata))
						continue;
					System.out.println("string found");
					completecelldata = cells;
					flaggetvalue = true;
					break;
				}
				if (flaggetvalue)
					break;
			}

			int newselectcolumn = selectcolumn - 1;
			WebElement element = (WebElement) completecelldata.get(newselectcolumn);
			if (checkFlag.equalsIgnoreCase("ON") || checkFlag.equalsIgnoreCase("TRUE")
					|| checkFlag.equalsIgnoreCase("YES") || checkFlag.equalsIgnoreCase("Y")) {
				if (!element.isSelected())
					element.click();
			} else if ((checkFlag.equalsIgnoreCase("OFF") || checkFlag.equalsIgnoreCase("FALSE")
					|| checkFlag.equalsIgnoreCase("NO") || checkFlag.equalsIgnoreCase("N")) && element.isSelected())
				element.click();
		}
	}

	public boolean isPresentintable(WebElement ele, int searchcolumn, String searchdata, int selectcolumn,
			String expectedtext) {
		List completecelldata = null;
		if (ele != null) {
			boolean flaggetvalue = false;
			List allRows = ele.findElements(By.tagName("tr"));
			for (Iterator iterator = allRows.iterator(); iterator.hasNext();) {
				WebElement row = (WebElement) iterator.next();
				List cells = row.findElements(By.tagName("td"));
				Iterator iterator1 = cells.iterator();
				while (iterator1.hasNext()) {
					WebElement cell = (WebElement) iterator1.next();
					int newsearchcolumn = searchcolumn - 1;
					if (!cell.equals(cells.get(newsearchcolumn)))
						continue;
					String sampletext = cell.getText();
					if (!sampletext.equals(searchdata))
						continue;
					System.out.println("string found");
					completecelldata = cells;
					flaggetvalue = true;
					break;
				}
				if (flaggetvalue)
					break;
			}

			int newselectcolumn = selectcolumn - 1;
			WebElement element = (WebElement) completecelldata.get(newselectcolumn);
			String actualtext = null;
			actualtext = element.getText();
			return actualtext.equalsIgnoreCase(expectedtext);
		} else {
			return false;
		}
	}

	public void waitforWindow(WebDriver driver, int timesec) {
		for (int ltimier = 0; driver.getWindowHandles().size() <= 1 && ltimier <= timesec; waitFor(1))
			System.out.println(driver.getWindowHandles().size());

		waitFor(5);
	}

	public void switchtoWindow(WebDriver driver) {
		String winHandle;
		for (Iterator iterator = driver.getWindowHandles().iterator(); iterator.hasNext(); driver.switchTo()
				.window(winHandle))
			winHandle = (String) iterator.next();

	}

	public void switchtoWindow(WebDriver driver, String window) {
		String pid = "";
		String cid = "";
		Set wlist = driver.getWindowHandles();
		Iterator itrw = wlist.iterator();
		if (wlist.size() > 1) {
			pid = (String) itrw.next();
			cid = (String) itrw.next();
			// System.out.println((new
			// StringBuilder(String.valueOf(pid))).append("-------------->").append(cid).toString());
			if (window.equalsIgnoreCase("parent"))
				driver.switchTo().window(pid);
			else if (window.equalsIgnoreCase("child")) {
				driver.switchTo().window(cid);
				System.out.println(cid);
			} else {
				driver.switchTo().window(window);
			}
		} else {
			pid = (String) itrw.next();
			if (window.equalsIgnoreCase("parent"))
				driver.switchTo().window(pid);
			else
				driver.switchTo().window(window);
		}
	}

	public boolean switchtoFrame(WebDriver driver, WebElement ele) {
		try {
			driver.switchTo().frame(ele);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public void switchtodefaultContent(WebDriver driver) {
		driver.switchTo().defaultContent();
	}

	public boolean searchandSelectlisttable(WebElement ele, int searchcolumn, String searchdata, int selectcolumn,
			String listitem) {
		List completecelldata = null;
		if (ele != null) {
			boolean flaggetvalue = false;
			List allRows = ele.findElements(By.tagName("tr"));
			for (Iterator iterator = allRows.iterator(); iterator.hasNext();) {
				WebElement row = (WebElement) iterator.next();
				List cells = row.findElements(By.tagName("td"));
				Iterator iterator1 = cells.iterator();
				while (iterator1.hasNext()) {
					WebElement cell = (WebElement) iterator1.next();
					int newsearchcolumn = searchcolumn - 1;
					if (!cell.equals(cells.get(newsearchcolumn)))
						continue;
					String sampletext = cell.getText();
					if (!sampletext.equals(searchdata))
						continue;
					System.out.println("string found");
					completecelldata = cells;
					flaggetvalue = true;
					break;
				}
				if (flaggetvalue)
					break;
			}

			int newselectcolumn = selectcolumn - 1;
			WebElement element = (WebElement) completecelldata.get(newselectcolumn);
			element.sendKeys(new CharSequence[] { listitem });
			String selectedtext = element.getText();
			return selectedtext.equalsIgnoreCase(listitem);
		} else {
			return false;
		}
	}

	public void roboAction(String tabstrokes) {
		int tabstrokescount = Integer.parseInt(tabstrokes);
		try {
			java.awt.Robot robot = new java.awt.Robot();
			for (int tab = 0; tab <= tabstrokescount; tab++) {
				Thread.sleep(1000L);
				robot.keyPress(9);
			}

			Thread.sleep(3000L);
			robot.keyRelease(10);
		} catch (java.awt.AWTException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void callAutoit(String Autoitpath) {
		try {
			Runtime.getRuntime().exec(Autoitpath);
			Thread.sleep(30000L);
			System.out.println("Autoit action done");
			Thread.sleep(3000L);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void implictwait(WebDriver driver, int timesec) {
		driver.manage().timeouts().implicitlyWait(timesec, TimeUnit.SECONDS);
	}

	/*
	 * *************************************************************************
	 * ******************** Name: writeValueExcel Purpose: This function writes
	 * a value in an excel cell Output: No output. In case of failure the
	 * exception is caught Author: Adarsh devappa
	 * *************************************************************************
	 * ********************
	 */
	public void writeValueExcel(Workbook wb, String workbookname, int rowIndex_, int celColPos, String valueMerlin,
			String type) {
		FileOutputStream fos;
		Row sheetRow = null;
		Cell cel = null;
		try {
			Sheet sh = wb.getSheet(workbookname);
			sheetRow = sh.getRow(rowIndex_);
			if (sheetRow == null)
				sheetRow = sh.createRow(rowIndex_);
			cel = sheetRow.getCell(celColPos);
			if (cel == null)
				cel = sheetRow.createCell(celColPos);

			if (type.equalsIgnoreCase("string")) {
				cel.setCellType(Cell.CELL_TYPE_STRING);
				cel.setCellValue(valueMerlin);
			}
			if (type.equalsIgnoreCase("float")) {
				// System.out.println("Existing value in the interest cell" +
				// cel.getNumericCellValue());
				NumberFormat fmt = NumberFormat.getInstance(Locale.ENGLISH);
				fmt.setParseIntegerOnly(false);
				double value = fmt.parse(valueMerlin).doubleValue();
				double celParsedDoubled = cel.getNumericCellValue();
				/*
				 * System.out.println("Existing value in cell: " +
				 * celParsedDoubled);
				 * System.out.println("Value from Merlin in cell: " + value);
				 */
				double accumulatedValue = celParsedDoubled + value;
				// System.out.println("Accumulated value: " + accumulatedValue);
				cel.setCellType(Cell.CELL_TYPE_NUMERIC);
				cel.setCellValue(accumulatedValue);

			} /*
			 * else if (type.equalsIgnoreCase("date")){ XSSFCreationHelper
			 * createHelper = (XSSFCreationHelper) wb.getCreationHelper();
			 * XSSFCellStyle cellStyle = (XSSFCellStyle)
			 * wb.createCellStyle();
			 * cellStyle.setDataFormat(createHelper.createDataFormat().
			 * getFormat("dd/MM/yyyy")); cel.setCellValue(value);
			 * cel.setCellStyle(cellStyle); }
			 */

			// fos = new FileOutputStream(Filepath);
			// wb.write(fos);
			// fos.close();
			// System.out.println("Value " + value + "is saved in the excel at
			// row " + rowIndex_ + " in column "+ celColPos);
		} catch (Exception e) {
			System.out.println("Value from merlin (failure)" + valueMerlin);
			System.out.println("Row index in pricing model (failure)" + rowIndex_);
			e.printStackTrace();
		}
	}

	/*
	 * *************************************************************************
	 * ******************** Name: getDropDownValues Purpose: This function
	 * retrieves all values of a given drop down object passed as a parameter
	 * Output: List with all the values of the dropdown Author: Adarsh devappa
	 * *************************************************************************
	 * ********************
	 */
	public List<String> getDropDownValues(WebElement dropDownObject) {
		List<String> listValues = new ArrayList<String>();
		List<WebElement> lists = dropDownObject.findElements(By.tagName("option"));
		for (WebElement element : lists) {
			String var2 = element.getText();
			// System.out.println(var2);
			listValues.add(var2);
		}
		for (String element2 : listValues) {
			System.out.println(element2);
		}
		return listValues;
	}

	public void selectValueFromUnorderedList(WebElement unorderedList, final String value) {
		List<WebElement> options = unorderedList.findElements(By.tagName("li"));

		for (WebElement option : options) {
			if (value.equalsIgnoreCase(option.getText().trim())) {
				// System.out.println(option.getText());
				option.click();
				break;
			}
		}
	}

	public void sendBackSpace(WebElement ele, int times) {
		for (int i = 0; i < times; i++) {
			ele.sendKeys(Keys.BACK_SPACE);
		}

	}

	/*
	 * *************************************************************************
	 * ******************** Name: getDivTableValue Purpose: This function
	 * retrieves the value of a div table field given its name Output: Value of
	 * the given field Author: Adarsh devappa
	 * *************************************************************************
	 * ********************
	 */
	public String getDivTableValue(WebElement ele, String fieldName) {

		List<WebElement> rows = ele.findElements(By.cssSelector("div"));
		for (WebElement row : rows) {
			WebElement field = row.findElement(By.cssSelector("dt"));
			System.out.println(field.getText().trim());
			if (field.getText().trim().equalsIgnoreCase(fieldName)) {
				// System.out.println("Field value: " +
				// field.findElement(By.xpath("..")).findElement(By.xpath("dd")).getText().trim());
				return field.findElement(By.xpath("..")).findElement(By.xpath("dd")).getText().trim();
			}
		}
		return "";
	}

	/*
	 * *************************************************************************
	 * ******************** Name: getLinkByText Purpose: Output: Author: Adarsh
	 * devappa
	 * *************************************************************************
	 * ********************
	 */
	public WebElement getLinkByText(WebElement eleHigherLevel, String attachedText) {
		List<WebElement> links = eleHigherLevel.findElements(By.xpath("//a"));
		for (WebElement linkInstance : links) {
			String actualAttachedText = linkInstance.getText().trim();
			// System.out.println(field.getText().trim());
			if (actualAttachedText.equalsIgnoreCase(attachedText)) {
				// System.out.println("Field value: " +
				// field.findElement(By.xpath("..")).findElement(By.xpath("dd")).getText().trim());
				return linkInstance;
			}
		}
		return null;
	}

	public String DoubleToStringNoDecimal(Double number_) {

		return String.format("%.0f", number_);

	}

	/*
	 * *************************************************************************
	 * ***************************************************** Name:
	 * excelDeleteSheet Purpose: This method deletes one sheet from the excel
	 * file passed as a parameter Output: void Author: Adarsh devappa
	 * *************************************************************************
	 * *****************************************************
	 */
	public void excelDeleteSheet(String fileOut, String sheetname) throws InvalidFormatException, IOException {

		FileInputStream fileStream_ = new FileInputStream(fileOut);
		// POIFSFileSystem fsPoi = new POIFSFileSystem(fileStream);
		Workbook wb = WorkbookFactory.create(fileStream_);
		Sheet sheet = wb.getSheet(sheetname);
		if (sheet != null) {
			int index = wb.getSheetIndex(sheetname);
			wb.removeSheetAt(index);

		}
		FileOutputStream fileOutStream = new FileOutputStream(fileOut);
		wb.write(fileOutStream);
		fileOutStream.close();
		fileStream_.close();

	}

	public void scrollTo(WebDriver driver, WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
	}

	public void writeResult_Excel(String ExcelPath, String Input_SheetName, int itercounter, int ColoumnNo,
			String Result) throws IOException {

		try {
			ex.writeStringValueIntoExcel(ExcelPath, Input_SheetName, itercounter, ColoumnNo, Result);

		} catch (Exception e) {
			Reporter.log("Exception in writeResult_Excel");

		}

	}

	public void writeResult_Excel_Status1(String ExcelPath, String Input_SheetName, int itercounter, String Result)
			throws IOException {

		try {
			ex.writeStringValueIntoExcel(ExcelPath, Input_SheetName, itercounter, 10, Result);

		} catch (Exception e) {
			Reporter.log("Exception in writeResult_Excel");

		}

	}

	public void writeResult_Excel_Status2(String ExcelPath, String Input_SheetName, int itercounter, String Result)
			throws IOException {

		try {
			ex.writeStringValueIntoExcel(ExcelPath, Input_SheetName, itercounter, 11, Result);

		} catch (Exception e) {
			Reporter.log("Exception in writeResult_Excel");

		}

	}

	public void writeFinalResult_Excel(String ExcelPath, String Input_SheetName, int Row, int col, String Result)
			throws IOException {

		try {
			ex.writeStringValueIntoExcel(ExcelPath, Input_SheetName, Row, col, Result);

		} catch (Exception e) {
			Reporter.log("Exception in writeResult_Excel");

		}

	}

	public void writeGeneric_OutputSheet_Excel(String ExcelPath, String SheetName, int itercounter, String ClassName,
			String Browser, String DataSet, int Output_TscNoCol, int Output_BrowserCol, int Output_DatasetCol)
					throws IOException {
		try {
			ex.writeStringValueIntoExcel(ExcelPath, SheetName, itercounter, 0, ClassName);
			ex.writeStringValueIntoExcel(ExcelPath, SheetName, itercounter, 1, Browser);
			ex.writeStringValueIntoExcel(ExcelPath, SheetName, itercounter, 2, DataSet);

		} catch (Exception e) {
			Reporter.log("Exception in writeGeneric_Excel");

		}

	}

	public void writeGeneric_AccountVerification_Excel(String ExcelPath, String SheetName, int itercounter,
			String ClassName, String DataSet, String ContractNo) throws IOException {
		try {
			ex.writeStringValueIntoExcel(ExcelPath, SheetName, itercounter, 0, ClassName);
			ex.writeStringValueIntoExcel(ExcelPath, SheetName, itercounter, 1, DataSet);
			ex.writeStringValueIntoExcel(ExcelPath, SheetName, itercounter, 2, ContractNo);

		} catch (Exception e) {
			Reporter.log("Exception in writeGeneric_Excel");

		}

	}

	public void writeStatus1_Excel(String ExcelPath, String SheetName, int itercounter, int ColoumnNo, String Value)
			throws IOException {
		try {
			ex.writeStringValueIntoExcel(ExcelPath, SheetName, itercounter, 6, Value);
		} catch (Exception e) {
			Reporter.log("Exception in writeStatus1_Excel");

		}
	}

	public void writeStatus2_Excel(String ExcelPath, String SheetName, int itercounter, int ColoumnNo, String Value)
			throws IOException {
		try {
			ex.writeStringValueIntoExcel(ExcelPath, SheetName, itercounter, 7, Value);
		} catch (Exception e) {
			Reporter.log("Exception in writeStatus2_Excel");

		}

	}

	public String Excel_SrcToDest(String SrcExcelPath, String ExcelPath, String TimeStamp) {

		try {
			File sourceFile;
			File destinationDir;
			sourceFile = new File(SrcExcelPath);

			String DesExcelPath = "C:\\Eclipse\\workspace\\NewTestAutomation\\Result\\Result_" + TimeStamp + "\\";

			ExcelPath = DesExcelPath + "DriverSheet.xlsx";
			destinationDir = new File(DesExcelPath);
			if (sourceFile.exists()) {
				FileUtils.copyFileToDirectory(sourceFile, destinationDir, true);
			} else {
				System.out.println("Required file is not Present in side folder");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ExcelPath;

	}

	public String DirectoryRename_withTimeStamp(String OldName) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		Date date = new Date();
		String TimeStamp = dateFormat.format(date);
		// create source File object
		File oldName = new File(OldName);

		// create destination File object
		File newName = new File(OldName + "_" + TimeStamp + "\\");

		/*
		 * To rename a file or directory, use boolean renameTo(File destination)
		 * method of Java File class.
		 * 
		 * This method returns true if the file was renamed successfully, false
		 * otherwise.
		 */

		boolean isFileRenamed = oldName.renameTo(newName);

		if (isFileRenamed) {
			// System.out.println("File has been renamed");
		} else {
			System.out.println("Error renaming the file");
		}
		return TimeStamp;
	}

	public void EndTimer_Total(long StartTime_TotalExecution, String ExcelPath, String ConfigSheet, int row, int col)
			throws IOException {
		long elapsedTimeMillis = System.currentTimeMillis() - StartTime_TotalExecution;
		int minutes = (int) ((elapsedTimeMillis / 1000) / 60);
		String elapsedTimeMin = Integer.toString(minutes);
		int seconds = (int) ((elapsedTimeMillis / 1000) % 60);
		String elapsedTimeSec = Integer.toString(seconds);
		ex.writeStringValueIntoExcel(ExcelPath, ConfigSheet, row, col,
				elapsedTimeMin + "Min " + elapsedTimeSec + "Sec");

	}

	public void EndTimer_Iteration(long StartTime_TotalExecution, String ExcelPath, String ConfigSheet, int row,int col) throws IOException {
		long elapsedTimeMillis = System.currentTimeMillis() - StartTime_TotalExecution;
			
		int minutes = (int) ((elapsedTimeMillis / 1000) / 60);
		String elapsedTimeMin = Integer.toString(minutes);
		int seconds = (int) ((elapsedTimeMillis / 1000) % 60);
		String elapsedTimeSec = Integer.toString(seconds);
		ex.writeStringValueIntoExcel(ExcelPath, ConfigSheet, row, col,
				elapsedTimeMin + "Min " + elapsedTimeSec + "Sec");

	}

	public void EndTimerTC004_Iteration(long StartTime_TotalExecution, String ExcelPath, String ConfigSheet, int row)
			throws IOException {
		long elapsedTimeMillis = System.currentTimeMillis() - StartTime_TotalExecution;
		int minutes = (int) ((elapsedTimeMillis / 1000) / 60);
		String elapsedTimeMin = Integer.toString(minutes);
		int seconds = (int) ((elapsedTimeMillis / 1000) % 60);
		String elapsedTimeSec = Integer.toString(seconds);
		ex.writeStringValueIntoExcel(ExcelPath, ConfigSheet, row, 9, elapsedTimeMin + "Min " + elapsedTimeSec + "Sec");

	}

	public void EndTimer(long StartTime_TotalExecution, String ExcelPath, String ConfigSheet, int row, int col)
			throws IOException {
		long elapsedTimeMillis = System.currentTimeMillis() - StartTime_TotalExecution;
		int minutes = (int) ((elapsedTimeMillis / 1000) / 60);
		String elapsedTimeMin = Integer.toString(minutes);
		int seconds = (int) ((elapsedTimeMillis / 1000) % 60);
		String elapsedTimeSec = Integer.toString(seconds);
		ex.writeStringValueIntoExcel(ExcelPath, ConfigSheet, row, col,
				elapsedTimeMin + "Min " + elapsedTimeSec + "Sec");

	}

	public void OpenAFile(String Path, String TimeStamp) {
		try {
			if ((new File(Path)).exists()) {
				Process p = Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + Path);
				p.waitFor();

			} else {

				System.out.println("File does not exist");

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void Move_SrcToDes(String SrcExcelPath, String DesExcelPath) {
		try {
			File sourceFile = new File(SrcExcelPath);
			File destinationDir = new File(DesExcelPath);
			if (sourceFile.exists()) {
				FileUtils.copyFileToDirectory(sourceFile, destinationDir, true);
			} else {
				System.out.println("Required file is not Present in side folder");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createOTR(XWPFDocument document, String testcasenumber, String scenariodescription) {
		try {
			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.DOUBLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.DOUBLE);
			paragraph.setBorderLeft(Borders.DOUBLE);
			XWPFRun run = paragraph.createRun();
			run.setBold(true);
			run.setFontSize(16);
			run.setText("Testcase Name: " + testcasenumber);
			// run.setText("Testcase Name : TC_0"+testcasenumber);
			paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.DOUBLE);
			paragraph.setBorderTop(Borders.SINGLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);

			run = paragraph.createRun();
			run.setText("");
			run.setText("");
			run.setText("");
			run.setText("");
			run.setText("");
			run.setText("");
			run.setBold(true);
			run.setFontSize(14);
			run.setText("Scenario Description: " + scenariodescription);
			run.addBreak(BreakType.PAGE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void captureupdateOTR(WebDriver driver, XWPFDocument document, String scenariodescription) {
		try {

			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.SINGLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);
			XWPFRun run = paragraph.createRun();
			run.setBold(true);
			
			run.setFontSize(14);
			run.setText(scenariodescription);
			paragraph = document.createParagraph();
			paragraph.setBorderBottom(Borders.DOUBLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.DOUBLE);
			paragraph.setBorderLeft(Borders.DOUBLE);
			paragraph.setAlignment(ParagraphAlignment.LEFT);
			run = paragraph.createRun();
			fis = new FileInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE));
			run.addBreak();
			run.addPicture(fis, Document.PICTURE_TYPE_JPEG, "test", Units.toEMU(450), Units.toEMU(250)); // 200x200
			//run.addPicture(fis, Document.PICTURE_TYPE_JPEG, "test", Units.toEMU(450), Units.toEMU(400)); // 200x200
			
			// pixels
			fis.close();
			run.addBreak(BreakType.PAGE);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	public String getScreenshot(WebDriver driver,String TestCaseName,int status,int stepNo) throws IOException
	{
	File src;
	String state;
	String ssPath="";
	if(status==1){
		state="PassScreenshots";
	}else if(status==0){
		state="FailedScreenshots";
	}else{
		state="SkippedScreenshots";
	}
	ssPath=ScreenShotLocation +TestCaseName+"\\"+state+"\\"+System.currentTimeMillis()+"_step_" + stepNo +".png";
	src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(src, new File(ssPath));  
	return ssPath;
	/*TakesScreenshot ts = (TakesScreenshot)driver;

    String dest = ts.getScreenshotAs(OutputType.BASE64);

    return "data:image/png;base64, " + dest ;
	*/
	}
	public void updatestatusOTR(XWPFDocument document, String Status) {
		try {

			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			paragraph.setBorderBottom(Borders.SINGLE);
			paragraph.setBorderTop(Borders.DOUBLE);
			paragraph.setBorderRight(Borders.SINGLE);
			paragraph.setBorderLeft(Borders.SINGLE);
			XWPFRun run = paragraph.createRun();
			if (Status.equalsIgnoreCase("passed")) {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("008000");
			} else if (Status.equalsIgnoreCase("failed")) {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("ff0000");
			} else {
				run.setBold(true);
				run.setFontSize(18);
				run.setColor("87CEFA");
				
			}
			run.setText("Execution Status : " + Status);

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void saveOTR(String writefileOTRpath, XWPFDocument document) {
		FileOutputStream out;
		try {
			out = new FileOutputStream(new File(writefileOTRpath));
			System.out.println("doc write " + writefileOTRpath);
			document.write(out);
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public String getCurrentdate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate localDate = LocalDate.now();
		String todaysdate = dtf.format(localDate);
		return todaysdate;
	}

	public String getfuturedate(int futuredays) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate localDate = LocalDate.now().plusDays(futuredays);
		String futuredate = dtf.format(localDate);
		return futuredate;
	}
	public  String CurrentDateAndTime(){
	DateFormat dateFormat = new SimpleDateFormat("MM_dd_yyyy HH_mm_ss");
	    //get current date time with Date()
	    Date date = new Date();
	    // Now format the date
	    String dateF= dateFormat.format(date);
		
	    return dateF;
	}
	
public String  getEnteredText(WebElement ele) {
	String actualstring = "" ;
	try {
		Thread.sleep(2000);
		actualstring = ele.getAttribute("value");
		return actualstring;
	} catch (Exception e) {
		System.out.println("isTextpresent exception catch block");
	}
	return actualstring;
}


public void ConvertStringToInt(String value ){
	
			    int strlen = value.length(); 
			  
		        for(int i = 0; i < strlen ; i++){         
		        char character = value.charAt(i); 
		        int ascii = (int) character; 
		        
		    }
		 // return ascii;
}

public void clearcacheInChrome() throws Exception{
	
	try{
		
	
		//Clear the cache for the ChromeDriver instance.
	driver.get("chrome://settings/clearBrowserData");
	driver.findElement(By.xpath("//*[@id='clearBrowsingDataConfirm']")).click();
	}
	catch(Exception e){
		logger.info(e.getMessage());
	}
}
}



