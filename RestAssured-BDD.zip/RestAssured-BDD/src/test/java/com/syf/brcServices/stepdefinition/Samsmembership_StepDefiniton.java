package com.syf.brcServices.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Reporter;

import runner.Baseclass;


public class Samsmembership_StepDefiniton extends Baseclass {
	
	@Given("^User prepares Get request to perform cml service with following paramateres:\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_prepares_Get_request_to_perform_cml_service_with_following_paramateres(String BaseURL, String Endpoint, String membershipNumber, String firstName, String middleInitial, String lastName) throws Throwable {
		//System.out.println("***Entered***");
		RestAssured.baseURI = BaseURL;
		System.out.println("*****"+BaseURL);
	    HashMap<String,Object> variable = new HashMap<String,Object>();
	    variable.put("membershipNumber",membershipNumber);
	    variable.put("firstName",firstName);
	    variable.put("middleInitial",middleInitial);
	    variable.put("lastName",lastName);
	     gRequest = RestAssured.given().contentType("application/json").body(variable);
	    		
	}
	
	@When("^Post request is triggered for the following endpoint: \"([^\"]*)\"$")
	public void post_request_is_triggered_for_the_following_endpoint(String endPoint) throws Throwable {
		try	{
			Reporter.log("INFO"+"@When: post request to be triggered", true);
			gResponse=gRequest.post(endPoint);
			Reporter.log("INFO"+"@When:Successfull");
		}catch(Exception e){
			Reporter.log("ERROR"+"Exception at @Given", true);
			Reporter.log("ERROR"+"StackTrace: "+e.toString(), true);
					e.printStackTrace();
					throw e;
		}
	}
	
	

	
	@Then("^validate userid \"([^\"]*)\"$")
	public void validate_userid(int responsecode) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 
		try	{
			Reporter.log("INFO"+"@Then: response code "+responsecode+" to be verified", true);
			Reporter.log("INFO"+"Response: "+gResponse.asString(), true);
			//Status code is verified
			 int statusResponse = gResponse.getStatusCode();
			 System.out.println(statusResponse);
				//int responsecode=gResponse.responsecode();
				AssertEquals_Int(statusResponse, responsecode, "Assertion of responsecode");
				Reporter.log("INFO"+"@Then:Successfull", true);
				
		}catch(Exception e){
			Reporter.log("ERROR"+ "Exception at @Then", true);
			Reporter.log("ERROR"+"StackTrace: "+e.toString(), true);
					e.printStackTrace();
					throw e;
		}
	}
	
	@Then("^validate JSONresponse \"([^\"]*)\"$") 
	public void validate_JSONresponse(int responsecode) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 
		try	{
			Reporter.log("INFO"+"@Then: response code "+responsecode+" to be verified", true);
			Reporter.log("INFO"+"Response: "+gResponse.asString(), true);
			//Status code is verified
			String responseBody = gResponse.getBody().asString();
			System.out.println(responseBody);
			JsonPath jpEvaluator = gResponse.jsonPath();
		String string = jpEvaluator.get("message");
		System.out.println(string);
            List<Map<String,String>> xref = gResponse.jsonPath().getList("errors");
            for(int i=0;i<xref.size();i++)
            {
                   System.out.println(xref.get(i).get("reason"));
            }

//			JsonPath jsonPath = new JsonPath(responseBody);
//			int code = jsonPath.getInt("code");
//			String code = jsonPath.getString("code");
//			System.out.println(code);
//			 int statusResponse = gResponse.getStatusCode();
//			 System.out.println(statusResponse);
				//int responsecode=gResponse.responsecode();
				//AssertEquals_String(responseBody, responsecode, "Assertion of responsecode");
				Reporter.log("INFO"+"@Then:Successfull", true);
				
		}catch(Exception e){
			Reporter.log("ERROR"+ "Exception at @Then", true);
			Reporter.log("ERROR"+"StackTrace: "+e.toString(), true);
					e.printStackTrace();
					throw e;
		}
		}
}
