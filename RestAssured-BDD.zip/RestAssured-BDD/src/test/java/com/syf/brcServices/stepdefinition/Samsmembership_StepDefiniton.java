package com.syf.brcServices.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import groovy.util.logging.Log;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.*;
import restassured.utilities.GenericMethods;

import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Reporter;

import runner.Baseclass;


public class Samsmembership_StepDefiniton extends Baseclass {

	WebDriver driver;	
	public static HashMap<String, String> testdataHashMap;
	public static FileInputStream fi=null;
	public static Workbook wb = null;
	public static FileOutputStream fo=null;





	@Given("^User prepares Get request to perform cml service with following paramateres:\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_prepares_Get_request_to_perform_cml_service_with_following_paramateres(String BaseURL, String EndPoint, String GrantType) throws Throwable {
		RestAssured.baseURI = BaseURL;
		System.out.println("*****"+BaseURL);
		HashMap<String,Object> headers = new HashMap<String,Object>();
		headers.put("Content-Type","application/x-www-form-urlencoded");
		headers.put("grant_type"," ");
		gRequest =  RestAssured.given().contentType("application/json").headers(headers).body("grant_type=client_credentials&client_id=IPSGnXxLfI47wthZgLStP4vsMX5zkB1t&client_secret=xjypNdyYokRBIujm");
		gResponse=gRequest.post(EndPoint);
	}

	
	@Then("^User prepares Get request to perform cml service with following paramateres:\"([^\"]*)\" and \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_prepares_Get_request_to_perform_cml_service_with_following_paramateres_and(int RowNumber, String ApplyBaseURL, String ApplyEndpoint) throws Throwable {
		RestAssured.baseURI = ApplyBaseURL;
		System.out.println("*****"+ApplyBaseURL);

		LinkedHashMap<String,Object> APIGEEheaders = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> APIGEEheaders = new HashMap<String,Object>();
		APIGEEheaders.put("Authorization","Bearer" + " " + AccesToken);
		//APIGEEheaders.put("X-SYF-Request-operator", "ECOM");
		APIGEEheaders.put("X-SYF-Request-clientId", "lowes brc");
		//APIGEEheaders.put("X-SYF-Request-register", "REGISTER");
		//APIGEEheaders.put("X-SYF-Request-country", "US");

		testdataHashMap = getDataFromExcel(System.getProperty("user.dir")+"\\testdata\\CMLServiceTestData.xlsx",
				"FincenFlow", 0, RowNumber);
		
		//MerchantInfo

		LinkedHashMap<String,Object> merchantInfo = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> merchantInfo = new HashMap<String,Object>();
		merchantInfo.put("deviceType",testdataHashMap.get("deviceType"));
		merchantInfo.put("merchantNumber", testdataHashMap.get("merchantNumber"));
		merchantInfo.put("merchantSiteId", testdataHashMap.get("merchantSiteId"));
		merchantInfo.put("productCode", testdataHashMap.get("productCode"));
		merchantInfo.put("productType", testdataHashMap.get("productType"));
		merchantInfo.put("salesPersonNumber", testdataHashMap.get("salesPersonNumber"));


		//Fincen

		//HashMap<String,Object> fincen = new HashMap<String,Object>();
		LinkedHashMap<String,Object> fincen = new LinkedHashMap<String,Object>();


		//Bussiness Info
		//	HashMap<String,Object> businessInfo = new HashMap<String,Object>();
		LinkedHashMap<String,Object> businessInfo = new LinkedHashMap<String,Object>();

		//companyAddress
		LinkedHashMap<String,Object> companyAddress = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> companyAddress = new HashMap<String,Object>();
		companyAddress.put("addressLine1", testdataHashMap.get("companyaddressLine1"));
		companyAddress.put("addressLine2", testdataHashMap.get("companyaddressLine2"));
		companyAddress.put("city", testdataHashMap.get("companycity"));
		companyAddress.put("state", testdataHashMap.get("companystate"));
		companyAddress.put("zipCode", testdataHashMap.get("companyzipCode"));

		//companyContact
		LinkedHashMap<String,Object> companyContact = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> companyContact = new HashMap<String,Object>();
		companyContact.put("companyName", testdataHashMap.get("companyName"));


		//contacts
		LinkedHashMap<String,Object> contacts = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> contacts = new HashMap<String,Object>();
		contacts.put("contactType", testdataHashMap.get("companycontactType"));
		contacts.put("contactNumber", testdataHashMap.get("companycontactNumber"));
		contacts.put("contactExtension", testdataHashMap.get("companycontactExtension"));

		List<LinkedHashMap<String,Object>> Companycontacts = new ArrayList<LinkedHashMap<String,Object>>();
		Companycontacts.add(contacts);


		companyContact.put("contacts", Companycontacts);


		LinkedHashMap<String,Object> billingAddress = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> billingAddress = new HashMap<String,Object>();
		billingAddress.put("addressLine1", testdataHashMap.get("billingAddressaddressLine1"));
		billingAddress.put("addressLine2", testdataHashMap.get("billingAddressaddressLine2"));
		billingAddress.put("city", testdataHashMap.get("billingAddresscity"));
		billingAddress.put("state", testdataHashMap.get("billingAddressstate"));
		billingAddress.put("zipCode", testdataHashMap.get("billingAddresszipCode"));

		LinkedHashMap<String,Object> billingContact = new LinkedHashMap<String,Object>();

		//HashMap<String,Object> billingContact = new HashMap<String,Object>();
		billingContact.put("name", testdataHashMap.get("billingContactname"));

		LinkedHashMap<String,Object> contact = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> contact = new HashMap<String,Object>();
		contact.put("contactType", testdataHashMap.get("billingcontactType"));
		contact.put("contactNumber", testdataHashMap.get("billingcontactNumber"));
		contact.put("contactExtension", testdataHashMap.get("billingcontactExtension"));


		List<LinkedHashMap<String,Object>> Billingcontacts = new ArrayList<LinkedHashMap<String,Object>>();
		Billingcontacts.add(contact);


		billingContact.put("contacts", Billingcontacts);

		//finalbusinessInfo

		businessInfo.put("companyAddress", companyAddress);   
		businessInfo.put("companyContact", companyContact);
		businessInfo.put("billingAddress", billingAddress);
		businessInfo.put("billingContact", billingContact);

		businessInfo.put("emailAddress", testdataHashMap.get("BillingemailAddress"));
		businessInfo.put("inBusinessSince", testdataHashMap.get("BillinginBusinessSince"));
		businessInfo.put("creditLineRequested", testdataHashMap.get("BillingcreditLineRequested"));
		businessInfo.put("annualRevenue", testdataHashMap.get("BillingannualRevenue"));
		businessInfo.put("doingBusinessAs", testdataHashMap.get("BillingdoingBusinessAs"));
		businessInfo.put("numberOfEmployees", testdataHashMap.get("BillingnumberOfEmployees"));
		businessInfo.put("dunsNumber", testdataHashMap.get("BillingdunsNumber"));
		businessInfo.put("promoCode", testdataHashMap.get("BillingpromoCode"));
		businessInfo.put("taxExemptFlag", testdataHashMap.get("BillingtaxExemptFlag"));
		businessInfo.put("taxNumber", testdataHashMap.get("BillingtaxNumber"));
		businessInfo.put("businessTypeCode", testdataHashMap.get("BillingbusinessTypeCode"));


		//AUTHORIZED Info
		LinkedHashMap<String,Object> authorizedRepresentativeInfo = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> authorizedRepresentativeInfo = new HashMap<String,Object>();
		authorizedRepresentativeInfo.put("firstName", testdataHashMap.get("authorizedRepresentativefirstName"));
		authorizedRepresentativeInfo.put("middleInitial", testdataHashMap.get("authorizedRepresentativemiddleInitial"));
		authorizedRepresentativeInfo.put("lastName", testdataHashMap.get("authorizedRepresentativelastName"));
		authorizedRepresentativeInfo.put("jobTitle", testdataHashMap.get("authorizedRepresentativejobTitle"));
		authorizedRepresentativeInfo.put("emailAddress", testdataHashMap.get("authorizedRepresentativeemailAddress"));
		authorizedRepresentativeInfo.put("membershipNumber", testdataHashMap.get("authorizedRepresentativemembershipNumber"));
		authorizedRepresentativeInfo.put("homePhone", testdataHashMap.get("authorizedRepresentativehomePhone"));

		//PersonalGuarantor
		LinkedHashMap<String,Object> personalGuarantorInfo = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> personalGuarantorInfo = new HashMap<String,Object>();
		LinkedHashMap<String,Object> address = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> address = new HashMap<String,Object>();
		address.put("addressLine1", testdataHashMap.get("personalGuarantoraddressLine1"));
		address.put("addressLine2", testdataHashMap.get("personalGuarantoraddressLine2"));
		address.put("city", testdataHashMap.get("personalGuarantorcity"));
		address.put("state", testdataHashMap.get("personalGuarantorstate"));
		address.put("zipCode", testdataHashMap.get("personalGuarantorzipCode"));


		//finalpersonalGuarantorInfo

		personalGuarantorInfo.put("address", address);

		personalGuarantorInfo.put("firstName", testdataHashMap.get("personalGuarantorfirstName"));
		personalGuarantorInfo.put("middleInitial", testdataHashMap.get("personalGuarantormiddleInitial"));
		personalGuarantorInfo.put("lastName", testdataHashMap.get("personalGuarantorlastName"));
		personalGuarantorInfo.put("applicantIncome", testdataHashMap.get("personalGuarantorapplicantIncome"));
		personalGuarantorInfo.put("dateOfBirth", testdataHashMap.get("personalGuarantordateOfBirth"));
		personalGuarantorInfo.put("socialSecurityNumber", testdataHashMap.get("personalGuarantorsocialSecurityNumber"));
		personalGuarantorInfo.put("jobTitle", testdataHashMap.get("personalGuarantorjobTitle"));
		personalGuarantorInfo.put("isPersonalGuarantorAvailable", true);



		//authorizedBuyersInfo
		LinkedHashMap<String,Object> authorizedBuyersInfo = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> authorizedBuyersInfo = new HashMap<String,Object>();
		LinkedHashMap<String,Object> info = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> info = new HashMap<String,Object>();
		info.put("cardRequired", true);
		info.put("memberNumber", testdataHashMap.get("authorizedBuyersmemberNumber"));
		info.put("name", testdataHashMap.get("authorizedBuyersname"));
		info.put("socialSecurityNumber", testdataHashMap.get("authorizedBuyerssocialSecurityNumber"));


		List<LinkedHashMap<String,Object>> AuthorizedBuyersInfo = new ArrayList<LinkedHashMap<String,Object>>();
		AuthorizedBuyersInfo.add(info);
		//finalauthorizedBuyersInfo
		authorizedBuyersInfo.put("info", AuthorizedBuyersInfo);


		authorizedBuyersInfo.put("numberOfCards", testdataHashMap.get("authorizedBuyersnumberOfCards"));
		authorizedBuyersInfo.put("isPONumberAvailable", testdataHashMap.get("authorizedBuyersisPONumberAvailable"));
		authorizedBuyersInfo.put("singleSaleLimit", testdataHashMap.get("authorizedBuyerssingleSaleLimit"));

		LinkedHashMap<String,Object> controllershipInfo = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> controllershipInfo = new HashMap<String,Object>();

		LinkedHashMap<String,Object> Controlleraddress = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> Controlleraddress = new HashMap<String,Object>();
		Controlleraddress.put("addressLine1", testdataHashMap.get("controllershipaddressLine1"));
		Controlleraddress.put("addressLine2", testdataHashMap.get("controllershipaddressLine2"));
		Controlleraddress.put("city", testdataHashMap.get("controllershipcity"));
		Controlleraddress.put("state", testdataHashMap.get("controllershipstate"));
		Controlleraddress.put("zipCode", testdataHashMap.get("controllershipzipCode"));

		controllershipInfo.put("address", Controlleraddress);

		controllershipInfo.put("firstName", testdataHashMap.get("controllershipfirstName"));
		controllershipInfo.put("middleInitial", testdataHashMap.get("controllershipmiddleInitial"));
		controllershipInfo.put("lastName", testdataHashMap.get("controllershiplastName"));
		controllershipInfo.put("dateOfBirth", testdataHashMap.get("controllershipdateofbirth"));
		controllershipInfo.put("identityNumber", testdataHashMap.get("controllershipidentityNumber"));
		controllershipInfo.put("identityIssueDate", testdataHashMap.get("controllershipidentityIssueDate"));
		controllershipInfo.put("identityExpiryDate", testdataHashMap.get("controllershipidentityExpiryDate"));
		controllershipInfo.put("countryIssuance", testdataHashMap.get("controllershipcountryIssuance"));
		controllershipInfo.put("countryCode", testdataHashMap.get("controllershipcountryCode"));
		controllershipInfo.put("legalDescription", testdataHashMap.get("controllershiplegalDescription"));
		controllershipInfo.put("ownerIndicator", testdataHashMap.get("controllershipownerIndicator"));
		controllershipInfo.put("socialSecurityNumber", testdataHashMap.get("controllershipsocialSecurityNumber"));
		controllershipInfo.put("jobTitle", testdataHashMap.get("controllershipjobTitle"));
		controllershipInfo.put("usCitizen", testdataHashMap.get("controllershipusCitizen"));

		//finalcontrollershipInfo


		//beneficialOwnersInfo


		LinkedHashMap<String,Object> beneficialOwnersOtherInfo = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> beneficialOwnersOtherInfo = new HashMap<String,Object>();


		LinkedHashMap<String,Object> beneficialaddress = new LinkedHashMap<String,Object>();
		//HashMap<String,Object> beneficialaddress = new HashMap<String,Object>();

		beneficialaddress.put("addressLine1", testdataHashMap.get("beneficialOwnersaddressLine1"));
		beneficialaddress.put("addressLine2", testdataHashMap.get("beneficialOwnersaddressLine2"));
		beneficialaddress.put("city", testdataHashMap.get("beneficialOwnerscity"));
		beneficialaddress.put("state", testdataHashMap.get("beneficialOwnersstate"));
		beneficialaddress.put("zipCode", testdataHashMap.get("beneficialOwnerszipCode"));

		beneficialOwnersOtherInfo.put("address",beneficialaddress);

		beneficialOwnersOtherInfo.put("firstName", testdataHashMap.get("beneficialOwnersfirstName"));
		beneficialOwnersOtherInfo.put("middleInitial", testdataHashMap.get("beneficialOwnersmiddleInitial"));
		beneficialOwnersOtherInfo.put("lastName", testdataHashMap.get("beneficialOwnerslastName"));
		beneficialOwnersOtherInfo.put("dateOfBirth", testdataHashMap.get("beneficialOwnersdateOfBirth"));
		beneficialOwnersOtherInfo.put("socialSecurityNumber", testdataHashMap.get("beneficialOwnerssocialSecurityNumber"));
		beneficialOwnersOtherInfo.put("usCitizen", testdataHashMap.get("beneficialOwnersusCitizen"));
		beneficialOwnersOtherInfo.put("legalDescription", testdataHashMap.get("beneficialOwnerslegalDescription"));
		beneficialOwnersOtherInfo.put("ownerIndicator", testdataHashMap.get("beneficialOwnersownerIndicator"));
		beneficialOwnersOtherInfo.put("countryCode", testdataHashMap.get("beneficialOwnerscountryCode"));
		beneficialOwnersOtherInfo.put("identityNumber", testdataHashMap.get("beneficialOwnersidentityNumber"));
		beneficialOwnersOtherInfo.put("identityIssueDate", testdataHashMap.get("beneficialOwnersidentityIssueDate"));
		beneficialOwnersOtherInfo.put("identityExpiryDate", testdataHashMap.get("beneficialOwnersidentityExpiryDate"));
		beneficialOwnersOtherInfo.put("countryIssuance", testdataHashMap.get("beneficialOwnerscountryIssuance"));

		List<LinkedHashMap<String,Object>> beneficialownerandaddressinfo = new ArrayList<LinkedHashMap<String,Object>>();
		beneficialownerandaddressinfo.add(beneficialOwnersOtherInfo);


		//Finalfincen

		fincen.put("businessInfo", businessInfo);
		fincen.put("authorizedRepresentativeInfo", authorizedRepresentativeInfo);
		fincen.put("personalGuarantorInfo", personalGuarantorInfo);
		fincen.put("authorizedBuyersInfo", authorizedBuyersInfo);
		fincen.put("controllershipInfo", controllershipInfo);
		fincen.put("beneficialOwnersInfo", beneficialownerandaddressinfo);


		LinkedHashMap<String,Object> EndToEndFincenFlow = new LinkedHashMap<String,Object>();
		EndToEndFincenFlow.put("merchantInfo", merchantInfo);
		EndToEndFincenFlow.put("businessType", testdataHashMap.get("businessType"));
		EndToEndFincenFlow.put("fincen", fincen);




		EncoderConfig encoderconfig = new EncoderConfig();
		gRequest =  RestAssured.given().headers(APIGEEheaders).contentType("application/json").config(RestAssured.config().encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false))).body(EndToEndFincenFlow);
		System.out.println(gRequest.log().all());
		gResponse=gRequest.post(ApplyEndpoint);
		System.out.println(gResponse.asString());

	}




	@Then("^Validate TokenID response: \"([^\"]*)\"$")
	public void  validate_TokenID_response(String token_type) throws Throwable {
		try	{
			Reporter.log("INFO"+"@Then: response code "+token_type+" to be verified", true);
			Reporter.log("INFO"+"Response: "+gResponse.asString(), true);
			//Status code is verified
			String responseBody = gResponse.getBody().asString();
			//System.out.println(responseBody);
			GenericMethods.CucumberReportWrite("INFO"+"@Then: response code "+ responseBody +" to be verified");
			Reporter.log("responseBody");
			JsonPath jpEvaluator = gResponse.jsonPath();
			String string = jpEvaluator.get("token_type");
			System.out.println(string);
			AccesToken=gResponse.jsonPath().get("access_token");
			/*List<Map<String,Object>> xref = gResponse.jsonPath().getList("status");
			for(int i=0;i<xref.size();i++)
			{
				 System.out.println(xref.get(i).get("access_token"));
				System.out.println(xref.get(i).get("client_id"));
				System.out.println(xref.get(i).get("status"));
			}*/
			System.out.println(AccesToken);
			Reporter.log("INFO"+"@Then:Successfull", true);

		}catch(Exception e){
			Reporter.log("status"+ "Exception at @Then", true);
			Reporter.log("status"+"StackTrace: "+e.toString(), true);
			e.printStackTrace();
			throw e;
		}
	}

	@Then("^validate various JSon Responses for positive and Negative requests: \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void validate_various_JSon_Responses_for_positive_and_Negative_requests(String decisionCod, String decisionDesc, String applicationId, String decisionProductCode, String foreignLanguageIndicator, String tempClExpDate, String temporaryCreditLine, String accountNumber, String creditLine, String securityCode) throws Throwable {
		try	{
			Reporter.log("INFO"+"@Then: response code "+DecisionCode+" to be verified", true);
			Reporter.log("INFO"+"Response: "+gResponse.asString(), true);
			//Status code is verified
			String responseBody = gResponse.getBody().asString();
			//	System.out.println(responseBody);
			Reporter.log("responseBody");
			GenericMethods.CucumberReportWrite("INFO"+"@Then: response code "+ responseBody +" to be verified");
			JsonPath jpEvaluator = gResponse.jsonPath();
			String JsonDecisionDesc = jpEvaluator.get("decisionDesc");

			DecisionDesc=gResponse.jsonPath().get("decisionDesc");
			DecisionCode=gResponse.jsonPath().get("decisionCode");
			TempClExpDate=gResponse.jsonPath().get("plccApplicantionResponse.accountInfo.tempClExpDate");
			ForeignLanguageIndicator = gResponse.jsonPath().getString("plccApplicantionResponse.foreignLanguageIndicator");
			System.out.println(DecisionDesc);
			System.out.println(TempClExpDate);

			AssertEquals_String(DecisionCode, decisionCod, "Assertion of responsecode");
			AssertEquals_String(DecisionDesc, decisionDesc, "Assertion of responsecode");


			Reporter.log("INFO"+"@Then:Successfull", true);

		}catch(Exception e){
			Reporter.log("status"+ "Exception at @Then", true);
			Reporter.log("status"+"StackTrace: "+e.toString(), true);
			e.printStackTrace();
			throw e;
		}
	}


	@Then("^validate userid \"([^\"]*)\"$")
	public void validate_userid(int responsecode) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		try	{
			Reporter.log("INFO"+"@Then: response code "+responsecode+" to be verified", true);
			Reporter.log("INFO"+"Response: "+gResponse.asString(), true);
			//Status code is verified
			int statusResponse = gResponse.getStatusCode();
			System.out.println(statusResponse);
			//int responsecode=gResponse.responsecode();
			AssertEquals_Int(statusResponse, responsecode, "Assertion of responsecode");
			Reporter.log("INFO"+"@Then:Successfull", true);




		}catch(Exception e){
			Reporter.log("ERROR"+ "Exception at @Then", true);
			Reporter.log("ERROR"+"StackTrace: "+e.toString(), true);
			e.printStackTrace();
			throw e;
		}
	}


	@Then("^validate Json APIGEE response$")
	public void validate_Json_APIGEE_response() throws Throwable {
		Reporter.log("INFO"+"@Then: response code "+ DecisionDesc +" to be verified", true);
		GenericMethods.CucumberReportWrite("INFO"+"@Then: response code "+ DecisionDesc +" to be verified");
		Reporter.log("INFO"+"Response: "+gResponse.asString(), true);
		//Status code is verified
		String EndResponse = gResponse.getBody().asString();
		Reporter.log("EndResponse");
		JsonPath jpEvaluator = gResponse.jsonPath();
		String string = jpEvaluator.get("decisionCode");
		Errors = gResponse.jsonPath().getString("errors");

	}


	@Given("^User prepares Get request to perform cml service with following paramateres:\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_prepares_Get_request_to_perform_cml_service_with_following_paramateres(String BaseURL, String Endpoint, String membershipNumber, String firstName, String middleInitial, String lastName) throws Throwable {
		//System.out.println("***Entered***");
		RestAssured.baseURI = BaseURL;
		System.out.println("*****"+BaseURL);
		HashMap<String,Object> variable = new HashMap<String,Object>();
		variable.put("membershipNumber",membershipNumber);
		variable.put("firstName",firstName);
		variable.put("middleInitial",middleInitial);
		variable.put("lastName",lastName);
		gRequest = RestAssured.given().contentType("application/json").body(variable);

	}

	@When("^Post request is triggered for the following endpoint: \"([^\"]*)\"$")
	public void post_request_is_triggered_for_the_following_endpoint(String ApplyEndpoint) throws Throwable {
		try	{
			Reporter.log("INFO"+"@When: post request to be triggered", true);
			gResponse=gRequest.post(ApplyEndpoint);
			System.out.println(gResponse);
			Reporter.log("INFO"+"@When:Successfull");
		}catch(Exception e){
			Reporter.log("ERROR"+"Exception at @Given", true);
			Reporter.log("ERROR"+"StackTrace: "+e.toString(), true);
			e.printStackTrace();
			throw e;
		}
	}






	@Then("^validate JSONresponse \"([^\"]*)\"$") 
	public void validate_JSONresponse(int code) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		try	{
			Reporter.log("INFO"+"@Then: response code "+code+" to be verified", true);
			Reporter.log("INFO"+"Response: "+gResponse.asString(), true);
			//Status code is verified
			String responseBody = gResponse.getBody().asString();
			System.out.println(responseBody);
			Reporter.log("responseBody");
			JsonPath jpEvaluator = gResponse.jsonPath();
			String string = jpEvaluator.get("message");
			System.out.println(string);
			List<Map<String,Object>> xref = gResponse.jsonPath().getList("status");
			for(int i=0;i<xref.size();i++)
			{
				System.out.println(xref.get(i).get("response_code"));
				System.out.println(xref.get(i).get("response_desc"));
				System.out.println(xref.get(i).get("trans_id"));


			}


			Reporter.log("INFO"+"@Then:Successfull", true);

		}catch(Exception e){
			Reporter.log("status"+ "Exception at @Then", true);
			Reporter.log("status"+"StackTrace: "+e.toString(), true);
			e.printStackTrace();
			throw e;
		}
	}


	@Given("^User prepares Get request to perform cml service with following paramateres:\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_prepares_Get_request_to_perform_cml_service_with_following_paramateres(String BaseURL, String EndPoint, String account_number, String header, String calling_api, String channel, String client_id, String trans_id) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		RestAssured.baseURI = BaseURL;
		System.out.println("*****"+BaseURL);
		HashMap<String,Object> variable = new HashMap<String,Object>();
		variable.put("BaseURL",BaseURL);
		variable.put("EndPoint",EndPoint);
		variable.put("account_number",account_number);
		variable.put("header",header);
		variable.put("calling_api",calling_api);
		variable.put("channel",channel);
		variable.put("client_id",client_id);
		variable.put("trans_id",trans_id);
		gRequest = RestAssured.given().contentType("application/json").body(variable);

	}	


	@Given("^User prepares Get request to perform cml service with following paramateres:\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_prepares_Get_request_to_perform_cml_service_with_following_paramateres(String BaseURL, String EndPoint) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		RestAssured.baseURI = BaseURL;
		System.out.println("*****"+BaseURL);
		HashMap<String,Object> variable = new HashMap<String,Object>();
		variable.put("EndPoint",EndPoint);
		gRequest = RestAssured.given().contentType("application/json").body(variable);

	}



	@Then("^validate the JSon response$")
	public void validate_the_JSon_response() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	public  static HashMap<String, String> getDataFromExcel(String path,String sheetname, int startRow, int endRow)
	{
		HashMap< String, String> hashMap=new HashMap<String, String>();
		int cellCount;
		try {
			fi=new FileInputStream(path);
			wb = WorkbookFactory.create(fi);
			Sheet sh=wb.getSheet(sheetname);
			cellCount =sh.getRow(startRow).getLastCellNum();
			for (int j = 0; j < cellCount; j++) 
			{
				hashMap.put(sh.getRow(0).getCell(j).getStringCellValue().toString(), sh.getRow(endRow).getCell(j).getStringCellValue().toString());
			}

		} 
		catch(NullPointerException exception)
		{
			System.out.println(exception.getMessage());
		}
		catch (EncryptedDocumentException e) {

			System.out.println(e.getMessage());	
		} catch (InvalidFormatException e) {

			System.out.println(e.getMessage());	
		}  catch (FileNotFoundException e1) {

			System.out.println(e1.getMessage());
		}
		catch (IOException e) {
			System.out.println(e.getMessage());	
		}
		catch (Exception e) {
			System.out.println(e.getMessage());	
		}
		return hashMap;

	}

	@Then("^validate various JSon Responses:\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void validate_various_JSon_Responses(String code, String message, String Transient, String remediationInfo, String userMessage) throws Throwable {
		try{
			Reporter.log("INFO"+"@Then: response code "+DecisionCode+" to be verified", true);
			Reporter.log("INFO"+"Response: "+gResponse.asString(), true);
			//Status code is verified
			String responseBody = gResponse.getBody().asString();
			//	System.out.println(responseBody);
			Reporter.log("responseBody");
			JsonPath jpEvaluator = gResponse.jsonPath();
			String JsonDecisionDesc = jpEvaluator.get("code");

			DecisionDesc=gResponse.jsonPath().get("code");
			DecisionCode=gResponse.jsonPath().get("message");
			DecisionCode=gResponse.jsonPath().get("Transient");
			DecisionCode=gResponse.jsonPath().get("remediationInfo");
			DecisionCode=gResponse.jsonPath().get("userMessage");
			TempClExpDate=gResponse.jsonPath().get("plccApplicantionResponse.accountInfo.tempClExpDate");

			System.out.println(DecisionDesc);
			System.out.println(TempClExpDate);

			AssertEquals_String(DecisionCode, code, "Assertion of responsecode");
			AssertEquals_String(DecisionDesc, message, "Assertion of responsecode");
			AssertEquals_String(DecisionDesc, Transient, "Assertion of responsecode");
			AssertEquals_String(DecisionDesc, remediationInfo, "Assertion of responsecode");
			AssertEquals_String(DecisionDesc, userMessage, "Assertion of responsecode");



			Reporter.log("INFO"+"@Then:Successfull", true);

		}catch(Exception e){
			Reporter.log("status"+ "Exception at @Then", true);
			Reporter.log("status"+"StackTrace: "+e.toString(), true);
			e.printStackTrace();
			throw e;
		}
	}

	@Given("^User prepares Get request to perform cml service with following paramateres:\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_prepares_Get_request_to_perform_cml_service_with_following_paramateres(String BaseURL, String EndPoint, String GrantType, String Content_Type) throws Throwable {
		RestAssured.baseURI = BaseURL;
		System.out.println("*****"+BaseURL);
		//	HashMap<String,Object> variable = new HashMap<String,Object>();
		//variable.put("GrantType",GrantType);
		//	variable.put("grant_type","client_credentials");
		HashMap<String,Object> headers = new HashMap<String,Object>();
		headers.put("Content-Type","application/x-www-form-urlencoded");
		headers.put("grant_type"," ");
		gRequest =  RestAssured.given().contentType("application/json").headers(headers).body("grant_type=client_credentials&client_id=IPSGnXxLfI47wthZgLStP4vsMX5zkB1t&client_secret=xjypNdyYokRBIujm");
		//	gRequest = RestAssured.given().contentType("application/json").headers(headers)
		System.out.println(gRequest);
	}
}