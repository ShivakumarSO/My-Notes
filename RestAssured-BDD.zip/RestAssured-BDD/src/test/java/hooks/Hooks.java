package hooks;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.it.Date;
import restassured.utilities.GenericUtilities;
import runner.Baseclass;

public class Hooks extends Baseclass{
	
	@SuppressWarnings("deprecation")
	@Before
	public void Before(Scenario scenario) {
		gstrScenarioName=scenario.getName();
		String[] ScenarioNameArr = gstrScenarioName.split("_");
		String TCName = ScenarioNameArr[0];
		System.out.println(TCName);
		Reporter.log("************************ StartTest - "+ TCName +" ************************");
		CucumberWrite ="";
	}
	@After
	public void After(Scenario scenario) throws Exception {
		//Reseting Request and Response
		gRequest=null;
		gResponse=null;
		gstrScenarioName=scenario.getName();
		
		try {
			
			boolean Result=scenario.isFailed();
			if(Result==false) {
				Reporter.log("Status:"+"Passed");
				scenario.write("PASS:"+"Passed");
				scenario.write("*****************************************************Passed Logs*****************************************************");
				scenario.write(CucumberWrite);
			}else {
				Reporter.log("Status:"+"Failed");
				scenario.write("FAIL:"+"Failed");
				scenario.write("*****************************************************Failed Logs*****************************************************");
				scenario.write(CucumberWrite);
			}
		} catch(Exception e) {
			Reporter.log("ERROR:"+"Exception at Hooks @After");
			scenario.write("ERROR:"+"Exception at Hooks @After");
			Reporter.log("ERROR:"+"StackTrace: "+e.toString());
			scenario.write("ERROR:"+"StackTrace: "+e.toString());
				e.printStackTrace();
				throw e;
		}
		Reporter.log("************************ EndTest - "+gstrScenarioName+" ************************");
	}
	
}
