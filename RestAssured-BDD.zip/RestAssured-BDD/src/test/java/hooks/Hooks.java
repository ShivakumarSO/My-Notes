package hooks;

import cucumber.api.java.Before;
import runner.Baseclass;

import org.testng.Reporter;

import cucumber.api.Scenario;
import cucumber.api.java.After;

public class Hooks extends Baseclass{
	
	@Before
	public void Before(Scenario scenario) {
		System.out.println("Entered Hooks");
		gstrScenarioName=scenario.getName();
		Reporter.log("************************ StartTest - "+gstrScenarioName+" ************************");
	}
		
	
	@After
	public void After(Scenario scenario) {
		//Reseting Request and Response
		gRequest=null;
		gResponse=null;
		try {
			boolean Result=scenario.isFailed();
			if(Result==false) {
				Reporter.log("PASS:"+"Passed");
			}else {
				Reporter.log("FAIL:"+"Failed");
			}
		} catch(Exception e) {
			Reporter.log("ERROR:"+"Exception at Hooks @After");
			Reporter.log("ERROR:"+"StackTrace: "+e.toString());
				e.printStackTrace();
				throw e;
		}
		Reporter.log("************************ EndTest - "+gstrScenarioName+" ************************");
	}

}
